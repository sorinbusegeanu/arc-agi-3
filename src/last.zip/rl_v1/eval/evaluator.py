from __future__ import annotations

import copy
import sys
from pathlib import Path

from rl_v1.data.rollout_collector import RolloutCollector
from rl_v1.metrics.metric_keys import GAME_WIN_RATE, LEVEL_COMPLETION_RATE, MEAN_LEVELS_REACHED, MEAN_STEPS_PER_COMPLETED_LEVEL
from rl_v1.metrics.multilevel_metrics import MultiLevelMetricAccumulator
from rl_v1.model.action_selector import ActionSelector, resolve_acting_mode
from rl_v1.training.parallel_collector import ParallelRolloutManager
from rl_v1.utils.artifact_writer import ArtifactWriter
from rl_v1.utils.run_summary import build_run_summary


class Evaluator:
    def __init__(self, cfg=None, model=None, wandb_logger=None, step: int = 0) -> None:
        self.cfg = cfg
        self.model = model
        self.wandb_logger = wandb_logger
        self.step = step
        self.parallel_rollout_manager = None
        if self.cfg is not None and self.model is not None and self.cfg.env.execution_mode == "parallel_workers":
            # env.num_workers is deprecated for multiprocessing; runtime.rollout_processes is the active knob.
            self.parallel_rollout_manager = ParallelRolloutManager(self.cfg, self.cfg)
            self.parallel_rollout_manager.start()

    def evaluate(self, episodes=None) -> dict:
        try:
            if self.cfg is None or self.model is None:
                accumulator = MultiLevelMetricAccumulator()
                for episode in episodes or []:
                    accumulator.on_game_start()
                    current_level_index = None
                    steps_in_level = 0
                    for step in episode:
                        level_index = step.current_level_index
                        if current_level_index is None or level_index != current_level_index:
                            accumulator.on_level_enter(level_index)
                            current_level_index = level_index
                            steps_in_level = 0
                        steps_in_level += 1
                        if step.level_completed:
                            accumulator.on_level_complete(level_index, steps_in_level)
                            steps_in_level = 0
                    if episode:
                        final_step = episode[-1]
                        accumulator.on_game_end(final_step.game_won, final_step.deepest_level_index)
                return accumulator.compute()

            artifact_writer = ArtifactWriter(Path(self.cfg.logging.output_dir) / self.cfg.logging.run_name / "eval")

            def collect_mode(mode_name: str):
                selector_cfg = copy.deepcopy(self.cfg)
                selector_cfg.acting.mode = "planner_act" if mode_name == "planner_act" else "policy_only"
                sequences = []
                if self.cfg.env.execution_mode == "parallel_workers":
                    game_episode_counts = {
                        str(game_id): int(self.cfg.evaluation.episodes)
                        for game_id in self.cfg.env.game_ids
                    }
                    # Training can weight collection via env.game_episode_multipliers; evaluation is intentionally unweighted.
                    if self.parallel_rollout_manager is None:
                        raise RuntimeError("parallel rollout manager is not initialized for evaluator")
                    sequences = self.parallel_rollout_manager.collect(
                        self.model,
                        game_episode_counts=game_episode_counts,
                        deterministic=self.cfg.evaluation.deterministic,
                        evaluation=True,
                        acting_mode=selector_cfg.acting.mode,
                    )
                else:
                    selector = ActionSelector(selector_cfg)
                    collector = RolloutCollector(self.cfg.rollout, selector)
                    from rl_v1.env.adapter import ArcEnvironmentAdapter

                    for worker_game_ids in _partition_game_ids(self.cfg.env.game_ids, self.cfg.env.num_workers):
                        for game_id in worker_game_ids:
                            env = ArcEnvironmentAdapter(self.cfg.env, self.cfg.model, game_id, reward_cfg=self.cfg.reward)
                            try:
                                # Training can weight collection via env.game_episode_multipliers; evaluation is intentionally unweighted.
                                sequences.extend(collector.collect(self.model, env, episodes=self.cfg.evaluation.episodes, deterministic=self.cfg.evaluation.deterministic, evaluation=True))
                            finally:
                                if hasattr(env, "close"):
                                    env.close()
                summary, episode_rows, planner_traces = _summarize_sequences(sequences)
                artifact_writer.write_eval_summary(mode_name, build_run_summary(self.cfg, summary))
                artifact_writer.write_episode_summaries(mode_name, episode_rows)
                if planner_traces:
                    artifact_writer.write_planner_trace(mode_name, planner_traces)
                return summary

            configured_mode = resolve_acting_mode(self.cfg, evaluation=True)
            if configured_mode != "policy_only" and not self.cfg.ablations.disable_planner:
                policy = collect_mode("policy_only")
                configured = collect_mode("planner_act")
                summary = {
                    "policy_only_game_win_rate": policy[GAME_WIN_RATE],
                    "policy_only_level_completion_rate": policy[LEVEL_COMPLETION_RATE],
                    "policy_only_mean_levels_reached": policy[MEAN_LEVELS_REACHED],
                    "policy_only_mean_steps_per_completed_level": policy[MEAN_STEPS_PER_COMPLETED_LEVEL],
                    "configured_mode_game_win_rate": configured[GAME_WIN_RATE],
                    "configured_mode_level_completion_rate": configured[LEVEL_COMPLETION_RATE],
                    "configured_mode_mean_levels_reached": configured[MEAN_LEVELS_REACHED],
                    "configured_mode_mean_steps_per_completed_level": configured[MEAN_STEPS_PER_COMPLETED_LEVEL],
                }
                if self.wandb_logger is not None:
                    self.wandb_logger.log_metrics(_wandb_eval_metrics(summary), step=self.step)
                _print_eval_summary(summary)
                return summary
            summary = collect_mode("policy_only" if configured_mode == "policy_only" else "planner_act")
            if self.wandb_logger is not None:
                self.wandb_logger.log_metrics(_wandb_eval_metrics(summary), step=self.step)
            _print_eval_summary(summary)
            return summary
        finally:
            self.shutdown()

    def shutdown(self) -> None:
        if self.parallel_rollout_manager is not None:
            self.parallel_rollout_manager.close()
            self.parallel_rollout_manager = None


def _summarize_sequences(sequences):
    accumulator = MultiLevelMetricAccumulator()
    episode_rows = []
    planner_traces = []
    by_episode = {}
    for sequence in sequences:
        by_episode.setdefault(sequence.episode_id, []).append(sequence)
    for episode_id in sorted(by_episode):
        episode_sequences = sorted(by_episode[episode_id], key=lambda seq: _sequence_sort_key(seq.sequence_id))
        game_ids = {seq.game_id for seq in episode_sequences}
        env_instance_ids = {seq.env_instance_id for seq in episode_sequences}
        assert len(game_ids) == 1, f"grouped episode {episode_id} contains multiple game ids: {game_ids}"
        assert len(env_instance_ids) == 1, f"grouped episode {episode_id} contains multiple env instance ids: {env_instance_ids}"
        game_id = next(iter(game_ids))
        env_instance_id = next(iter(env_instance_ids))
        accumulator.on_game_start()
        starting_level = None
        current_level = None
        steps_in_level = 0
        levels_completed = 0
        total_steps = 0
        deepest_level_reached = None
        terminal_level_index = None
        game_won = False
        planner = {}
        observed_level_indices: list[int] = []
        for sequence in episode_sequences:
            for step in sequence.timesteps:
                level_index = step.observation.current_level_index
                observed_level_indices.append(level_index)
                if starting_level is None:
                    starting_level = level_index
                if deepest_level_reached is None:
                    deepest_level_reached = level_index
                else:
                    deepest_level_reached = max(deepest_level_reached, level_index, step.next_observation.current_level_index)
                if current_level is None or current_level != level_index:
                    accumulator.on_level_enter(level_index)
                    current_level = level_index
                    steps_in_level = 0
                steps_in_level += 1
                total_steps += 1
                if step.next_observation.level_completed:
                    accumulator.on_level_complete(level_index, steps_in_level)
                    levels_completed += 1
                    if not step.next_observation.game_won and step.next_observation.current_level_index <= level_index:
                        raise ValueError(
                            f"invalid level progression in episode {episode_id}: "
                            f"level_completed at {level_index} without progressing level, "
                            f"raw={step.next_observation.raw_metadata}"
                        )
                    steps_in_level = 0
                terminal_level_index = step.next_observation.current_level_index
                game_won = game_won or bool(step.next_observation.game_won)
                if step.next_observation.game_won and not step.next_observation.terminal:
                    raise ValueError(
                        f"inconsistent game_won terminal state in episode {episode_id}: "
                        f"raw={step.next_observation.raw_metadata}"
                    )
                if not planner:
                    planner = step.extras.get("diagnostics", {}).get("planner", {})
        if starting_level is not None and deepest_level_reached is not None:
            if observed_level_indices:
                deepest_level_reached = max(observed_level_indices + [deepest_level_reached, terminal_level_index if terminal_level_index is not None else deepest_level_reached])
            assert levels_completed == 0 or deepest_level_reached >= starting_level
            assert not game_won or deepest_level_reached >= starting_level
            if levels_completed > max(0, deepest_level_reached - starting_level) and not game_won:
                raise ValueError(
                    f"inconsistent level metrics in episode {episode_id}: "
                    f"levels_completed={levels_completed}, starting_level={starting_level}, "
                    f"deepest_level_reached={deepest_level_reached}"
                )
            accumulator.on_game_end(game_won, deepest_level_reached)
            episode_rows.append(
                {
                    "game_id": game_id,
                    "env_instance_id": env_instance_id,
                    "seed": episode_sequences[0].timesteps[0].observation.raw_metadata.get("seed"),
                    "won": game_won,
                    "starting_level_index": starting_level,
                    "deepest_level_reached": deepest_level_reached,
                    "levels_completed": levels_completed,
                    "terminal_level_index": terminal_level_index,
                    "total_steps": total_steps,
                }
            )
            if planner:
                planner_traces.append(
                    {
                        "chosen_first_action": planner.get("chosen_first_action"),
                        "branch_length": planner.get("branch_length"),
                        "planner_score": planner.get("planner_score"),
                    }
                )
    metrics = accumulator.compute()
    assert not (metrics[LEVEL_COMPLETION_RATE] > 0.0 and metrics[MEAN_LEVELS_REACHED] == 0.0)
    return {
        GAME_WIN_RATE: metrics[GAME_WIN_RATE],
        LEVEL_COMPLETION_RATE: metrics[LEVEL_COMPLETION_RATE],
        MEAN_LEVELS_REACHED: metrics[MEAN_LEVELS_REACHED],
        MEAN_STEPS_PER_COMPLETED_LEVEL: metrics[MEAN_STEPS_PER_COMPLETED_LEVEL],
    }, episode_rows, planner_traces


def _partition_game_ids(game_ids, num_workers: int):
    worker_count = max(1, min(int(num_workers), len(game_ids)))
    buckets = [[] for _ in range(worker_count)]
    for idx, game_id in enumerate(game_ids):
        buckets[idx % worker_count].append(game_id)
    return buckets


def _sequence_sort_key(sequence_id: str):
    if sequence_id.startswith("seq-"):
        try:
            return int(sequence_id.split("-", 1)[1])
        except ValueError:
            return sequence_id
    return sequence_id


def _wandb_eval_metrics(summary: dict) -> dict:
    allowed = {
        "game_win_rate",
        "level_completion_rate",
        "mean_levels_reached",
        "mean_steps_per_completed_level",
        "policy_only_game_win_rate",
        "policy_only_level_completion_rate",
        "policy_only_mean_levels_reached",
        "policy_only_mean_steps_per_completed_level",
        "configured_mode_game_win_rate",
        "configured_mode_level_completion_rate",
        "configured_mode_mean_levels_reached",
        "configured_mode_mean_steps_per_completed_level",
    }
    return {key: value for key, value in summary.items() if key in allowed and isinstance(value, (int, float))}


def _print_eval_summary(summary: dict) -> None:
    ordered_keys = [
        "game_win_rate",
        "level_completion_rate",
        "mean_levels_reached",
        "mean_steps_per_completed_level",
        "policy_only_game_win_rate",
        "policy_only_level_completion_rate",
        "policy_only_mean_levels_reached",
        "policy_only_mean_steps_per_completed_level",
        "configured_mode_game_win_rate",
        "configured_mode_level_completion_rate",
        "configured_mode_mean_levels_reached",
        "configured_mode_mean_steps_per_completed_level",
    ]
    parts = [f"{key}={summary[key]:.4f}" for key in ordered_keys if key in summary and isinstance(summary[key], (int, float))]
    sys.stdout.write("eval " + " ".join(parts) + "\n")
    sys.stdout.flush()
