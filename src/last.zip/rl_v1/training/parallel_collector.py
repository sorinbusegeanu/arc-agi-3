from __future__ import annotations

import io
import multiprocessing as mp

import torch

from rl_v1.training.worker import _build_model_signature, rollout_worker_main


class ParallelRolloutManager:
    def __init__(self, cfg, action_selector_cfg_source) -> None:
        self.cfg = cfg
        self.action_selector_cfg_source = action_selector_cfg_source
        self._started = False
        self._ctx = None
        self._workers: list[dict] = []
        self._worker_debug: dict[int, dict] = {}

    def start(self) -> None:
        if self._started:
            return
        self._ctx = mp.get_context(self.cfg.env.mp_start_method)
        # env.num_workers is deprecated for multiprocessing; runtime.rollout_processes is the active knob.
        partitions = _partition_game_ids(self.cfg.env.game_ids, int(self.cfg.runtime.rollout_processes))
        try:
            for worker_id in range(int(self.cfg.runtime.rollout_processes)):
                parent_conn, child_conn = self._ctx.Pipe()
                process = self._ctx.Process(
                    target=rollout_worker_main,
                    args=(child_conn,),
                    daemon=True,
                )
                process.start()
                assigned_game_ids = partitions[worker_id] if worker_id < len(partitions) else []
                worker = {
                    "id": worker_id,
                    "process": process,
                    "conn": parent_conn,
                    "game_ids": assigned_game_ids,
                }
                self._workers.append(worker)
                self._worker_debug[worker_id] = {
                    "assigned_game_ids": list(assigned_game_ids),
                    "init_succeeded": False,
                }
                worker["conn"].send(
                    {
                        "type": "init",
                        "payload": {
                            "config_dict": self.cfg.to_dict(),
                            "worker_id": int(worker_id),
                            "game_ids": list(assigned_game_ids),
                        },
                    }
                )
            for worker in self._workers:
                response = worker["conn"].recv()
                if not response.get("ok"):
                    raise RuntimeError(f"parallel worker {worker['id']} init failed: {response.get('error')}")
                self._worker_debug[int(worker["id"])]["init_succeeded"] = True
            self._started = True
        except Exception:
            self.close()
            raise

    def collect(self, model, game_episode_counts: dict[str, int], deterministic: bool, evaluation: bool, acting_mode: str | None = None) -> list:
        if not self._started:
            self.start()
        model_buffer = io.BytesIO()
        cpu_state = {key: value.detach().cpu() for key, value in model.state_dict().items()}
        torch.save(cpu_state, model_buffer)
        model_state_bytes = model_buffer.getvalue()
        for worker in self._workers:
            assigned_game_ids = worker["game_ids"]
            per_game_episode_counts = {
                game_id: int(game_episode_counts.get(game_id, 0))
                for game_id in assigned_game_ids
            }
            worker["conn"].send(
                {
                    "type": "collect",
                    "payload": {
                        "model_state_bytes": model_state_bytes,
                        "model_signature": _build_model_signature(self.cfg),
                        "per_game_episode_counts": per_game_episode_counts,
                        "deterministic": bool(deterministic),
                        "evaluation": bool(evaluation),
                        "acting_mode": acting_mode,
                        "worker_id": int(worker["id"]),
                    },
                }
            )
        sequences = []
        for worker in self._workers:
            response = worker["conn"].recv()
            if not response.get("ok"):
                raise RuntimeError(f"parallel worker {worker['id']} collect failed: {response.get('error')}")
            sequences.extend(response.get("sequences", []))
        return sequences

    def close(self) -> None:
        if not self._started:
            return
        for worker in self._workers:
            try:
                worker["conn"].send({"type": "close"})
            except Exception:
                pass
        for worker in self._workers:
            try:
                worker["conn"].recv()
            except Exception:
                pass
            worker["process"].join(timeout=5.0)
            if worker["process"].is_alive():
                worker["process"].terminate()
            worker["conn"].close()
        self._workers = []
        self._worker_debug = {}
        self._started = False


def _partition_game_ids(game_ids, process_count: int):
    count = max(1, int(process_count))
    buckets = [[] for _ in range(count)]
    for idx, game_id in enumerate(game_ids):
        buckets[idx % count].append(game_id)
    return buckets
