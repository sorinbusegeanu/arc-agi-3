from __future__ import annotations

import sys
from pathlib import Path

import torch

from rl_v1.data.rollout_collector import RolloutCollector
from rl_v1.env.adapter import ArcEnvironmentAdapter
from rl_v1.eval.evaluator import Evaluator
from rl_v1.metrics.metric_keys import LEVEL_COMPLETION_RATE
from rl_v1.metrics.training_loss_meter import TrainingLossMeter
from rl_v1.model.action_selector import ActionSelector
from rl_v1.model.latent_targets import NextLatentTargetBuilder
from rl_v1.model.model_factory import build_model
from rl_v1.training.fabric import build_fabric
from rl_v1.training.losses import compute_gae, compute_losses
from rl_v1.training.parallel_collector import ParallelRolloutManager
from rl_v1.utils.artifact_writer import ArtifactWriter
from rl_v1.utils.checkpoint_manager import CheckpointManager
from rl_v1.utils.io import ensure_dir
from rl_v1.utils.run_summary import build_run_summary


class Trainer:
    def __init__(self, cfg, model=None, wandb_logger=None) -> None:
        self.cfg = cfg
        self.wandb_logger = wandb_logger
        accelerator = _resolve_runtime_accelerator(cfg.runtime.accelerator)
        self.fabric = build_fabric(
            accelerator=accelerator,
            precision=cfg.runtime.precision,
            devices=cfg.runtime.devices,
        )
        self.model = build_model(cfg) if model is None else model
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=cfg.optimization.learning_rate, weight_decay=cfg.optimization.weight_decay)
        self.scheduler = None
        self.model, self.optimizer = self.fabric.setup(self.model, self.optimizer)
        self.action_selector = ActionSelector(cfg)
        self.collector = RolloutCollector(cfg.rollout, self.action_selector)
        self.target_builder = NextLatentTargetBuilder()
        self.training_loss_meter = TrainingLossMeter()
        self.run_dir = ensure_dir(Path(cfg.logging.output_dir) / cfg.logging.run_name)
        self.artifacts = ArtifactWriter(self.run_dir / "artifacts")
        self.checkpoints = CheckpointManager()
        self.update_idx = 0
        self.best_level_completion_rate = float("-inf")
        self._envs = None
        self.parallel_rollout_manager = None
        self._closed = False
        if self.cfg.env.execution_mode == "parallel_workers":
            # env.num_workers is deprecated for multiprocessing; runtime.rollout_processes is the active knob.
            self.parallel_rollout_manager = ParallelRolloutManager(cfg, self.action_selector)
            self.parallel_rollout_manager.start()

    def build_envs(self):
        envs = []
        for worker_game_ids in _partition_game_ids(self.cfg.env.game_ids, self.cfg.env.num_workers):
            for game_id in worker_game_ids:
                envs.append(ArcEnvironmentAdapter(self.cfg.env, self.cfg.model, game_id, reward_cfg=self.cfg.reward))
        return envs

    def maybe_restore(self):
        if self.cfg.checkpoint.restore_path:
            self.checkpoints.load(self.cfg.checkpoint.restore_path, model=self.model, optimizer=self.optimizer, scheduler=self.scheduler, cfg=self.cfg)

    def train(self, updates: int = 1):
        self.maybe_restore()
        self._ensure_envs()
        summary = {}
        try:
            for _ in range(updates):
                self.update_idx += 1
                sequences = self._collect_sequences(deterministic=False, evaluation=False)
                collected_steps = sum(len(sequence.timesteps) for sequence in sequences)
                sys.stdout.write(f"collected_steps={collected_steps}\n")
                sys.stdout.flush()
                summary = self._train_on_sequences(sequences)
                _print_training_progress(self.update_idx, updates, summary.get("training_loss"))
                if self.update_idx % self.cfg.logging.log_every_updates == 0:
                    payload = build_run_summary(self.cfg, self.training_loss_meter.compute())
                    payload["update_idx"] = self.update_idx
                    payload["effective_training_episodes_per_game"] = {
                        str(game_id): _episodes_to_collect_for_game(self.cfg, str(game_id))
                        for game_id in self.cfg.env.game_ids
                    }
                    self.artifacts.write_eval_summary(f"train_update_{self.update_idx:06d}", payload)
                    if self.wandb_logger is not None and self.update_idx % self.cfg.wandb.log_every_updates == 0:
                        self.wandb_logger.log_metrics(_wandb_training_metrics(summary), step=self.update_idx)
                    self.training_loss_meter.reset()
                if self.cfg.checkpoint.enabled and self.update_idx % self.cfg.checkpoint.save_every_updates == 0:
                    self.checkpoints.save(
                        self.run_dir / "last.pt",
                        model=self.model,
                        optimizer=self.optimizer,
                        scheduler=self.scheduler,
                        cfg=self.cfg,
                        update_idx=self.update_idx,
                        model_variant=self.cfg.model.variant,
                    )
                if self.update_idx % self.cfg.logging.eval_every_updates == 0:
                    summary["evaluation"] = Evaluator(self.cfg, self.model, wandb_logger=self.wandb_logger, step=self.update_idx).evaluate()
                    self._maybe_save_best_checkpoint(summary["evaluation"])
            if updates > 0:
                sys.stdout.write("\n")
                sys.stdout.flush()
            return summary
        finally:
            self.shutdown()

    def _train_on_sequences(self, sequences):
        self.model.train()
        if not sequences:
            return self.training_loss_meter.compute()
        target_latents_by_sequence = {}
        for sequence in sequences:
            if hasattr(self.target_builder, "build_next_latents_for_sequence"):
                targets = self.target_builder.build_next_latents_for_sequence(sequence, self.model)
            else:
                targets, _ = self.target_builder.build_next_latent_targets(
                    [sequence],
                    self.model,
                    {sequence.sequence_id: sequence.initial_hidden_state},
                )
            target_latents_by_sequence[sequence.sequence_id] = targets
        rows = []
        for _epoch_idx in range(self.cfg.optimization.ppo_epochs):
            for seq_batch in _batched_sequences(sequences, self.cfg.optimization.batch_size):
                self.optimizer.zero_grad()
                batch_total = torch.tensor(0.0, device=self.fabric.device)
                batch_parts_sum = {}
                step_count = 0
                for sequence in seq_batch:
                    if not sequence.timesteps:
                        continue
                    rewards = [step.reward for step in sequence.timesteps]
                    values = [step.value_estimate for step in sequence.timesteps]
                    dones = [step.done for step in sequence.timesteps]
                    terminal_chunk = sequence.chunk_end_reason == "terminal"
                    advantages, returns = compute_gae(
                        rewards,
                        values,
                        dones,
                        self.cfg.optimization.gamma,
                        self.cfg.optimization.gae_lambda,
                        bootstrap_value=sequence.bootstrap_value,
                        terminal_chunk=terminal_chunk,
                    )
                    hidden = sequence.initial_hidden_state.to(self.fabric.device)
                    target_latents = target_latents_by_sequence.get(sequence.sequence_id)
                    if target_latents is None:
                        raise ValueError(f"missing target latents for sequence_id={sequence.sequence_id}")
                    if target_latents.shape[0] != len(sequence.timesteps):
                        raise ValueError(
                            "target latent/timestep mismatch for sequence_id="
                            f"{sequence.sequence_id}: target_len={target_latents.shape[0]}, "
                            f"timestep_len={len(sequence.timesteps)}"
                        )
                    for idx, step in enumerate(sequence.timesteps):
                        encoded = self.model.encode_observation(step.observation, step.previous_action.action_id, step.previous_reward, step.previous_done, hidden)
                        hidden = encoded.hidden.detach()
                        distribution = torch.distributions.Categorical(logits=encoded.policy_logits)
                        new_logprob = distribution.log_prob(torch.tensor([step.chosen_action.action_id], device=self.fabric.device))
                        transition_pred = reward_pred = done_logit = transition_target = reward_target = done_target = None
                        if self.model.dynamics is not None:
                            transition_pred, reward_pred, done_logit = self.model.transition(encoded.latent, step.chosen_action.action_id)
                            transition_target = target_latents[idx : idx + 1]
                            reward_target = torch.tensor([step.reward], device=self.fabric.device)
                            done_target = torch.tensor([1.0 if step.done else 0.0], device=self.fabric.device)
                        if self.cfg.ablations.disable_transition_loss:
                            transition_pred = None
                            transition_target = None
                        loss, parts = compute_losses(
                            new_logprob=new_logprob,
                            old_logprob=torch.tensor([step.action_logprob], device=self.fabric.device),
                            value_pred=encoded.value,
                            returns=returns[idx : idx + 1].to(self.fabric.device),
                            advantages=advantages[idx : idx + 1].to(self.fabric.device),
                            entropy=distribution.entropy(),
                            transition_pred=transition_pred,
                            transition_target=transition_target,
                            reward_pred=reward_pred,
                            reward_target=reward_target,
                            done_logit=done_logit,
                            done_target=done_target,
                            optimization_cfg=self.cfg.optimization,
                            loss_weights_cfg=self.cfg.loss_weights,
                        )
                        if not torch.isfinite(loss).item():
                            raise ValueError(
                                f"non-finite loss detected for sequence_id={sequence.sequence_id}, "
                                f"timestep_idx={idx}, loss_parts={parts}"
                            )
                        batch_total = batch_total + loss
                        for key, value in parts.items():
                            batch_parts_sum[key] = batch_parts_sum.get(key, 0.0) + float(value)
                        step_count += 1
                if step_count == 0:
                    continue
                batch_total = batch_total / step_count
                if not torch.isfinite(batch_total).item():
                    raise ValueError(f"non-finite batch_total before backward: {float(batch_total.detach().cpu())}")
                self.fabric.backward(batch_total)
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.optimization.grad_clip_norm)
                self.optimizer.step()
                for name, parameter in self.model.named_parameters():
                    if parameter is None:
                        continue
                    if not torch.isfinite(parameter.detach()).all().item():
                        raise ValueError(f"non-finite model parameter after optimizer step: {name}")
                self.training_loss_meter.update(float(batch_total.detach().cpu()))
                rows.append({key: value / step_count for key, value in batch_parts_sum.items()})
        return _mean_rows(rows) | self.training_loss_meter.compute()

    def shutdown(self) -> None:
        if self._closed:
            return
        if self.parallel_rollout_manager is not None:
            self.parallel_rollout_manager.close()
        else:
            for env in self._envs or []:
                if hasattr(env, "close"):
                    env.close()
        self._closed = True

    def _ensure_envs(self) -> None:
        if self.cfg.env.execution_mode == "parallel_workers":
            return
        if self._envs is None:
            self._envs = self.build_envs()

    def _collect_sequences(self, *, deterministic: bool, evaluation: bool):
        if self.cfg.env.execution_mode == "parallel_workers":
            game_episode_counts = {
                str(game_id): _episodes_to_collect_for_game(self.cfg, str(game_id))
                for game_id in self.cfg.env.game_ids
            }
            if self.parallel_rollout_manager is None:
                raise RuntimeError("parallel rollout manager is not initialized")
            return self.parallel_rollout_manager.collect(
                self.model,
                game_episode_counts=game_episode_counts,
                deterministic=deterministic,
                evaluation=evaluation,
            )
        sequences = []
        for env in self._envs or []:
            episodes_to_collect = _episodes_to_collect_for_game(self.cfg, env.game_id)
            sequences.extend(
                self.collector.collect(
                    self.model,
                    env,
                    episodes=episodes_to_collect,
                    deterministic=deterministic,
                    evaluation=evaluation,
                )
            )
        return sequences

    def _maybe_save_best_checkpoint(self, evaluation_summary: dict) -> None:
        if not self.cfg.checkpoint.enabled:
            return
        metric = _extract_level_completion_rate(evaluation_summary)
        if metric is None or metric <= self.best_level_completion_rate:
            return
        self.best_level_completion_rate = float(metric)
        self.checkpoints.save(
            self.run_dir / "best_level_completion_rate.pt",
            model=self.model,
            optimizer=self.optimizer,
            scheduler=self.scheduler,
            cfg=self.cfg,
            update_idx=self.update_idx,
            model_variant=self.cfg.model.variant,
        )


def _mean_rows(rows):
    if not rows:
        return {}
    keys = set().union(*(row.keys() for row in rows))
    return {key: sum(row.get(key, 0.0) for row in rows) / len(rows) for key in keys}


def _partition_game_ids(game_ids, num_workers: int):
    worker_count = max(1, min(int(num_workers), len(game_ids)))
    buckets = [[] for _ in range(worker_count)]
    for idx, game_id in enumerate(game_ids):
        buckets[idx % worker_count].append(game_id)
    return buckets


def _resolve_runtime_accelerator(runtime_value: str) -> str:
    value = str(runtime_value).lower()
    if value == "gpu":
        value = "cuda"
    if value == "auto":
        return "cuda" if torch.cuda.is_available() else "cpu"
    if value == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA/GPU was requested but torch.cuda.is_available() is False")
        return "cuda"
    if value == "cpu":
        return "cpu"
    raise ValueError(f"unsupported runtime.accelerator value: {runtime_value}")


def _batched_sequences(sequences, batch_size: int):
    size = max(1, int(batch_size))
    for idx in range(0, len(sequences), size):
        yield sequences[idx : idx + size]


def _wandb_training_metrics(summary: dict) -> dict:
    mapping = {
        "training_loss": "training_loss",
        "policy_loss": "policy_loss",
        "value_loss": "value_loss",
        "entropy_bonus": "entropy",
        "latent_transition_loss": "transition_loss",
        "reward_prediction_loss": "reward_loss",
        "done_prediction_loss": "done_loss",
    }
    return {target: summary[source] for source, target in mapping.items() if source in summary}


def _print_training_progress(current_update: int, total_updates: int, training_loss) -> None:
    width = 24
    completed = 0 if total_updates <= 0 else int(width * current_update / total_updates)
    bar = "#" * completed + "-" * (width - completed)
    suffix = f" loss={float(training_loss):.4f}" if training_loss is not None else ""
    sys.stdout.write(f"\rtrain [{bar}] {current_update}/{total_updates}{suffix}")
    sys.stdout.flush()


def _extract_level_completion_rate(summary: dict) -> float | None:
    if LEVEL_COMPLETION_RATE in summary:
        return float(summary[LEVEL_COMPLETION_RATE])
    if "configured_mode_level_completion_rate" in summary:
        return float(summary["configured_mode_level_completion_rate"])
    return None


def _episodes_to_collect_for_game(cfg, game_id: str) -> int:
    base = cfg.rollout.num_episodes_per_collect
    multiplier = cfg.env.game_episode_multipliers.get(game_id, 1)
    return base * multiplier
