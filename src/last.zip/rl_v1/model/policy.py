from __future__ import annotations

import torch

from rl_v1.model.action_masking import build_valid_action_mask


def apply_valid_action_mask(logits: torch.Tensor, observation_or_mask) -> torch.Tensor:
    if isinstance(observation_or_mask, torch.Tensor):
        mask = observation_or_mask.to(dtype=torch.bool, device=logits.device)
    else:
        built = build_valid_action_mask(observation_or_mask)
        mask = built.to(dtype=torch.bool, device=logits.device) if isinstance(built, torch.Tensor) else torch.tensor(built, dtype=torch.bool, device=logits.device)
    if mask.dim() == 1:
        mask = mask.unsqueeze(0)
    safe_mask = mask.clone()
    empty_rows = safe_mask.sum(dim=-1) == 0
    if empty_rows.any():
        safe_mask[empty_rows, 1] = True
    return logits.masked_fill(~safe_mask, -1e9)


def sample_masked_action(masked_logits: torch.Tensor, deterministic: bool) -> tuple[int, torch.Tensor, torch.Tensor]:
    distribution = torch.distributions.Categorical(logits=masked_logits)
    action = masked_logits.argmax(dim=-1) if deterministic else distribution.sample()
    return int(action.item()), distribution.log_prob(action), distribution.entropy()


def masked_logprob(masked_logits: torch.Tensor, action_id: int) -> torch.Tensor:
    distribution = torch.distributions.Categorical(logits=masked_logits)
    return distribution.log_prob(torch.tensor([action_id], device=masked_logits.device))
