from __future__ import annotations

import torch


class NextLatentTargetBuilder:
    def build_next_latents_for_sequence(self, sequence, model) -> torch.Tensor:
        device = next(model.parameters()).device
        hidden = sequence.initial_hidden_state.to(device)
        outputs = []
        for step in sequence.timesteps:
            encoded = model.encode_observation(
                step.next_observation,
                prev_action_id=step.chosen_action.action_id,
                prev_reward=step.reward,
                prev_done=step.done,
                hidden=hidden,
            )
            outputs.append(_single_latent_row(encoded.latent.detach()))
            hidden = encoded.hidden.detach()
        if not outputs:
            return torch.zeros((0, model.cfg.hidden_dim), device=device)
        return torch.cat(outputs, dim=0)

    def build_next_latent_targets(self, batch, model, hidden_state_bundle):
        outputs = []
        masks = []
        device = next(model.parameters()).device
        by_episode = {}
        for sequence in batch:
            by_episode.setdefault(sequence.episode_id, []).append(sequence)
        for episode_id in sorted(by_episode):
            sequences = sorted(by_episode[episode_id], key=lambda seq: _sequence_sort_key(seq.sequence_id))
            first_sequence = sequences[0]
            hidden = hidden_state_bundle[first_sequence.sequence_id].to(device)
            for seq_idx, sequence in enumerate(sequences):
                if seq_idx == 0 and sequence.sequence_start:
                    hidden = hidden_state_bundle[sequence.sequence_id].to(device)
                for step in sequence.timesteps:
                    encoded = model.encode_observation(
                        step.next_observation,
                        prev_action_id=step.chosen_action.action_id,
                        prev_reward=step.reward,
                        prev_done=step.done,
                        hidden=hidden,
                    )
                    hidden = encoded.hidden.detach()
                    outputs.append(_single_latent_row(encoded.latent.detach()))
                    masks.append(1.0)
        if not outputs:
            return torch.zeros(0, model.cfg.hidden_dim), torch.zeros(0)
        return torch.cat(outputs, dim=0), torch.tensor(masks, dtype=torch.float32, device=outputs[0].device)


def _sequence_sort_key(sequence_id: str):
    if sequence_id.startswith("seq-"):
        try:
            return int(sequence_id.split("-", 1)[1])
        except ValueError:
            return sequence_id
    return sequence_id


def _single_latent_row(latent: torch.Tensor) -> torch.Tensor:
    if latent.ndim == 1:
        return latent.unsqueeze(0)
    if latent.ndim == 2:
        if latent.shape[0] == 1:
            return latent
        return latent.mean(dim=0, keepdim=True)
    flat = latent.reshape(latent.shape[0], -1)
    if flat.shape[0] == 1:
        return flat
    return flat.mean(dim=0, keepdim=True)
