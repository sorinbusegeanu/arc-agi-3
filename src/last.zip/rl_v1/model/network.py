from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch
from torch import nn
from torch.nn import functional as F

from rl_v1.configs.schema import ModelConfig, PlannerConfig
from rl_v1.data.contracts import ObservationPackage, PolicyOutput, V1Action
from rl_v1.model.components import (
    ClickPolicyHead,
    DynamicsModel,
    PolicyHead,
    RecurrentCore,
    SlotAttention,
    SlotPooler,
    SlotRelationBlock,
    ValueHead,
    VisualEncoder,
)
from rl_v1.planner.beam_search import BeamSearchPlanner


@dataclass
class StepOutput:
    latent: torch.Tensor
    hidden: torch.Tensor
    spatial: torch.Tensor
    tokens: torch.Tensor
    raw_slots: torch.Tensor | None
    slots: torch.Tensor | None
    pooled: torch.Tensor
    policy_logits: torch.Tensor
    value: torch.Tensor
    click_logits: torch.Tensor | None
    diagnostics: dict[str, Any]


class RLV1Model(nn.Module):
    def __init__(self, model_cfg: ModelConfig, planner_cfg: PlannerConfig) -> None:
        super().__init__()
        self.cfg = model_cfg
        self.encoder = VisualEncoder(3, model_cfg.encoder_dim, tuple(model_cfg.encoder_channels))
        self.use_slots = bool(model_cfg.use_slots)
        if self.use_slots:
            self.slot_attention = SlotAttention(model_cfg.slot_count, model_cfg.slot_dim)
            self.slot_relation = SlotRelationBlock(model_cfg.slot_dim, model_cfg.relation_heads, model_cfg.relation_layers)
            self.pooler = SlotPooler(model_cfg.slot_dim, mode=model_cfg.pooling)
            scene_dim = model_cfg.slot_dim
        else:
            self.slot_attention = None
            self.slot_relation = None
            self.pooler = None
            self.direct_pool = nn.Sequential(nn.Linear(model_cfg.encoder_dim, model_cfg.hidden_dim), nn.ReLU(), nn.Linear(model_cfg.hidden_dim, model_cfg.hidden_dim))
            scene_dim = model_cfg.hidden_dim
        self.use_recurrent_memory = bool(model_cfg.use_recurrent_memory)
        self.recurrent = RecurrentCore(scene_dim, model_cfg.hidden_dim, action_vocab=8)
        self.direct_latent = nn.Sequential(nn.Linear(scene_dim, model_cfg.hidden_dim), nn.Tanh())
        self.policy_head = PolicyHead(model_cfg.hidden_dim, action_vocab=8)
        self.value_head = ValueHead(model_cfg.hidden_dim)
        self.use_click_branch = bool(model_cfg.use_click_branch)
        self.click_head = ClickPolicyHead(model_cfg.hidden_dim, model_cfg.encoder_dim) if self.use_click_branch else None
        self.use_transition_model = bool(model_cfg.use_transition_model)
        self.dynamics = DynamicsModel(model_cfg.hidden_dim, action_vocab=8) if self.use_transition_model else None
        self.planner = BeamSearchPlanner(planner_cfg) if planner_cfg.enabled else None

    def initial_hidden(self, batch_size: int, device: torch.device) -> torch.Tensor:
        return self.recurrent.initial_state(batch_size, device)

    def encode_observation(
        self,
        observation: ObservationPackage,
        prev_action_id: int,
        prev_reward: float,
        prev_done: bool,
        hidden: torch.Tensor,
    ) -> StepOutput:
        frames = observation.stacked_frames().unsqueeze(0).to(hidden.device)
        valid_pixel_mask = observation.valid_pixel_mask.unsqueeze(0).to(hidden.device)
        spatial, tokens = self.encoder(frames)
        diagnostics: dict[str, Any] = {}
        if self.use_slots:
            raw_slots, slot_diag = self.slot_attention(tokens)
            slots = self.slot_relation(raw_slots)
            pooled, pool_diag = self.pooler(slots)
            diagnostics.update(slot_diag)
            diagnostics.update(pool_diag)
        else:
            raw_slots = None
            slots = None
            pooled = self.direct_pool(tokens.mean(dim=1))
            diagnostics["pooling_mode"] = "direct_mean"
        if self.use_recurrent_memory:
            prev_action = torch.tensor([int(prev_action_id)], device=hidden.device, dtype=torch.long)
            prev_reward_t = torch.tensor([float(prev_reward)], device=hidden.device, dtype=torch.float32)
            prev_done_t = torch.tensor([1.0 if prev_done else 0.0], device=hidden.device, dtype=torch.float32)
            next_hidden, latent = self.recurrent(pooled, prev_action, prev_reward_t, prev_done_t, hidden)
        else:
            next_hidden = hidden
            latent = self.direct_latent(pooled)
        action_mask = observation.valid_action_mask.unsqueeze(0).to(hidden.device)
        policy_logits = self.policy_head(latent, action_mask)
        value = self.value_head(latent)
        click_logits = self.click_head(latent, spatial, valid_pixel_mask) if self.click_head is not None else None
        diagnostics["action_mask_count"] = int(action_mask.sum().item())
        return StepOutput(
            latent=latent,
            hidden=next_hidden,
            spatial=spatial,
            tokens=tokens,
            raw_slots=raw_slots,
            slots=slots,
            pooled=pooled,
            policy_logits=policy_logits,
            value=value,
            click_logits=click_logits,
            diagnostics=diagnostics,
        )

    def act(
        self,
        observation: ObservationPackage,
        prev_action_id: int,
        prev_reward: float,
        prev_done: bool,
        hidden: torch.Tensor,
        acting_mode: str = "policy_only",
        deterministic: bool = False,
    ) -> tuple[V1Action, PolicyOutput, torch.Tensor, dict[str, Any]]:
        step = self.encode_observation(observation, prev_action_id, prev_reward, prev_done, hidden)
        planner_diag = {}
        planned_action = None
        if acting_mode in {"planner_act", "planner_eval_only"} and self.planner is not None and self.dynamics is not None:
            planned_action, planner_diag = self.planner.plan(
                latent=step.latent.detach(),
                action_mask=observation.valid_action_mask.unsqueeze(0).to(step.latent.device),
                policy_logits=step.policy_logits.detach(),
                value_head=self.value_head,
                dynamics=self.dynamics,
            )
        if acting_mode == "planner_act" and planned_action is not None:
            action = planned_action
            chosen = int(action.action_id)
        else:
            distribution = torch.distributions.Categorical(logits=step.policy_logits)
            if deterministic:
                chosen = int(step.policy_logits.argmax(dim=-1).item())
            else:
                chosen = int(distribution.sample().item())
        click_action = self._resolve_click(step, observation, chosen)
        final_action = click_action if click_action is not None else V1Action(action_id=chosen)
        action_logprob = self._action_logprob(step, final_action)
        diagnostics = dict(step.diagnostics)
        diagnostics["acting_mode"] = acting_mode
        diagnostics["planner"] = planner_diag
        diagnostics["planner_first_action"] = None if planned_action is None else planned_action.action_id
        return (
            final_action,
            PolicyOutput(
                action_logits=step.policy_logits,
                action_logprob=action_logprob,
                value=step.value,
                click_logits=step.click_logits,
                diagnostics=diagnostics,
            ),
            step.hidden,
            diagnostics,
        )

    def _resolve_click(self, step: StepOutput, observation: ObservationPackage, chosen: int) -> V1Action | None:
        if chosen != 6:
            return None
        if step.click_logits is None:
            return V1Action(action_id=6, x=0, y=0)
        flat_index = int(step.click_logits.view(1, -1).argmax(dim=-1).item())
        width = step.click_logits.shape[-1]
        y = flat_index // width
        x = flat_index % width
        return V1Action(action_id=6, x=x, y=y)

    def _action_logprob(self, step: StepOutput, action: V1Action) -> torch.Tensor:
        dist = torch.distributions.Categorical(logits=step.policy_logits)
        action_id = torch.tensor([action.action_id], device=step.policy_logits.device)
        logprob = dist.log_prob(action_id)
        if action.action_id == 6 and step.click_logits is not None and action.x is not None and action.y is not None:
            click_logp = F.log_softmax(step.click_logits.view(1, -1), dim=-1)
            flat = action.y * step.click_logits.shape[-1] + action.x
            logprob = logprob + click_logp[:, flat]
        return logprob

    def transition(self, latent: torch.Tensor, action_id: int) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        if self.dynamics is None:
            raise RuntimeError("transition model disabled")
        action_ids = torch.tensor([action_id], device=latent.device, dtype=torch.long)
        return self.dynamics(latent, action_ids)


class RecurrentBaselineModel(RLV1Model):
    def __init__(self, model_cfg: ModelConfig, planner_cfg: PlannerConfig) -> None:
        baseline_cfg = ModelConfig(**{**model_cfg.__dict__, "use_slots": False, "use_transition_model": False, "use_click_branch": False, "baseline": True})
        baseline_planner = PlannerConfig(**{**planner_cfg.__dict__, "enabled": False})
        super().__init__(baseline_cfg, baseline_planner)
