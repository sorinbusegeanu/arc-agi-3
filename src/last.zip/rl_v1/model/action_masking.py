from __future__ import annotations

import torch

from rl_v1.data.contracts import ACTION_MASK_SIZE, action_mask_from_available


def build_valid_action_mask(observation):
    existing = getattr(observation, "valid_action_mask", None)
    if existing is not None:
        if isinstance(existing, torch.Tensor):
            if existing.numel() != ACTION_MASK_SIZE:
                raise ValueError(f"valid action mask length must be {ACTION_MASK_SIZE}")
            return existing.to(dtype=torch.bool)
        existing_list = list(existing)
        if len(existing_list) != ACTION_MASK_SIZE:
            raise ValueError(f"valid action mask length must be {ACTION_MASK_SIZE}")
        return [bool(item) for item in existing_list]
    available = getattr(observation, "available_action_ids", None)
    if available is None:
        raise ValueError("observation must expose either valid_action_mask or available_action_ids")
    return action_mask_from_available(available)
