from __future__ import annotations

from collections import Counter
from typing import Any, Callable

from v5_0.contact.outcome_classifier import classify_contact_outcome
from v5_0.contact.policy import build_candidate_contact_trajectories_for_poi
from v5_0.contact.runner import run_contact_policy
from v5_0.contracts.avatar_types import (
    ContactExperimentEpisode,
    ContactExperimentReport,
    MultiResetAvatarReport,
)


def run_controlled_contact_for_episode(
    *,
    probe_episode,
    poi_report,
    selected_avatar,
    plan,
    seed: int,
    render_terminal: bool,
    env_factory: Callable[[], Any] | None,
    max_pois_to_test: int = 2,
):
    if selected_avatar.failure_reason is not None:
        return ()
    eligible_pois = tuple(candidate for candidate in poi_report.candidates if not _is_border_locked_poi(candidate))
    top_pois = tuple(
        sorted(
            eligible_pois,
            key=lambda item: (-item.confidence, item.poi_id),
        )
    )[:1]
    if not top_pois:
        return ()

    tested = []
    for poi in top_pois:
        candidate_policies = build_candidate_contact_trajectories_for_poi(
            selected_avatar=selected_avatar,
            poi_candidate=poi,
            transitions=probe_episode.transitions,
            episode_index=int(probe_episode.episode_index),
        )
        if not candidate_policies:
            continue
        policy = candidate_policies[0]
        partial = run_contact_policy(
            plan=plan,
            policy=policy,
            seed=seed,
            render_terminal=render_terminal,
            env_factory=env_factory,
            selected_avatar=selected_avatar,
            poi_candidate=poi,
        )
        outcome = classify_contact_outcome(partial, poi, selected_avatar)
        tested.append(
            type(partial)(
                poi_id=partial.poi_id,
                episode_index=partial.episode_index,
                policy=partial.policy,
                steps=partial.steps,
                outcome=outcome,
                initial_poi_bbox=partial.initial_poi_bbox,
                final_poi_bbox=partial.final_poi_bbox,
                initial_avatar_bbox=partial.initial_avatar_bbox,
                final_avatar_bbox=partial.final_avatar_bbox,
            )
        )
    return tuple(tested)


def run_controlled_contact_multi_reset(
    *,
    avatar_multi_report: MultiResetAvatarReport,
    poi_multi_bundle,
    plan,
    base_seed: int,
    render_terminal: bool,
    env_factory: Callable[[], Any] | None,
    max_pois_to_test: int = 2,
) -> ContactExperimentReport:
    poi_by_episode = {item.episode_index: item.poi_report for item in poi_multi_bundle.get("episodes", ())}
    selected_poi_ids: list[str] = []
    for episode in avatar_multi_report.episodes:
        if episode.report.selected.failure_reason is not None:
            continue
        poi_report = poi_by_episode.get(episode.episode_index)
        if poi_report is None:
            continue
        eligible_pois = tuple(candidate for candidate in tuple(getattr(poi_report, "candidates", ())) if not _is_border_locked_poi(candidate))
        top_pois = tuple(sorted(eligible_pois, key=lambda item: (-item.confidence, item.poi_id)))[:1]
        if top_pois:
            selected_poi_ids.append(str(top_pois[0].poi_id))
    collapse_same_selected_poi = bool(selected_poi_ids) and len(set(selected_poi_ids)) == 1

    episode_results = []
    all_tested = []
    policy_failures = Counter()
    skipped_border_locked_poi_count = 0
    shared_tested = None
    shared_poi_id = selected_poi_ids[0] if selected_poi_ids else None
    for episode in avatar_multi_report.episodes:
        if episode.report.selected.failure_reason is not None:
            episode_results.append(ContactExperimentEpisode(episode_index=episode.episode_index, tested_pois=()))
            continue
        poi_report = poi_by_episode.get(episode.episode_index)
        if poi_report is None:
            episode_results.append(ContactExperimentEpisode(episode_index=episode.episode_index, tested_pois=()))
            policy_failures["missing_poi_report"] += 1
            continue
        skipped_border_locked_poi_count += sum(1 for candidate in poi_report.candidates if _is_border_locked_poi(candidate))
        if collapse_same_selected_poi and shared_tested is not None:
            episode_results.append(ContactExperimentEpisode(episode_index=episode.episode_index, tested_pois=()))
            continue
        tested = run_controlled_contact_for_episode(
            probe_episode=episode,
            poi_report=poi_report,
            selected_avatar=episode.report.selected,
            plan=plan,
            seed=int(base_seed) + int(episode.episode_index),
            render_terminal=render_terminal,
            env_factory=env_factory,
            max_pois_to_test=1,
        )
        if collapse_same_selected_poi:
            if shared_poi_id is None:
                shared_tested = tested
            else:
                shared_tested = tuple(item for item in tested if str(getattr(item, "poi_id", "")) == str(shared_poi_id))
            tested = shared_tested
        if not tested and poi_report.candidates:
            policy_failures["empty_tested_set"] += 1
        episode_results.append(ContactExperimentEpisode(episode_index=episode.episode_index, tested_pois=tested))
        all_tested.extend(tested)

    outcome_counts = Counter(item.outcome.outcome_type for item in all_tested)
    diagnostics = {
        "tested_poi_count": len(all_tested),
        "successful_contact_count": sum(1 for item in all_tested if item.outcome.contact_step_index is not None),
        "outcome_type_counts": dict(sorted(outcome_counts.items())),
        "level_change_count": sum(1 for item in all_tested if item.outcome.level_transition),
        "terminal_count": sum(1 for item in all_tested if item.outcome.terminal),
        "hud_only_change_count": sum(1 for item in all_tested if item.outcome.hud_change_only),
        "skipped_border_locked_poi_count": int(skipped_border_locked_poi_count),
        "policy_failure_counts": dict(sorted(policy_failures.items())),
    }
    return ContactExperimentReport(
        episodes=tuple(episode_results),
        tested_pois=tuple(all_tested),
        diagnostics=diagnostics,
    )


def _is_border_locked_poi(poi_candidate) -> bool:
    x0, y0, x1, y1 = poi_candidate.bbox
    bw = max(1, x1 - x0 + 1)
    bh = max(1, y1 - y0 + 1)
    strip_like = bw <= 2 or bh <= 2 or bw >= 3 * bh or bh >= 3 * bw
    tiny = int(poi_candidate.area) <= 8
    if not (tiny or strip_like):
        return False
    return bool("border_locked" in set(getattr(poi_candidate, "ambiguity_flags", ())) or x0 == 0 or y0 == 0 or x1 == 0 or y1 == 0)
