from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from v5_0.cli import build_parser
from v5_0.contact.service import run_controlled_contact_multi_reset
from v5_0.contracts.avatar_types import ContactExperimentEpisode
from v5_0.runtime.campaign_state import CampaignLevelState
from v5_0.runtime.run_avatar_bootstrap import (
    run_frontier_avatar_bootstrap_from_frontier,
    run_full_campaign_analysis,
)


def test_cli_default_episode_count_is_one():
    parser = build_parser()
    args = parser.parse_args(["--game-id", "ez01"])
    assert int(args.episode_count) == 1


@patch("v5_0.runtime.run_avatar_bootstrap.write_trace_store_index_artifacts", return_value={})
@patch("v5_0.runtime.run_avatar_bootstrap.write_campaign_artifacts", return_value={})
@patch("v5_0.runtime.run_avatar_bootstrap.update_campaign_state_after_level", side_effect=lambda **kwargs: kwargs["state"])
@patch("v5_0.runtime.run_avatar_bootstrap.run_frontier_level_from_live_session")
@patch(
    "v5_0.runtime.run_avatar_bootstrap.replay_prefix_traces_to_frontier",
    return_value={"session": object(), "frontier_reached": True, "frontier_level_id": "L0", "divergence": False, "executed_action_count": 0},
)
@patch("v5_0.runtime.run_avatar_bootstrap.get_verified_prefix_traces", return_value=tuple())
@patch("v5_0.runtime.run_avatar_bootstrap.get_current_run_prefix_traces", return_value=tuple())
@patch("v5_0.runtime.run_avatar_bootstrap.get_frontier_level_id", side_effect=["L0", None])
@patch(
    "v5_0.runtime.run_avatar_bootstrap.load_or_initialize_campaign_state",
    return_value={
        "L0": CampaignLevelState(game_id="ez01", level_id="L0", status="pending", solved=False, solution_trace_path=None, best_step_count=None, attempt_count=0)
    },
)
@patch("v5_0.runtime.run_avatar_bootstrap.get_db_solved_levels_for_game", return_value=tuple())
@patch("v5_0.runtime.run_avatar_bootstrap.get_level_sequence_for_game", return_value=("L0",))
@patch("v5_0.runtime.run_avatar_bootstrap.initialize_trace_store", return_value="/tmp/trace_store.sqlite")
def test_campaign_default_passes_episode_count_one_unchanged(
    _init,
    _seq,
    _db,
    _load,
    _frontier,
    _current,
    _verified,
    _replay,
    run_frontier,
    _update,
    _write_campaign,
    _write_index,
):
    run_frontier.return_value = {
        "solved": False,
        "solution": {"action_trace": tuple(), "step_count": 0},
        "saved_trace": None,
        "diagnostics": {},
        "failure_reason": "failed",
        "artifact_paths": {},
    }

    run_full_campaign_analysis(game_id="ez01", output_dir="runs_v5_0_test")

    assert run_frontier.call_count == 1
    assert int(run_frontier.call_args.kwargs["episode_count"]) == 1


@patch("v5_0.runtime.run_avatar_bootstrap.write_trace_store_index_artifacts", return_value={})
@patch("v5_0.runtime.run_avatar_bootstrap.write_campaign_artifacts", return_value={})
@patch("v5_0.runtime.run_avatar_bootstrap.update_campaign_state_after_level", side_effect=lambda **kwargs: kwargs["state"])
@patch(
    "v5_0.runtime.run_avatar_bootstrap.replay_prefix_traces_to_frontier",
    return_value={"session": object(), "frontier_reached": True, "frontier_level_id": "L0", "divergence": False, "executed_action_count": 0},
)
@patch("v5_0.runtime.run_avatar_bootstrap.get_verified_prefix_traces", return_value=tuple())
@patch("v5_0.runtime.run_avatar_bootstrap.get_current_run_prefix_traces", return_value=tuple())
@patch("v5_0.runtime.run_avatar_bootstrap.get_frontier_level_id", side_effect=["L0", None])
@patch(
    "v5_0.runtime.run_avatar_bootstrap.load_or_initialize_campaign_state",
    return_value={
        "L0": CampaignLevelState(game_id="ez01", level_id="L0", status="pending", solved=False, solution_trace_path=None, best_step_count=None, attempt_count=0)
    },
)
@patch("v5_0.runtime.run_avatar_bootstrap.get_db_solved_levels_for_game", return_value=tuple())
@patch("v5_0.runtime.run_avatar_bootstrap.get_level_sequence_for_game", return_value=("L0",))
@patch("v5_0.runtime.run_avatar_bootstrap.initialize_trace_store", return_value="/tmp/trace_store.sqlite")
def test_campaign_default_creates_only_episode_000(
    _init,
    _seq,
    _db,
    _load,
    _frontier,
    _current,
    _verified,
    _replay,
    _update,
    _write_campaign,
    _write_index,
    tmp_path,
):
    output_dir = tmp_path / "runs"

    def _fake_frontier(**kwargs):
        level_id = str(kwargs["frontier_level_id"])
        game_id = str(kwargs["game_id"])
        episode_count = int(kwargs["episode_count"])
        base = Path(kwargs["output_dir"]) / game_id / level_id / "multi_reset"
        base.mkdir(parents=True, exist_ok=True)
        for idx in range(episode_count):
            (base / f"episode_{idx:03d}").mkdir(parents=True, exist_ok=True)
        return {
            "solved": False,
            "solution": {"action_trace": tuple(), "step_count": 0},
            "saved_trace": None,
            "diagnostics": {},
            "failure_reason": "failed",
            "artifact_paths": {},
        }

    with patch("v5_0.runtime.run_avatar_bootstrap.run_frontier_level_from_live_session", side_effect=_fake_frontier):
        run_full_campaign_analysis(game_id="ez01", output_dir=str(output_dir))

    multi_reset = output_dir / "ez01" / "L0" / "multi_reset"
    assert (multi_reset / "episode_000").exists()
    assert not (multi_reset / "episode_001").exists()
    assert not (multi_reset / "episode_002").exists()


def test_contact_experiments_do_not_repeat_same_poi_across_episodes_when_one_episode():
    avatar_multi = SimpleNamespace(
        episodes=(SimpleNamespace(episode_index=0, report=SimpleNamespace(selected=SimpleNamespace(failure_reason=None))),),
    )
    poi_candidate = SimpleNamespace(poi_id="p1", confidence=0.9, bbox=(1, 1, 2, 2), area=4, ambiguity_flags=())
    poi_multi = {"episodes": (SimpleNamespace(episode_index=0, poi_report=SimpleNamespace(candidates=(poi_candidate,))),)}

    with patch("v5_0.contact.service.run_controlled_contact_for_episode", return_value=(SimpleNamespace(outcome=SimpleNamespace(outcome_type="no_effect", contact_step_index=None, level_transition=False, terminal=False, hud_change_only=False), steps=tuple()),)) as run_one:
        report = run_controlled_contact_multi_reset(
            avatar_multi_report=avatar_multi,
            poi_multi_bundle=poi_multi,
            plan=SimpleNamespace(),
            base_seed=0,
            render_terminal=False,
            env_factory=None,
        )

    assert run_one.call_count == 1
    assert len(report.episodes) == 1
    assert isinstance(report.episodes[0], ContactExperimentEpisode)


def test_frontier_bootstrap_uses_passed_episode_count_unchanged():
    with patch("v5_0.runtime.run_avatar_bootstrap.run_probe_episodes_at_frontier", return_value=(tuple(),) * 7) as run_probe:
        run_frontier_avatar_bootstrap_from_frontier(
            game_id="ez01",
            frontier_level_id="L1",
            prefix_traces=tuple(),
            episode_count=7,
            seed=123,
            render_terminal=False,
            env_factory=None,
        )

    assert int(run_probe.call_args.kwargs["episode_count"]) == 7
