from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Any, Callable

from v5_0.contact.outcome_classifier import build_route_hint_from_contact_outcome, classify_contact_outcome
from v5_0.contact.policy import build_candidate_contact_trajectories_for_poi, dedupe_contact_trajectories
from v5_0.contact.runner import run_contact_policy
from v5_0.contracts.avatar_types import (
    ContactExperimentEpisode,
    ContactExperimentReport,
    MultiResetAvatarReport,
)


@dataclass(frozen=True)
class _TestedPOIRouteResult:
    poi_id: str
    episode_index: int
    policy: Any
    steps: tuple[Any, ...]
    outcome: Any
    initial_poi_bbox: Any
    final_poi_bbox: Any
    initial_avatar_bbox: Any
    final_avatar_bbox: Any
    route_evidence: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "poi_id": self.poi_id,
            "episode_index": int(self.episode_index),
            "policy": self.policy.to_dict() if hasattr(self.policy, "to_dict") else dict(getattr(self.policy, "__dict__", {})),
            "steps": [item.to_dict() if hasattr(item, "to_dict") else dict(getattr(item, "__dict__", {})) for item in tuple(self.steps)],
            "outcome": self.outcome.to_dict() if hasattr(self.outcome, "to_dict") else dict(getattr(self.outcome, "__dict__", {})),
            "initial_poi_bbox": self.initial_poi_bbox,
            "final_poi_bbox": self.final_poi_bbox,
            "initial_avatar_bbox": self.initial_avatar_bbox,
            "final_avatar_bbox": self.final_avatar_bbox,
        }
        if self.route_evidence is not None:
            payload["route_evidence"] = dict(self.route_evidence)
        return payload


def run_controlled_contact_for_episode(
    *,
    probe_episode,
    poi_report,
    selected_avatar,
    plan,
    seed: int,
    render_terminal: bool,
    env_factory: Callable[[], Any] | None,
    max_pois_to_test: int = 2,
):
    if selected_avatar.failure_reason is not None:
        return ()
    eligible_pois = tuple(candidate for candidate in poi_report.candidates if not _is_border_locked_poi(candidate))
    top_pois = tuple(
        sorted(
            eligible_pois,
            key=lambda item: (-item.confidence, item.poi_id),
        )
    )[:1]
    if not top_pois:
        return ()

    tested = []
    for poi in top_pois:
        candidate_policies = build_candidate_contact_trajectories_for_poi(
            selected_avatar=selected_avatar,
            poi_candidate=poi,
            transitions=probe_episode.transitions,
            episode_index=int(probe_episode.episode_index),
        )
        if not candidate_policies:
            continue
        candidate_policies = dedupe_contact_trajectories(candidate_policies)
        attempted_route_ids: list[str] = []
        best_attempt = None
        winning_attempt = None
        for policy in candidate_policies:
            attempted_route_ids.append(str(getattr(policy, "policy_id", "")))
            partial = run_contact_policy(
                plan=plan,
                policy=policy,
                seed=seed,
                render_terminal=render_terminal,
                env_factory=env_factory,
                selected_avatar=selected_avatar,
                poi_candidate=poi,
            )
            outcome = classify_contact_outcome(partial, poi, selected_avatar)
            route_hint = build_route_hint_from_contact_outcome(partial, outcome)
            attempted = (partial, outcome, route_hint)
            stop_now = bool(
                outcome.level_transition
                or outcome.terminal
                or bool(getattr(outcome, "reward_change_step_indices", ()))
                or bool(getattr(outcome, "object_removed", False))
                or str(getattr(outcome, "outcome_type", "")) == "door_opens"
                or bool(getattr(outcome, "new_object_appeared", False))
                or getattr(outcome, "contact_step_index", None) is not None
            )
            if best_attempt is None:
                best_attempt = attempted
            else:
                best_partial, best_outcome, _ = best_attempt
                best_key = (
                    float(getattr(best_outcome, "confidence", 0.0)),
                    -len(tuple(getattr(best_partial.policy, "planned_actions", ()))),
                    str(getattr(best_partial.policy, "policy_id", "")),
                )
                cur_key = (
                    float(getattr(outcome, "confidence", 0.0)),
                    -len(tuple(getattr(policy, "planned_actions", ()))),
                    str(getattr(policy, "policy_id", "")),
                )
                if cur_key > best_key:
                    best_attempt = attempted
            if stop_now:
                winning_attempt = attempted
                break
        chosen = winning_attempt if winning_attempt is not None else best_attempt
        if chosen is None:
            continue
        partial, outcome, route_hint = chosen
        winning_actions = tuple(str(item) for item in tuple(getattr(partial.policy, "planned_actions", ())))
        route_evidence = {
            "attempted_route_ids": tuple(attempted_route_ids),
            "winning_route_id": str(getattr(partial.policy, "policy_id", "")),
            "winning_route_actions": winning_actions,
            "winning_route_length": int(len(winning_actions)),
            "route_caused_contact": bool(getattr(outcome, "contact_step_index", None) is not None),
            "route_caused_world_change": bool(
                outcome.level_transition
                or outcome.terminal
                or bool(getattr(outcome, "reward_change_step_indices", ()))
                or bool(getattr(outcome, "object_removed", False))
                or bool(getattr(outcome, "new_object_appeared", False))
                or str(getattr(outcome, "outcome_type", "")) == "door_opens"
            ),
            "route_hint": route_hint,
        }
        tested.append(
            _TestedPOIRouteResult(
                poi_id=partial.poi_id,
                episode_index=partial.episode_index,
                policy=partial.policy,
                steps=partial.steps,
                outcome=outcome,
                initial_poi_bbox=partial.initial_poi_bbox,
                final_poi_bbox=partial.final_poi_bbox,
                initial_avatar_bbox=partial.initial_avatar_bbox,
                final_avatar_bbox=partial.final_avatar_bbox,
                route_evidence=route_evidence,
            )
        )
    return tuple(tested)


def run_controlled_contact_multi_reset(
    *,
    avatar_multi_report: MultiResetAvatarReport,
    poi_multi_bundle,
    plan,
    base_seed: int,
    render_terminal: bool,
    env_factory: Callable[[], Any] | None,
    max_pois_to_test: int = 2,
) -> ContactExperimentReport:
    poi_by_episode = {item.episode_index: item.poi_report for item in poi_multi_bundle.get("episodes", ())}
    selected_poi_ids: list[str] = []
    for episode in avatar_multi_report.episodes:
        if episode.report.selected.failure_reason is not None:
            continue
        poi_report = poi_by_episode.get(episode.episode_index)
        if poi_report is None:
            continue
        eligible_pois = tuple(candidate for candidate in tuple(getattr(poi_report, "candidates", ())) if not _is_border_locked_poi(candidate))
        top_pois = tuple(sorted(eligible_pois, key=lambda item: (-item.confidence, item.poi_id)))[:1]
        if top_pois:
            selected_poi_ids.append(str(top_pois[0].poi_id))
    collapse_same_selected_poi = bool(selected_poi_ids) and len(set(selected_poi_ids)) == 1

    episode_results = []
    all_tested = []
    policy_failures = Counter()
    skipped_border_locked_poi_count = 0
    shared_tested = None
    shared_poi_id = selected_poi_ids[0] if selected_poi_ids else None
    for episode in avatar_multi_report.episodes:
        if episode.report.selected.failure_reason is not None:
            episode_results.append(ContactExperimentEpisode(episode_index=episode.episode_index, tested_pois=()))
            continue
        poi_report = poi_by_episode.get(episode.episode_index)
        if poi_report is None:
            episode_results.append(ContactExperimentEpisode(episode_index=episode.episode_index, tested_pois=()))
            policy_failures["missing_poi_report"] += 1
            continue
        skipped_border_locked_poi_count += sum(1 for candidate in poi_report.candidates if _is_border_locked_poi(candidate))
        if collapse_same_selected_poi and shared_tested is not None:
            episode_results.append(ContactExperimentEpisode(episode_index=episode.episode_index, tested_pois=()))
            continue
        tested = run_controlled_contact_for_episode(
            probe_episode=episode,
            poi_report=poi_report,
            selected_avatar=episode.report.selected,
            plan=plan,
            seed=int(base_seed) + int(episode.episode_index),
            render_terminal=render_terminal,
            env_factory=env_factory,
            max_pois_to_test=1,
        )
        if collapse_same_selected_poi:
            if shared_poi_id is None:
                shared_tested = tested
            else:
                shared_tested = tuple(item for item in tested if str(getattr(item, "poi_id", "")) == str(shared_poi_id))
            tested = shared_tested
        if not tested and poi_report.candidates:
            policy_failures["empty_tested_set"] += 1
        episode_results.append(ContactExperimentEpisode(episode_index=episode.episode_index, tested_pois=tested))
        all_tested.extend(tested)

    outcome_counts = Counter(item.outcome.outcome_type for item in all_tested)
    attempted_route_ids: list[str] = []
    for item in all_tested:
        route_evidence = getattr(item, "route_evidence", None)
        if isinstance(route_evidence, dict):
            attempted_route_ids.extend(str(v) for v in tuple(route_evidence.get("attempted_route_ids", ())))
    selected_poi_best_route_hint = None
    selected_poi_ids = tuple(dict.fromkeys(str(getattr(item, "poi_id", "")) for item in all_tested if getattr(item, "poi_id", None) is not None))
    if selected_poi_ids:
        selected_poi_best_route_hint = get_best_route_hint_for_poi(
            ContactExperimentReport(episodes=tuple(), tested_pois=tuple(all_tested), diagnostics={}),
            selected_poi_ids[0],
        )
    diagnostics = {
        "tested_poi_count": len(all_tested),
        "successful_contact_count": sum(1 for item in all_tested if item.outcome.contact_step_index is not None),
        "outcome_type_counts": dict(sorted(outcome_counts.items())),
        "level_change_count": sum(1 for item in all_tested if item.outcome.level_transition),
        "terminal_count": sum(1 for item in all_tested if item.outcome.terminal),
        "hud_only_change_count": sum(1 for item in all_tested if item.outcome.hud_change_only),
        "skipped_border_locked_poi_count": int(skipped_border_locked_poi_count),
        "policy_failure_counts": dict(sorted(policy_failures.items())),
        "attempted_route_ids": tuple(attempted_route_ids),
        "selected_poi_best_route_hint": selected_poi_best_route_hint,
    }
    return ContactExperimentReport(
        episodes=tuple(episode_results),
        tested_pois=tuple(all_tested),
        diagnostics=diagnostics,
    )


def get_best_route_hint_for_poi(contact_experiment_report, poi_id: str) -> dict[str, object] | None:
    tested = tuple(getattr(contact_experiment_report, "tested_pois", ()))
    relevant = tuple(item for item in tested if str(getattr(item, "poi_id", "")) == str(poi_id))
    if not relevant:
        return None

    def _is_useful_world_change(item) -> bool:
        outcome = getattr(item, "outcome", None)
        return bool(
            str(getattr(outcome, "outcome_type", "")) in {"reward_change", "object_removed", "door_opens", "level_transition", "terminal"}
            or bool(getattr(outcome, "new_object_appeared", False))
        )

    ranked = sorted(
        relevant,
        key=lambda item: (
            not _is_useful_world_change(item),
            not bool(getattr(getattr(item, "outcome", None), "contact_step_index", None) is not None),
            -float(getattr(getattr(item, "outcome", None), "confidence", 0.0)),
            len(tuple(getattr(getattr(item, "policy", None), "planned_actions", ()))),
        ),
    )
    best = ranked[0]
    route_evidence = getattr(best, "route_evidence", None)
    if not isinstance(route_evidence, dict):
        return None
    hint = route_evidence.get("route_hint")
    if not isinstance(hint, dict):
        return None
    return dict(hint)


def _is_border_locked_poi(poi_candidate) -> bool:
    x0, y0, x1, y1 = poi_candidate.bbox
    bw = max(1, x1 - x0 + 1)
    bh = max(1, y1 - y0 + 1)
    strip_like = bw <= 2 or bh <= 2 or bw >= 3 * bh or bh >= 3 * bw
    tiny = int(poi_candidate.area) <= 8
    if not (tiny or strip_like):
        return False
    return bool("border_locked" in set(getattr(poi_candidate, "ambiguity_flags", ())) or x0 == 0 or y0 == 0 or x1 == 0 or y1 == 0)
