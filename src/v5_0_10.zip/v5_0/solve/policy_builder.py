from __future__ import annotations

from v5_0.contact.frame_tracker import track_avatar_bbox_in_frame
from v5_0.route.trajectory_enumerator import enumerate_routes_between_points


def build_solve_policy_for_target(
    selected_avatar_result,
    target_poi,
    current_frame,
    step_budget_remaining,
) -> tuple[str, ...]:
    candidates = _build_candidate_solve_routes(
        selected_avatar_result=selected_avatar_result,
        target_poi=target_poi,
        current_frame=current_frame,
        step_budget_remaining=step_budget_remaining,
        route_hints=None,
    )
    return candidates[0] if candidates else tuple()


def build_adaptive_policy_for_target(
    selected_avatar_result,
    target_poi,
    current_frame,
    step_budget_remaining,
    route_hints=None,
) -> tuple[tuple[str, ...], ...]:
    return _build_candidate_solve_routes(
        selected_avatar_result=selected_avatar_result,
        target_poi=target_poi,
        current_frame=current_frame,
        step_budget_remaining=step_budget_remaining,
        route_hints=route_hints,
    )


def _build_candidate_solve_routes(
    *,
    selected_avatar_result,
    target_poi,
    current_frame,
    step_budget_remaining,
    route_hints=None,
) -> tuple[tuple[str, ...], ...]:
    budget = max(0, int(step_budget_remaining))
    if budget <= 0 or target_poi is None:
        return tuple()

    avatar_bbox = track_avatar_bbox_in_frame(
        current_frame,
        getattr(selected_avatar_result, "selected_bbox", None),
        None,
    )
    if avatar_bbox is None:
        avatar_center = tuple(getattr(selected_avatar_result, "selected_center", (0.0, 0.0)) or (0.0, 0.0))
    else:
        avatar_center = ((avatar_bbox[0] + avatar_bbox[2]) / 2.0, (avatar_bbox[1] + avatar_bbox[3]) / 2.0)

    target_center = tuple(getattr(target_poi, "center", avatar_center))
    enumerated = enumerate_routes_between_points(
        start_center=avatar_center,
        target_center=target_center,
        max_extra_steps=6,
        max_routes=64,
    )
    route_candidates = [tuple(route.actions)[:budget] for route in enumerated if tuple(route.actions)[:budget] or route.length == 0]
    if not route_candidates:
        route_candidates = [tuple()]
    hint_candidates: list[tuple[str, ...]] = []
    for hint in tuple(route_hints or ()):
        if not isinstance(hint, dict):
            continue
        actions = tuple(str(item) for item in tuple(hint.get("actions", ())))
        suggested_prefix = int(hint.get("suggested_prefix_length", len(actions)))
        if not actions:
            continue
        prefix = actions[: max(1, min(len(actions), suggested_prefix, budget))]
        if prefix:
            hint_candidates.append(prefix)
    seen = set()
    ordered: list[tuple[str, ...]] = []
    for item in tuple(hint_candidates) + tuple(route_candidates):
        key = tuple(item)
        if key in seen:
            continue
        seen.add(key)
        ordered.append(key)
    ordered.sort(key=lambda seq: (len(seq), seq))
    for hint in reversed(hint_candidates):
        if hint in ordered:
            ordered.remove(hint)
            ordered.insert(0, hint)
    return tuple(ordered)
