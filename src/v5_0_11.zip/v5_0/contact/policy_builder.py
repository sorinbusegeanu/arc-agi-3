from __future__ import annotations

from v5_0.contracts.avatar_types import ContactPolicy, POICandidate, ProbeTransitionRecord
from v5_0.route.trajectory_enumerator import enumerate_routes_between_points


def build_contact_policies_for_poi(
    selected_avatar,
    poi_candidate: POICandidate,
    transitions: tuple[ProbeTransitionRecord, ...],
    episode_index: int,
) -> tuple[ContactPolicy, ...]:
    if _is_border_locked_poi(poi_candidate, transitions=transitions):
        return tuple()

    avatar_center = selected_avatar.selected_center or (0.0, 0.0)
    poi_center = poi_candidate.center
    routes = enumerate_routes_between_points(
        start_center=avatar_center,
        target_center=poi_center,
        max_extra_steps=6,
        max_routes=32,
    )
    policies: list[ContactPolicy] = []
    for route in routes:
        planned = tuple(route.actions)
        policies.append(
            ContactPolicy(
                policy_id=f"contact:{episode_index}:{poi_candidate.poi_id}:{route.route_id}",
                poi_id=poi_candidate.poi_id,
                episode_index=int(episode_index),
                planned_actions=planned,
                max_steps=int(len(planned)),
                stop_on_contact=True,
                stop_on_screen_change=True,
                stop_on_terminal=True,
            )
        )
    return tuple(policies)


def build_contact_policy_for_poi(
    selected_avatar,
    poi_candidate: POICandidate,
    transitions: tuple[ProbeTransitionRecord, ...],
    episode_index: int,
) -> ContactPolicy | None:
    policies = build_contact_policies_for_poi(
        selected_avatar=selected_avatar,
        poi_candidate=poi_candidate,
        transitions=transitions,
        episode_index=episode_index,
    )
    return policies[0] if policies else None


def _is_border_locked_poi(
    poi_candidate: POICandidate,
    *,
    transitions: tuple[ProbeTransitionRecord, ...] = (),
) -> bool:
    if "border_locked" in set(getattr(poi_candidate, "ambiguity_flags", ())):
        return True
    x0, y0, x1, y1 = poi_candidate.bbox
    bw = max(1, x1 - x0 + 1)
    bh = max(1, y1 - y0 + 1)
    strip_like = bw <= 2 or bh <= 2 or bw >= 3 * bh or bh >= 3 * bw
    tiny = int(poi_candidate.area) <= 8
    if not (tiny or strip_like):
        return False
    dims = _latest_frame_dimensions(transitions)
    if dims is None:
        return bool(x0 == 0 or y0 == 0)
    width, height = dims
    touches_left = x0 <= 0
    touches_top = y0 <= 0
    touches_right = x1 >= (int(width) - 1)
    touches_bottom = y1 >= (int(height) - 1)
    return bool(touches_left or touches_top or touches_right or touches_bottom)


def _latest_frame_dimensions(transitions: tuple[ProbeTransitionRecord, ...]) -> tuple[int, int] | None:
    for item in reversed(tuple(transitions or ())):
        for frame in (getattr(item, "post_frame", None), getattr(item, "pre_frame", None)):
            if frame is None:
                continue
            h = len(frame)
            w = len(frame[0]) if h else 0
            if w > 0 and h > 0:
                return int(w), int(h)
    return None
