from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations


@dataclass(frozen=True)
class RouteCandidate:
    route_id: str
    actions: tuple[str, ...]
    length: int
    net_dx: int
    net_dy: int
    first_action: str | None
    turn_count: int
    axis_order: str
    waypoints: tuple[tuple[int, int], ...]
    score_components: dict[str, float]


def enumerate_routes_between_points(
    start_center,
    target_center,
    max_extra_steps=6,
    max_routes=32,
) -> tuple[RouteCandidate, ...]:
    sx = float(start_center[0]) if start_center is not None else 0.0
    sy = float(start_center[1]) if start_center is not None else 0.0
    tx = float(target_center[0]) if target_center is not None else sx
    ty = float(target_center[1]) if target_center is not None else sy

    dx = int(round(tx - sx))
    dy = int(round(ty - sy))
    h_token = "RIGHT" if dx >= 0 else "LEFT"
    v_token = "DOWN" if dy >= 0 else "UP"
    h_steps = abs(dx)
    v_steps = abs(dy)
    shortest = h_steps + v_steps
    if shortest == 0:
        return (
            RouteCandidate(
                route_id="route_000",
                actions=tuple(),
                length=0,
                net_dx=0,
                net_dy=0,
                first_action=None,
                turn_count=0,
                axis_order="NONE",
                waypoints=((0, 0),),
                score_components={"length": 0.0, "turn_count": 0.0, "detour_steps": 0.0},
            ),
        )

    action_sequences: set[tuple[str, ...]] = set()
    base = _enumerate_shortest_interleavings(h_steps=h_steps, v_steps=v_steps, h_token=h_token, v_token=v_token)
    action_sequences.update(base)

    max_extra_even = max(0, int(max_extra_steps))
    if max_extra_even % 2 == 1:
        max_extra_even -= 1
    detour_levels = tuple(extra for extra in (2, 4, 6) if extra <= max_extra_even)

    for extra in detour_levels:
        for sequence in _enumerate_balanced_detours(base_sequences=base, extra_steps=extra):
            action_sequences.add(sequence)

    sorted_actions = sorted(
        action_sequences,
        key=lambda seq: (len(seq), _turn_count(seq), seq),
    )

    routes: list[RouteCandidate] = []
    for index, actions in enumerate(sorted_actions[: max(1, int(max_routes))]):
        net_dx, net_dy = _net_displacement(actions)
        route = RouteCandidate(
            route_id=f"route_{index:03d}",
            actions=actions,
            length=len(actions),
            net_dx=net_dx,
            net_dy=net_dy,
            first_action=(actions[0] if actions else None),
            turn_count=_turn_count(actions),
            axis_order=_axis_order(actions),
            waypoints=_waypoints(actions),
            score_components={
                "length": float(len(actions)),
                "turn_count": float(_turn_count(actions)),
                "detour_steps": float(max(0, len(actions) - shortest)),
            },
        )
        routes.append(route)
    return tuple(routes)


def _enumerate_shortest_interleavings(*, h_steps: int, v_steps: int, h_token: str, v_token: str) -> tuple[tuple[str, ...], ...]:
    if h_steps == 0 and v_steps == 0:
        return (tuple(),)
    if h_steps == 0:
        return (tuple(v_token for _ in range(v_steps)),)
    if v_steps == 0:
        return (tuple(h_token for _ in range(h_steps)),)
    total = h_steps + v_steps
    out: list[tuple[str, ...]] = []
    for h_positions in combinations(range(total), h_steps):
        h_pos = set(h_positions)
        seq = tuple(h_token if i in h_pos else v_token for i in range(total))
        out.append(seq)
    out.sort()
    return tuple(out)


def _enumerate_balanced_detours(*, base_sequences: tuple[tuple[str, ...], ...], extra_steps: int) -> tuple[tuple[str, ...], ...]:
    if extra_steps <= 0 or extra_steps % 2 != 0:
        return tuple()
    pairs_needed = extra_steps // 2
    cancel_pairs = (
        ("LEFT", "RIGHT"),
        ("RIGHT", "LEFT"),
        ("UP", "DOWN"),
        ("DOWN", "UP"),
    )
    current = set(base_sequences)
    for _ in range(pairs_needed):
        nxt: set[tuple[str, ...]] = set()
        for seq in sorted(current):
            for pair in cancel_pairs:
                for pos in range(len(seq) + 1):
                    candidate = seq[:pos] + pair + seq[pos:]
                    nxt.add(candidate)
        current = nxt
    return tuple(sorted(item for item in current if len(item) == len(base_sequences[0]) + extra_steps))


def _turn_count(actions: tuple[str, ...]) -> int:
    turns = 0
    prev_axis = None
    for action in actions:
        axis = "H" if action in {"LEFT", "RIGHT"} else "V"
        if prev_axis is not None and axis != prev_axis:
            turns += 1
        prev_axis = axis
    return turns


def _axis_order(actions: tuple[str, ...]) -> str:
    if not actions:
        return "NONE"
    axes = ["H" if action in {"LEFT", "RIGHT"} else "V" for action in actions]
    unique = tuple(dict.fromkeys(axes))
    if unique == ("H",):
        return "H_ONLY"
    if unique == ("V",):
        return "V_ONLY"
    if unique[:2] == ("H", "V") and all(a == "H" for a in axes[: axes.index("V")]):
        return "H_FIRST"
    if unique[:2] == ("V", "H") and all(a == "V" for a in axes[: axes.index("H")]):
        return "V_FIRST"
    return "MIXED"


def _waypoints(actions: tuple[str, ...]) -> tuple[tuple[int, int], ...]:
    x = 0
    y = 0
    points: list[tuple[int, int]] = [(x, y)]
    for action in actions:
        if action == "LEFT":
            x -= 1
        elif action == "RIGHT":
            x += 1
        elif action == "UP":
            y -= 1
        elif action == "DOWN":
            y += 1
        points.append((x, y))
    return tuple(points)


def _net_displacement(actions: tuple[str, ...]) -> tuple[int, int]:
    x = 0
    y = 0
    for action in actions:
        if action == "LEFT":
            x -= 1
        elif action == "RIGHT":
            x += 1
        elif action == "UP":
            y -= 1
        elif action == "DOWN":
            y += 1
    return x, y
