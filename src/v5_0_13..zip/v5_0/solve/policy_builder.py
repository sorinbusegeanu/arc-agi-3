from __future__ import annotations

from v5_0.contact.frame_tracker import track_avatar_bbox_in_frame
from v5_0.route.trajectory_enumerator import RouteCandidate, enumerate_routes_between_points


def build_solve_policy_for_target(
    selected_avatar_result,
    target_poi,
    current_frame,
    step_budget_remaining,
) -> tuple[str, ...]:
    candidates = _build_candidate_solve_routes(
        selected_avatar_result=selected_avatar_result,
        target_poi=target_poi,
        current_frame=current_frame,
        step_budget_remaining=step_budget_remaining,
        route_hints=None,
    )
    return tuple(candidates[0].actions) if candidates else tuple()


def build_adaptive_policy_for_target(
    selected_avatar_result,
    target_poi,
    current_frame,
    step_budget_remaining,
    route_hints=None,
) -> tuple[RouteCandidate, ...]:
    return _build_candidate_solve_routes(
        selected_avatar_result=selected_avatar_result,
        target_poi=target_poi,
        current_frame=current_frame,
        step_budget_remaining=step_budget_remaining,
        route_hints=route_hints,
    )


def _build_candidate_solve_routes(
    *,
    selected_avatar_result,
    target_poi,
    current_frame,
    step_budget_remaining,
    route_hints=None,
) -> tuple[RouteCandidate, ...]:
    budget = max(0, int(step_budget_remaining))
    if budget <= 0 or target_poi is None:
        return tuple()

    avatar_bbox = track_avatar_bbox_in_frame(
        current_frame,
        getattr(selected_avatar_result, "selected_bbox", None),
        None,
    )
    if avatar_bbox is None:
        avatar_center = tuple(getattr(selected_avatar_result, "selected_center", (0.0, 0.0)) or (0.0, 0.0))
    else:
        avatar_center = ((avatar_bbox[0] + avatar_bbox[2]) / 2.0, (avatar_bbox[1] + avatar_bbox[3]) / 2.0)

    target_center = tuple(getattr(target_poi, "center", avatar_center))
    avatar_bbox_for_scale = avatar_bbox or getattr(selected_avatar_result, "selected_bbox", None)
    target_bbox_for_scale = getattr(target_poi, "bbox", None)
    step_scale = _estimate_action_step_scale(avatar_bbox_for_scale, target_bbox_for_scale)
    avatar_action_center = (float(avatar_center[0]) / float(step_scale), float(avatar_center[1]) / float(step_scale))
    target_action_center = (float(target_center[0]) / float(step_scale), float(target_center[1]) / float(step_scale))
    dx = int(round(target_action_center[0] - avatar_action_center[0]))
    dy = int(round(target_action_center[1] - avatar_action_center[1]))
    shortest = abs(dx) + abs(dy)
    enumerated = tuple(
        _truncate_route(route, budget)
        for route in enumerate_routes_between_points(
            start_center=avatar_action_center,
            target_center=target_action_center,
            max_extra_steps=2,
            max_routes=16,
        )
    )
    route_candidates = [
        route
        for route in enumerated
        if (tuple(route.actions) or route.length == 0) and _route_is_sane(route, dx=dx, dy=dy, budget=budget)
    ]
    if shortest > budget or shortest > 12:
        route_candidates = list(_exploratory_routes(budget))
    if not route_candidates:
        route_candidates = [RouteCandidate("route_fallback", tuple(), 0, 0, 0, None, 0, "NONE", ((0, 0),), {"length": 0.0, "turn_count": 0.0, "detour_steps": 0.0})]
    hint_candidates: list[RouteCandidate] = []
    for hint in tuple(route_hints or ()):
        if not isinstance(hint, dict):
            continue
        actions = tuple(str(item) for item in tuple(hint.get("actions", ())))
        suggested_prefix = int(hint.get("suggested_prefix_length", len(actions)))
        if not actions:
            continue
        prefix = tuple(actions[: max(1, min(len(actions), suggested_prefix, budget))])
        if prefix:
            hint_candidates.append(_route_from_actions(route_id=f"hint:{hint.get('route_id', 'unknown')}", actions=prefix))
    combined = tuple(hint_candidates) + tuple(route_candidates)
    seen: set[tuple[str, ...]] = set()
    ordered_routes: list[RouteCandidate] = []
    for route in combined:
        key = tuple(route.actions)
        if key in seen:
            continue
        seen.add(key)
        ordered_routes.append(route)
    ordered_routes.sort(key=lambda route: (int(route.length), int(route.turn_count), tuple(route.actions)))

    hint_keys = {tuple(route.actions) for route in hint_candidates}
    hint_front = [route for route in ordered_routes if tuple(route.actions) in hint_keys]
    non_hint = [route for route in ordered_routes if tuple(route.actions) not in hint_keys]
    ordered_routes = hint_front + non_hint
    return tuple(ordered_routes)


def _route_from_actions(*, route_id: str, actions: tuple[str, ...]) -> RouteCandidate:
    dx = 0
    dy = 0
    turns = 0
    prev_axis = None
    points = [(0, 0)]
    for action in actions:
        axis = "H" if action in {"LEFT", "RIGHT"} else "V"
        if prev_axis is not None and axis != prev_axis:
            turns += 1
        prev_axis = axis
        if action == "LEFT":
            dx -= 1
        elif action == "RIGHT":
            dx += 1
        elif action == "UP":
            dy -= 1
        elif action == "DOWN":
            dy += 1
        points.append((dx, dy))
    return RouteCandidate(
        route_id=str(route_id),
        actions=tuple(actions),
        length=int(len(actions)),
        net_dx=int(dx),
        net_dy=int(dy),
        first_action=(actions[0] if actions else None),
        turn_count=int(turns),
        axis_order="NONE" if not actions else ("H_ONLY" if all(a in {"LEFT", "RIGHT"} for a in actions) else ("V_ONLY" if all(a in {"UP", "DOWN"} for a in actions) else "MIXED")),
        waypoints=tuple(points),
        score_components={"length": float(len(actions)), "turn_count": float(turns)},
    )


def _truncate_route(route: RouteCandidate, budget: int) -> RouteCandidate:
    actions = tuple(route.actions[: max(0, int(budget))])
    return _route_from_actions(route_id=str(route.route_id), actions=actions)


def _estimate_action_step_scale(avatar_bbox, target_bbox) -> int:
    sizes = []
    for bbox in (avatar_bbox, target_bbox):
        if bbox is None:
            continue
        w = max(1, int(bbox[2]) - int(bbox[0]) + 1)
        h = max(1, int(bbox[3]) - int(bbox[1]) + 1)
        sizes.append((w + h) / 2.0)
    if not sizes:
        return 8
    return max(1, int(round(sum(sizes) / len(sizes))))


def _route_is_sane(route: RouteCandidate, *, dx: int, dy: int, budget: int) -> bool:
    actions = tuple(route.actions)
    if len(actions) > int(budget):
        return False
    if len(actions) > 14:
        return False
    first = actions[0] if actions else None
    if first == "LEFT" and dx > 0:
        return False
    if first == "RIGHT" and dx < 0:
        return False
    if first == "UP" and dy > 0:
        return False
    if first == "DOWN" and dy < 0:
        return False
    if len(actions) >= 2 and (actions[0], actions[1]) in {("LEFT", "RIGHT"), ("RIGHT", "LEFT"), ("UP", "DOWN"), ("DOWN", "UP")}:
        return False
    return True


def _exploratory_routes(budget: int) -> tuple[RouteCandidate, ...]:
    probes = [
        ("RIGHT",),
        ("DOWN",),
        ("RIGHT", "RIGHT"),
        ("DOWN", "DOWN"),
        ("RIGHT", "DOWN"),
        ("DOWN", "RIGHT"),
    ]
    out: list[RouteCandidate] = []
    for idx, seq in enumerate(probes):
        actions = tuple(seq[: max(0, min(len(seq), int(budget)))])
        if not actions:
            continue
        route = _route_from_actions(route_id=f"explore_{idx:03d}", actions=actions)
        route.score_components["reason_probe"] = 1.0
        out.append(route)
    return tuple(out)
