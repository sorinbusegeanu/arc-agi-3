from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations

MAX_SHORTEST_PATH = 12
MAX_FINAL_ROUTE = 14


@dataclass(frozen=True)
class RouteCandidate:
    route_id: str
    actions: tuple[str, ...]
    length: int
    net_dx: int
    net_dy: int
    first_action: str | None
    turn_count: int
    axis_order: str
    waypoints: tuple[tuple[int, int], ...]
    score_components: dict[str, float]


def enumerate_routes_between_points(
    start_center,
    target_center,
    max_extra_steps=6,
    max_routes=32,
) -> tuple[RouteCandidate, ...]:
    sx = float(start_center[0]) if start_center is not None else 0.0
    sy = float(start_center[1]) if start_center is not None else 0.0
    tx = float(target_center[0]) if target_center is not None else sx
    ty = float(target_center[1]) if target_center is not None else sy

    dx = int(round(tx - sx))
    dy = int(round(ty - sy))
    h_token = "RIGHT" if dx >= 0 else "LEFT"
    v_token = "DOWN" if dy >= 0 else "UP"
    h_steps = abs(dx)
    v_steps = abs(dy)
    shortest = h_steps + v_steps
    if shortest == 0:
        return (
            RouteCandidate(
                route_id="route_000",
                actions=tuple(),
                length=0,
                net_dx=0,
                net_dy=0,
                first_action=None,
                turn_count=0,
                axis_order="NONE",
                waypoints=((0, 0),),
                score_components={"length": 0.0, "turn_count": 0.0, "detour_steps": 0.0},
            ),
        )

    action_sequences: set[tuple[str, ...]] = set()
    base = _enumerate_shortest_interleavings(h_steps=h_steps, v_steps=v_steps, h_token=h_token, v_token=v_token)
    action_sequences.update(base)

    # Geometry-aware bounded generation: shortest first, then tiny near-shortest/one-turn variants.
    if shortest > MAX_SHORTEST_PATH:
        base = tuple(sorted(base, key=lambda seq: (_turn_count(seq), seq))[:4])
    action_sequences.update(base)

    if shortest <= MAX_SHORTEST_PATH:
        near_shortest: set[tuple[str, ...]] = set()
        max_extra = max(0, min(int(max_extra_steps), 2))
        if max_extra >= 2 and shortest + 2 <= MAX_FINAL_ROUTE:
            for seq in base:
                near_shortest.update(_enumerate_one_turn_variants(seq))
        for seq in near_shortest:
            if _is_plausible_route(seq, dx=dx, dy=dy):
                action_sequences.add(seq)

    sorted_actions = sorted(
        (seq for seq in action_sequences if len(seq) <= MAX_FINAL_ROUTE and _is_plausible_route(seq, dx=dx, dy=dy)),
        key=lambda seq: (len(seq), _turn_count(seq), _monotonic_progress_penalty(seq, dx, dy), seq),
    )

    routes: list[RouteCandidate] = []
    route_cap = max(1, min(int(max_routes), 32))
    for index, actions in enumerate(sorted_actions[: route_cap]):
        net_dx, net_dy = _net_displacement(actions)
        route = RouteCandidate(
            route_id=f"route_{index:03d}",
            actions=actions,
            length=len(actions),
            net_dx=net_dx,
            net_dy=net_dy,
            first_action=(actions[0] if actions else None),
            turn_count=_turn_count(actions),
            axis_order=_axis_order(actions),
            waypoints=_waypoints(actions),
            score_components={
                "length": float(len(actions)),
                "turn_count": float(_turn_count(actions)),
                "detour_steps": float(max(0, len(actions) - shortest)),
                "monotonic_penalty": float(_monotonic_progress_penalty(actions, dx, dy)),
            },
        )
        routes.append(route)
    return tuple(routes)


def _enumerate_shortest_interleavings(*, h_steps: int, v_steps: int, h_token: str, v_token: str) -> tuple[tuple[str, ...], ...]:
    if h_steps == 0 and v_steps == 0:
        return (tuple(),)
    if h_steps == 0:
        return (tuple(v_token for _ in range(v_steps)),)
    if v_steps == 0:
        return (tuple(h_token for _ in range(h_steps)),)
    total = h_steps + v_steps
    out: list[tuple[str, ...]] = []
    for h_positions in combinations(range(total), h_steps):
        h_pos = set(h_positions)
        seq = tuple(h_token if i in h_pos else v_token for i in range(total))
        out.append(seq)
    out.sort()
    return tuple(out)


def _enumerate_one_turn_variants(seq: tuple[str, ...]) -> tuple[tuple[str, ...], ...]:
    if len(seq) < 2:
        return tuple()
    variants: set[tuple[str, ...]] = set()
    for i in range(1, min(len(seq), 4)):
        left = seq[:i]
        right = seq[i:]
        if not left or not right:
            continue
        # swap one early axis chunk to provide bounded alternatives
        variants.add(right[:1] + left + right[1:])
    return tuple(sorted(variants))


def _turn_count(actions: tuple[str, ...]) -> int:
    turns = 0
    prev_axis = None
    for action in actions:
        axis = "H" if action in {"LEFT", "RIGHT"} else "V"
        if prev_axis is not None and axis != prev_axis:
            turns += 1
        prev_axis = axis
    return turns


def _axis_order(actions: tuple[str, ...]) -> str:
    if not actions:
        return "NONE"
    axes = ["H" if action in {"LEFT", "RIGHT"} else "V" for action in actions]
    unique = tuple(dict.fromkeys(axes))
    if unique == ("H",):
        return "H_ONLY"
    if unique == ("V",):
        return "V_ONLY"
    if unique[:2] == ("H", "V") and all(a == "H" for a in axes[: axes.index("V")]):
        return "H_FIRST"
    if unique[:2] == ("V", "H") and all(a == "V" for a in axes[: axes.index("H")]):
        return "V_FIRST"
    return "MIXED"


def _waypoints(actions: tuple[str, ...]) -> tuple[tuple[int, int], ...]:
    x = 0
    y = 0
    points: list[tuple[int, int]] = [(x, y)]
    for action in actions:
        if action == "LEFT":
            x -= 1
        elif action == "RIGHT":
            x += 1
        elif action == "UP":
            y -= 1
        elif action == "DOWN":
            y += 1
        points.append((x, y))
    return tuple(points)


def _net_displacement(actions: tuple[str, ...]) -> tuple[int, int]:
    x = 0
    y = 0
    for action in actions:
        if action == "LEFT":
            x -= 1
        elif action == "RIGHT":
            x += 1
        elif action == "UP":
            y -= 1
        elif action == "DOWN":
            y += 1
    return x, y


def _is_plausible_route(actions: tuple[str, ...], *, dx: int, dy: int) -> bool:
    if not actions:
        return dx == 0 and dy == 0
    if len(actions) > MAX_FINAL_ROUTE:
        return False
    net = _net_displacement(actions)
    if net != (dx, dy):
        return False
    # avoid anti-target first move unless no movement in that axis
    first = actions[0]
    if dx > 0 and first == "LEFT":
        return False
    if dx < 0 and first == "RIGHT":
        return False
    if dy > 0 and first == "UP":
        return False
    if dy < 0 and first == "DOWN":
        return False
    # avoid early oscillation
    if len(actions) >= 2:
        a0, a1 = actions[0], actions[1]
        if (a0, a1) in {("LEFT", "RIGHT"), ("RIGHT", "LEFT"), ("UP", "DOWN"), ("DOWN", "UP")}:
            return False
    return True


def _monotonic_progress_penalty(actions: tuple[str, ...], dx: int, dy: int) -> int:
    x = 0
    y = 0
    goal = abs(dx) + abs(dy)
    penalty = 0
    best = goal
    for action in actions:
        if action == "LEFT":
            x -= 1
        elif action == "RIGHT":
            x += 1
        elif action == "UP":
            y -= 1
        elif action == "DOWN":
            y += 1
        dist = abs(dx - x) + abs(dy - y)
        if dist > best:
            penalty += 1
        best = min(best, dist)
    return penalty
