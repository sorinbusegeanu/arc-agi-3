from __future__ import annotations

from typing import List

from codex_baseline_v2.shared.latent_state import active_latent_states
from codex_baseline_v2.shared.plan_records import PlannerBeliefStateV1, SkillSpecV1
from codex_baseline_v2.shared.schemas import BlackboardStateV2
from codex_baseline_v2.planning.plan_memory import PlanMemoryStateV1, cluster_ledger_map, cluster_key_for_skill


def _skill_target_ref(skill: SkillSpecV1) -> str:
    for ref in skill.precondition_ids:
        if ref.startswith("poi:") or ref.startswith("trigger_zone:"):
            return ref
    return skill.skill_id


def _probe_local_relation(ax: int, ay: int, bx: int, by: int) -> str:
    if ax == bx and ay == by:
        return "exact"
    distance = abs(ax - bx) + abs(ay - by)
    if distance <= 2:
        return "immediate"
    if (ax == bx or ay == by) and distance <= 8:
        return "immediate"
    if distance <= 5:
        return "immediate"
    if distance <= 10 or ax == bx or ay == by:
        return "cluster"
    return "distant"


def _diversify_movement_clusters(skill_ids: List[str], skills_by_id: dict[str, SkillSpecV1], minimum_clusters: int = 4) -> List[str]:
    diversified: List[str] = []
    overflow: List[str] = []
    used_clusters = set()
    distinct_clusters = {
        cluster_key_for_skill(skills_by_id[skill_id])
        for skill_id in skill_ids
        if skill_id in skills_by_id and cluster_key_for_skill(skills_by_id[skill_id]) is not None
    }
    target_cluster_count = min(max(1, minimum_clusters), len(distinct_clusters))
    for skill_id in skill_ids:
        skill = skills_by_id.get(skill_id)
        cluster_key = cluster_key_for_skill(skill) if skill is not None else None
        if cluster_key is None:
            diversified.append(skill_id)
            continue
        if cluster_key not in used_clusters and len(used_clusters) < target_cluster_count:
            used_clusters.add(cluster_key)
            diversified.append(skill_id)
        else:
            overflow.append(skill_id)
    return diversified + overflow


def _movement_sort_key(skill: SkillSpecV1) -> tuple[float, float, float, str]:
    cluster_key = cluster_key_for_skill(skill) or ""
    area_prefix = cluster_key.rsplit("|", 2)[0] if "|" in cluster_key else ""
    return (
        float(skill.total_attempt_count == 0 and skill.failure_count == 0),
        -float(skill.failure_count),
        -float(skill.total_attempt_count),
        f"{area_prefix}:{skill.skill_id}",
    )


def _dedup_candidate_subgoals(blackboard: BlackboardStateV2) -> List[str]:
    if blackboard.dependency_graph is None:
        return []
    kept: List[str] = []
    seen_targets = set()
    for subgoal in blackboard.dependency_graph.subgoals:
        if subgoal.status not in {"candidate", "enabled", "blocked"}:
            continue
        if subgoal.subgoal_id.startswith("subgoal:reach:poi:"):
            target_ref = subgoal.subgoal_id[len("subgoal:reach:") :]
            if target_ref in seen_targets:
                continue
            seen_targets.add(target_ref)
            kept.append(subgoal.subgoal_id)
            continue
        if subgoal.subgoal_id.startswith("subgoal:enable_route:latent:"):
            continue
        kept.append(subgoal.subgoal_id)
    concrete = [subgoal_id for subgoal_id in kept if ":poi:" in subgoal_id or "trigger_zone:" in subgoal_id]
    return concrete[:8]


def _filtered_candidate_skill_ids(
    skills: List[SkillSpecV1],
    plan_memory: PlanMemoryStateV1 | None = None,
    force_full_inventory: bool = False,
    reachable_frontier_ids: List[str] | None = None,
) -> List[str]:
    concrete = []
    abstract = []
    seen_bindings = set()
    skills_by_id = {skill.skill_id: skill for skill in skills}
    for skill in skills:
        if not skill.active:
            continue
        binding = _skill_target_ref(skill)
        row = (skill.skill_id, skill.total_attempt_count > 0, binding.startswith("poi:") or binding.startswith("trigger_zone:"))
        if row[2]:
            dedup_key = (skill.skill_type, binding)
            if dedup_key in seen_bindings:
                continue
            seen_bindings.add(dedup_key)
            concrete.append(skill.skill_id)
        else:
            abstract.append(skill.skill_id)
    local_probe_failures = any(
        skill.skill_type == "probe_hidden_trigger" and skill.latest_termination_reason_this_round == "contact_no_effect"
        for skill in skills
    )
    failure_reasons = {"contact_no_effect", "contact_no_reach", "route_stall", "blocked", "invalid_target", "no_progress", "unreachable_now"}
    recovery_mode = force_full_inventory or any(skill.latest_termination_reason_this_round in failure_reasons for skill in skills)
    widen_after_probe_failure = bool(plan_memory is not None and plan_memory.failed_cluster_keys_this_round)
    failed_probe_coords = [
        (skill.target_x_this_round, skill.target_y_this_round)
        for skill in skills
        if skill.skill_type == "probe_hidden_trigger"
        and skill.latest_termination_reason_this_round == "contact_no_effect"
        and skill.target_x_this_round is not None
        and skill.target_y_this_round is not None
    ]
    historical_probe_coords = [
        (skill.target_x_this_round, skill.target_y_this_round, int(skill.historical_contact_no_effect_count))
        for skill in skills
        if skill.skill_type == "probe_hidden_trigger"
        and skill.target_x_this_round is not None
        and skill.target_y_this_round is not None
        and skill.historical_contact_no_effect_count > 0
    ]
    cluster_ledger = cluster_ledger_map(plan_memory)
    probe_rows = []
    for skill_id in [skill_id for skill_id in concrete if ":probe_hidden_trigger:" in skill_id]:
        parts = skill_id.split(":")
        try:
            sx, sy = int(parts[-2]), int(parts[-1])
        except (TypeError, ValueError):
            probe_rows.append({"skill_id": skill_id, "sx": None, "sy": None, "local_hits": 0, "historical_hits": 0, "novelty": 999})
            continue
        local_hits = 0
        exact_hit = False
        nearest_failed_distance = 9999
        for fx, fy in failed_probe_coords:
            distance = abs(int(sx) - int(fx)) + abs(int(sy) - int(fy))
            nearest_failed_distance = min(nearest_failed_distance, distance)
            relation = _probe_local_relation(int(sx), int(sy), int(fx), int(fy))
            if relation == "exact":
                exact_hit = True
                break
            if relation == "immediate":
                local_hits += 2
            elif relation == "cluster":
                local_hits += 1
        if exact_hit:
            continue
        if local_hits >= 2:
            continue
        historical_hits = 0
        for fx, fy, count in historical_probe_coords:
            relation = _probe_local_relation(int(sx), int(sy), int(fx), int(fy))
            if relation in {"immediate", "cluster"}:
                historical_hits += count
        if historical_hits >= 3:
            continue
        cluster_key = cluster_key_for_skill(skills_by_id[skill_id]) if skill_id in skills_by_id else None
        if cluster_key is not None:
            cluster_entry = cluster_ledger.get(cluster_key)
            if plan_memory is not None and skills_by_id[skill_id].skill_type == "probe_hidden_trigger" and int(plan_memory.excluded_cluster_cooldowns.get(cluster_key, 0)) > 0:
                continue
            if cluster_entry is not None and cluster_entry.locally_exhausted:
                continue
        novelty = nearest_failed_distance if nearest_failed_distance != 9999 else 999
        probe_rows.append({"skill_id": skill_id, "sx": int(sx), "sy": int(sy), "local_hits": local_hits, "historical_hits": historical_hits, "novelty": novelty})
    if local_probe_failures and not widen_after_probe_failure:
        has_distant_probe = False
        for row in probe_rows:
            sx = row["sx"]
            sy = row["sy"]
            if sx is None or sy is None:
                continue
            if all(_probe_local_relation(sx, sy, int(fx), int(fy)) == "distant" for fx, fy in failed_probe_coords):
                has_distant_probe = True
                break
        if has_distant_probe:
            probe_rows = [
                row for row in probe_rows
                if row["sx"] is None or all(
                    _probe_local_relation(int(row["sx"]), int(row["sy"]), int(fx), int(fy)) == "distant"
                    for fx, fy in failed_probe_coords
                )
            ]
    probe_cap = len(probe_rows) if recovery_mode else (8 if widen_after_probe_failure else (2 if local_probe_failures else 4))
    probe_rows.sort(key=lambda row: (row["local_hits"], row["historical_hits"], -int(row["novelty"]), row["skill_id"]))
    probe = [row["skill_id"] for row in probe_rows[:probe_cap]]
    reachable_set = set(reachable_frontier_ids or [])
    movement_rows = []
    for skill_id in [skill_id for skill_id in concrete if ":go_to_region:" in skill_id]:
        skill = skills_by_id.get(skill_id)
        if skill is None:
            continue
        target_ref = _skill_target_ref(skill)
        if recovery_mode:
            if reachable_set and target_ref not in reachable_set:
                continue
            movement_rows.append(skill_id)
        else:
            movement_rows.append(skill_id)
    movement_rows.sort(key=lambda skill_id: _movement_sort_key(skills_by_id[skill_id]), reverse=True)
    movement_cap = len(movement_rows) if recovery_mode else 4
    other_cap = len([skill_id for skill_id in concrete if skill_id not in set(probe + movement_rows)]) if recovery_mode else 2
    abstract_cap = 0 if recovery_mode else 2
    movement = _diversify_movement_clusters(movement_rows[:movement_cap], skills_by_id, minimum_clusters=6 if recovery_mode else 4)
    other_concrete = [skill_id for skill_id in concrete if skill_id not in set(probe + movement)][:other_cap]
    if recovery_mode:
        result = probe + movement + other_concrete
        returned = set(result)
        omitted_fresh = [
            (skill.skill_id, _skill_target_ref(skill))
            for skill in skills
            if skill.skill_type == "go_to_region"
            and skill.active
            and skill.total_attempt_count == 0
            and skill.failure_count == 0
            and ((_skill_target_ref(skill) in reachable_set) if reachable_set else True)
            and skill.skill_id not in returned
        ]
        if omitted_fresh:
            payload = ",".join(f"{skill_id}:{target_ref}" for skill_id, target_ref in omitted_fresh[:12])
            print(f"[v2][planner][warning] recovery_mode_omitted_fresh_pois omission_reason=movement_filter ids={payload}")
        return result
    total_cap = 12
    return (probe + movement + other_concrete + abstract[:abstract_cap])[:total_cap]


def build_planner_belief_state(
    blackboard: BlackboardStateV2,
    skills: List[SkillSpecV1],
    candidate_skills: List[SkillSpecV1] | None = None,
    plan_memory_refs: List[str] | None = None,
    plan_memory: PlanMemoryStateV1 | None = None,
    force_full_inventory: bool = False,
) -> PlannerBeliefStateV1:
    active = active_latent_states(blackboard.latent_states, min_confidence=0.6)
    uncertain = [state for state in blackboard.latent_states if state.current_value is None or state.confidence < 0.6]
    candidate_subgoals = _dedup_candidate_subgoals(blackboard)
    reachable_frontier_ids = [record.poi_id for record in blackboard.reachability_table if record.status in {"reachable", "reachable_now", "uncertain"}]
    return PlannerBeliefStateV1(
        schema_version="v2.3.2",
        current_area_id=blackboard.area_table[0].area_id if blackboard.area_table else None,
        current_avatar_track_id=blackboard.avatar_track_table[0].track_id if blackboard.avatar_track_table else None,
        candidate_subgoal_ids=candidate_subgoals,
        active_latent_state_ids=[state.latent_state_id for state in active],
        uncertain_latent_state_ids=[state.latent_state_id for state in uncertain],
        reachable_frontier_ids=reachable_frontier_ids,
        candidate_skill_ids=_filtered_candidate_skill_ids(
            candidate_skills if candidate_skills is not None else skills,
            plan_memory=plan_memory,
            force_full_inventory=force_full_inventory,
            reachable_frontier_ids=reachable_frontier_ids,
        ),
        plan_memory_refs=list(plan_memory_refs or []),
    )
