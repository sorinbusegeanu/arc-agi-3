from __future__ import annotations

import json
import multiprocessing as mp
import os
import time
from dataclasses import replace
from typing import Any, Dict, List, Optional

from codex_baseline_v2.analyst.analyst import analyze_episodes, analyze_episodes_parallel
from codex_baseline_v2.controller.controller import select_instruction
from codex_baseline_v2.executor.option_executor import execute_option, instruction_from_skill, skill_record_from_execution
from codex_baseline_v2.executor.online_executor import run_offline_local_execution, run_online_executions_parallel
from codex_baseline_v2.learning.ranking_inference import rank_mechanics, rank_options
from codex_baseline_v2.memory.store import (
    append_round_report,
    load_blackboard_typed,
    save_blackboard,
    save_event_table,
    save_interventions,
    save_mechanic_hypotheses,
    save_navigation_graph,
    save_world_model_archive,
)
from codex_baseline_v2.memory.graph_store import save_graph_state
from codex_baseline_v2.planning.hierarchical_planner import PLANNER_BUILD_ID, PLANNER_MODULE_PATH, plan_best_first
from codex_baseline_v2.planning.plan_memory import load_plan_memory, plan_memory_refs as build_plan_memory_refs, reconcile_plan_memory, save_plan_memory
from codex_baseline_v2.planning.planner_state_builder import build_planner_belief_state
from codex_baseline_v2.planning.skill_inducer import induce_skills
from codex_baseline_v2.planning.skill_library import candidate_skills, load_skill_library, reconcile_skill_library, save_skill_library
from codex_baseline_v2.runtime.environment_session import EnvironmentSessionV2
from codex_baseline_v2.runtime.session_manager import SessionManagerV2
from codex_baseline_v2.runtime.trajectory_collector import CollectionConfigV2, TrajectoryCollectorV2
from codex_baseline_v2.shared.config import V2Config
from codex_baseline_v2.shared.logging_utils import log_event
from codex_baseline_v2.shared.metrics import RoundMetricsV2, compute_round_metrics
from codex_baseline_v2.shared.plan_records import PlanResultV1
from codex_baseline_v2.shared.storage import StoragePathsV2
from codex_baseline_v2.shared.schemas import BlackboardStateV2, ControllerInstructionV2, DecisionRecordV2, ExecutorOutcomeV2, SCHEMA_VERSION, TrajectoryEpisodeV2
from codex_baseline_v2.trajectory_analysis.analyzer import analyze_trajectories
from codex_baseline_v2.trajectory_analysis.avatar_hypothesis_debug import export_avatar_debug


def _log_stage_start(game_id: str, round_id: int, stage: str) -> float:
    started_at = time.perf_counter()
    print(f"[v2] stage_start game_id={game_id} round_id={round_id} stage={stage}", flush=True)
    return started_at


def _log_stage_stop(game_id: str, round_id: int, stage: str, started_at: float, stage_timings: Dict[str, float]) -> None:
    duration = time.perf_counter() - started_at
    stage_timings[stage] = duration
    print(f"[v2] stage_stop game_id={game_id} round_id={round_id} stage={stage} duration_s={round(duration, 3)}", flush=True)


def _extract_tag(text: Optional[str], key: str) -> Optional[str]:
    if not text:
        return None
    prefix = key + "="
    for token in text.split():
        if token.startswith(prefix):
            return token[len(prefix):]
    return None


def _export_debug_table(storage: StoragePathsV2, game_id: str, round_id: int, filename: str, payload: object) -> None:
    path = os.path.join(storage.category_path(game_id, round_id, "exports"), filename)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, sort_keys=True)


def _save_plan_memory(storage: StoragePathsV2, game_id: str, belief, nodes, result, plan_memory_state=None, failure_payload: Optional[Dict[str, Any]] = None) -> None:
    game_root = storage.game_root(game_id)
    plans_path = os.path.join(game_root, "plans.json")
    failures_path = os.path.join(game_root, "plan_failures.json")
    _validate_finalized_plan_nodes(nodes)
    payload = {
        "schema_version": "v2.3.2",
        "planner_module_path": PLANNER_MODULE_PATH,
        "planner_build_id": PLANNER_BUILD_ID,
        "export_finalized": True,
        "belief_state": belief.to_dict() if belief is not None else None,
        "plan_nodes": [node.to_dict() for node in (nodes or [])],
        "plan_result": result.to_dict() if result is not None else None,
        "plan_memory_state": plan_memory_state.to_dict() if plan_memory_state is not None else None,
    }
    with open(plans_path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, sort_keys=True)
    _verify_plan_artifact(plans_path)
    if failure_payload is not None:
        failures = []
        if os.path.exists(failures_path):
            with open(failures_path, "r", encoding="utf-8") as handle:
                loaded = json.load(handle)
            failures = list(loaded.get("failures", []))
        failures.append(failure_payload)
        with open(failures_path, "w", encoding="utf-8") as handle:
            json.dump({"schema_version": "v2.3.2", "failures": failures}, handle, sort_keys=True)


def _save_plan_pass_debug(storage: StoragePathsV2, game_id: str, round_id: int, episode_idx: int, belief, nodes, result, outcome) -> None:
    path = os.path.join(storage.category_path(game_id, round_id, "exports"), f"plan_pass_{episode_idx:03d}.json")
    _validate_finalized_plan_nodes(nodes)
    payload = {
        "schema_version": "v2.4.0",
        "planner_module_path": PLANNER_MODULE_PATH,
        "planner_build_id": PLANNER_BUILD_ID,
        "export_finalized": True,
        "episode_idx": episode_idx,
        "belief_state": belief.to_dict() if belief is not None else None,
        "plan_nodes": [node.to_dict() for node in (nodes or [])],
        "plan_result": result.to_dict() if result is not None else None,
        "execution_outcome": outcome.to_dict() if outcome is not None else None,
    }
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, sort_keys=True)


def _validate_finalized_plan_nodes(nodes) -> None:
    if nodes is None:
        return
    non_root = [node for node in nodes if getattr(node, "plan_node_id", "") != "plan_node:root"]
    if not non_root:
        return
    if not any(node.pre_filter_rank_position is not None for node in non_root):
        raise RuntimeError("artifact-integrity-error: planner returned non-finalized plan nodes")
    for node in non_root:
        if node.blocked and not node.blocking_reason_codes:
            raise RuntimeError("artifact-integrity-error: blocked plan node missing blocking_reason_codes")
        if not node.blocked and node.surviving_unblocked_candidate_count <= 0:
            raise RuntimeError("artifact-integrity-error: unblocked plan node missing surviving_unblocked_candidate_count")


def _verify_plan_artifact(path: str) -> None:
    with open(path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)
    nodes = list(payload.get("plan_nodes", []))
    non_root = [node for node in nodes if node.get("plan_node_id") != "plan_node:root"]
    if not any(node.get("pre_filter_rank_position") is not None for node in non_root):
        raise RuntimeError("artifact-integrity-error: persisted plans.json missing finalized export fields")


def _save_ranking_records(
    storage: StoragePathsV2,
    game_id: str,
    option_record: Any,
    option_scores: Dict[str, float],
    mechanic_record: Any,
    mechanic_scores: Dict[str, float],
) -> None:
    game_root = storage.game_root(game_id)
    option_applied = bool(option_record is not None and option_scores)
    mechanic_applied = bool(mechanic_record is not None and mechanic_scores)
    with open(os.path.join(game_root, "option_rankings.json"), "w", encoding="utf-8") as handle:
        option_state = "inactive"
        if option_record is not None and option_scores:
            option_state = "applied" if option_record.model_score_map_ref != "live_reconstruction" else "reconstructed"
        json.dump(
            {
                "schema_version": "v2.3.4",
                "state": option_state,
                "applied": option_applied,
                "ranking_record": option_record.to_dict() if option_record is not None else None,
                "score_map": option_scores if option_record is not None else {},
            },
            handle,
            sort_keys=True,
        )
    with open(os.path.join(game_root, "mechanic_rankings.json"), "w", encoding="utf-8") as handle:
        mechanic_state = "inactive"
        if mechanic_record is not None and mechanic_scores:
            mechanic_state = "applied" if mechanic_record.model_score_map_ref != "live_reconstruction" else "reconstructed"
        json.dump(
            {
                "schema_version": "v2.3.4",
                "state": mechanic_state,
                "applied": mechanic_applied,
                "ranking_record": mechanic_record.to_dict() if mechanic_record is not None else None,
                "score_map": mechanic_scores if mechanic_record is not None else {},
            },
            handle,
            sort_keys=True,
        )


def _instruction_has_executable_target(instruction: ControllerInstructionV2) -> bool:
    if instruction.mode in {"random_probe", "unguided_probe", "discriminating_probe"}:
        return True
    trigger_zone_id = _extract_tag(instruction.rationale or "", "trigger_zone_id")
    if trigger_zone_id and instruction.target_geometry is not None:
        return True
    if instruction.target_geometry is not None:
        return True
    if instruction.target_poi_id:
        return True
    return False


def _instruction_trigger_zone_id(instruction: ControllerInstructionV2) -> Optional[str]:
    return _extract_tag(instruction.rationale or "", "trigger_zone_id")


def _choose_structured_fallback_skill(skills, plan_memory_state):
    failed_clusters = set(getattr(plan_memory_state, "failed_cluster_keys_this_round", []) if plan_memory_state is not None else [])
    repeated_trigger_failures = sum(1 for skill in skills if skill.skill_type == "probe_hidden_trigger" and skill.latest_termination_reason_this_round == "contact_no_effect")
    repeated_navigation_failures = sum(1 for skill in skills if skill.skill_type == "go_to_region" and skill.latest_termination_reason_this_round in {"route_stall", "contact_no_reach", "blocked"})
    if repeated_navigation_failures > repeated_trigger_failures:
        for skill in skills:
            if skill.skill_type == "probe_hidden_trigger":
                from codex_baseline_v2.planning.plan_memory import cluster_key_for_skill, cluster_distance
                cluster_key = cluster_key_for_skill(skill)
                if not cluster_key:
                    continue
                if cluster_key in failed_clusters:
                    continue
                if any((cluster_distance(cluster_key, failed) or 99) > 1 for failed in failed_clusters) or not failed_clusters:
                    return "distant_trigger_probe", skill
    for skill in skills:
        if skill.skill_type == "go_to_region" and skill.active and "route_stall" not in skill.failure_mode_labels and "contact_no_reach" not in skill.failure_mode_labels:
            return "navigation_poi", skill
    for skill in skills:
        if skill.skill_type == "probe_hidden_trigger":
            from codex_baseline_v2.planning.plan_memory import cluster_key_for_skill, cluster_distance
            cluster_key = cluster_key_for_skill(skill)
            if not cluster_key:
                continue
            if cluster_key in failed_clusters:
                continue
            if any((cluster_distance(cluster_key, failed) or 99) > 1 for failed in failed_clusters) or not failed_clusters:
                return "distant_trigger_probe", skill
    for skill in skills:
        if skill.skill_type == "go_to_region" and skill.active:
            return "navigation_poi", skill
    for skill in skills:
        if skill.skill_type in {"cross_transition", "return_to_anchor"} and skill.active:
            return "cross_area_exploration", skill
    return None, None


def _measurable_progress(outcome: Optional[ExecutorOutcomeV2]) -> bool:
    if outcome is None:
        return False
    if outcome.reached:
        return True
    progress = list(getattr(outcome, "target_progress", []) or [])
    if progress and max(progress) != min(progress):
        return True
    return any(
        record.distance_decreased
        or record.reached
        or bool(record.event_ids)
        or bool(record.topology_delta_id)
        or record.local_change_magnitude > 0.0
        for record in getattr(outcome, "consequence_records", [])
    )


def _bind_instruction_to_blackboard(instruction: ControllerInstructionV2, blackboard: BlackboardStateV2) -> ControllerInstructionV2:
    if instruction.target_poi_id and instruction.target_geometry is None:
        poi = next((row for row in blackboard.poi_table if row.poi_id == instruction.target_poi_id), None)
        if poi is not None and poi.bbox is not None:
            instruction = replace(instruction, target_geometry=poi.bbox)
    trigger_zone_id = _instruction_trigger_zone_id(instruction)
    if trigger_zone_id and instruction.target_geometry is None:
        zone = next((row for row in blackboard.trigger_zone_table if row.trigger_zone_id == trigger_zone_id), None)
        if zone is not None:
            bbox = zone.bbox
            if bbox is None and zone.cells:
                xs = [cell[0] for cell in zone.cells]
                ys = [cell[1] for cell in zone.cells]
                from codex_baseline_v2.shared.utils import BBox
                bbox = BBox(min(xs), min(ys), max(xs), max(ys))
            if bbox is not None:
                instruction = replace(instruction, target_type="trigger_zone", target_geometry=bbox, target_region=bbox)
    return instruction


def _invalid_pre_execution_outcome(game_id: str, instruction: ControllerInstructionV2) -> tuple[ExecutorOutcomeV2, TrajectoryEpisodeV2]:
    episode_id = f"exec_round{instruction.round_id:03d}_invalid"
    outcome = ExecutorOutcomeV2(
        schema_version=SCHEMA_VERSION,
        game_id=game_id,
        round_id=instruction.round_id,
        instruction_id=instruction.instruction_id,
        instruction_mode=instruction.mode,
        target_poi_id=instruction.target_poi_id,
        target_type=instruction.target_type,
        target_geometry=instruction.target_geometry,
        target_source_round=instruction.target_source_round,
        actions=[],
        target_progress=[],
        reached=False,
        contact=False,
        blocked=False,
        outcome_summary="invalid_target_pre_execution",
        consequence_records=[],
    )
    episode = TrajectoryEpisodeV2(
        schema_version=SCHEMA_VERSION,
        game_id=game_id,
        episode_id=episode_id,
        steps=[],
        done=False,
        win=False,
        seed=None,
        metadata={"mode": instruction.mode, "instruction": instruction.to_dict(), "diagnostic": "invalid_target_pre_execution"},
    )
    return outcome, episode


def _decision_target_invalidated(instruction: Optional[ControllerInstructionV2], outcome: Optional[ExecutorOutcomeV2]) -> bool:
    if instruction is None or outcome is None:
        return False
    trigger_zone_id = _instruction_trigger_zone_id(instruction)
    if trigger_zone_id and instruction.target_geometry is not None:
        return False
    return bool(outcome.outcome_summary in {"invalid_target_pre_execution", "invalid_target"} and not outcome.actions)


def _outcome_score(outcome: Any) -> tuple[float, float, float, float]:
    final_distance = float(outcome.target_progress[-1]) if getattr(outcome, "target_progress", None) else 1e9
    progress_events = sum(
        1.0 for record in getattr(outcome, "consequence_records", []) if record.reached or record.contact or record.distance_decreased
    )
    return (
        1.0 if getattr(outcome, "reached", False) else 0.0,
        1.0 if getattr(outcome, "contact", False) else 0.0,
        progress_events,
        -final_distance,
    )


def _consistent_round_metrics(metrics: RoundMetricsV2, outcomes: List[ExecutorOutcomeV2], controller_modes: List[str]) -> RoundMetricsV2:
    if not outcomes or len(controller_modes) != 1:
        return metrics
    reached = any(outcome.reached for outcome in outcomes)
    contact = any(outcome.contact for outcome in outcomes)
    blocked = any(outcome.blocked for outcome in outcomes)
    route_success_rate = metrics.route_success_rate
    contact_success_rate = metrics.contact_success_rate
    if not reached:
        route_success_rate = 0.0
    if contact and not reached:
        contact_success_rate = max(contact_success_rate, 1.0 / float(max(1, len(controller_modes))))
    if blocked and not reached:
        route_success_rate = 0.0
    return RoundMetricsV2(
        unique_states=metrics.unique_states,
        unique_pois=metrics.unique_pois,
        route_success_rate=route_success_rate,
        useful_change_rate=metrics.useful_change_rate,
        contact_success_rate=contact_success_rate,
    )


def run_autonomous_rounds(cfg: V2Config, env_factory: Any, env_factory_path: Optional[str] = None, workers: int = 1) -> Dict[str, Any]:
    storage = StoragePathsV2(cfg.memory.storage_dir)
    session_mgr = SessionManagerV2(cfg.memory.storage_dir)
    state = session_mgr.init_or_resume(cfg.game_id, resume_if_exists=bool(cfg.runtime.resume_if_exists))

    max_rounds = int(cfg.runtime.max_rounds) if cfg.runtime else cfg.rounds
    effective_workers = max(1, min(int(workers), int(max(cfg.collection.initial_probe_episodes, cfg.collection.directed_probe_episodes))))
    last_report = None
    total_wins = 0
    max_steps_per_game = 0
    episodes_seen = 0
    shared_env = None
    shared_session: Optional[EnvironmentSessionV2] = None
    worker_pool = None
    if effective_workers <= 1:
        shared_env = env_factory()
        shared_session = EnvironmentSessionV2(shared_env, cfg.game_id)
    else:
        worker_pool = mp.get_context("spawn").Pool(processes=effective_workers)
    try:
        for round_id in range(state.round_id, max_rounds):
            print(f"[v2] round_start game_id={cfg.game_id} round_id={round_id}", flush=True)
            round_t0 = time.perf_counter()
            stage_timings: Dict[str, float] = {}
            plan_result = None
            option_record = None
            mechanic_record = None
            option_scores = {}
            mechanic_scores = {}
            storage.ensure_round_dirs(cfg.game_id, round_id)
            session = shared_session
            if session is None:
                env = env_factory()
                session = EnvironmentSessionV2(env, cfg.game_id)
            collector = TrajectoryCollectorV2(
                storage,
                CollectionConfigV2(
                    episodes=cfg.collection.initial_probe_episodes if round_id == 0 else cfg.collection.directed_probe_episodes,
                    max_steps_per_episode=cfg.collection.max_steps_per_episode,
                    max_steps_per_instruction=cfg.collection.max_steps_per_instruction,
                    seed=cfg.collection.seed,
                    action_repeat_limit=cfg.collection.action_repeat_limit,
                    keep_invalid_steps_for_debug=cfg.debug.keep_invalid_steps_for_debug,
                    write_raw_copy=bool(cfg.storage.keep_raw_env_payloads),
                    keep_observations_in_artifacts=bool(cfg.storage.keep_raw_frames),
                    keep_raw_info_in_artifacts=bool(cfg.storage.keep_raw_env_payloads),
                    keep_observation_summaries_in_artifacts=bool(cfg.storage.keep_raw_frames),
                ),
            )
            if round_id == 0:
                t0 = _log_stage_start(cfg.game_id, round_id, "collection")
                if effective_workers > 1 and env_factory_path and cfg.env.env_id and cfg.env.env_root:
                    episodes = collector.collect_round_parallel(
                        env_factory_path=env_factory_path,
                        env_id=cfg.env.env_id,
                        env_root=cfg.env.env_root,
                        mode="random_probe",
                        instruction=None,
                        round_id=round_id,
                        workers=effective_workers,
                        pool=worker_pool,
                    )
                else:
                    episodes = collector.collect_round(session, "random_probe", None, round_id)
                _log_stage_stop(cfg.game_id, round_id, "collection", t0, stage_timings)
                t0 = _log_stage_start(cfg.game_id, round_id, "episode_analysis")
                analyzed = analyze_episodes_parallel(episodes, cfg.analyst, workers=effective_workers, pool=worker_pool)
                _log_stage_stop(cfg.game_id, round_id, "episode_analysis", t0, stage_timings)
                t0 = _log_stage_start(cfg.game_id, round_id, "trajectory_analysis")
                blackboard = analyze_trajectories(analyzed, cfg.trajectory_analysis, round_id=round_id, workers=effective_workers, pool=worker_pool)
                _log_stage_stop(cfg.game_id, round_id, "trajectory_analysis", t0, stage_timings)
                t0 = _log_stage_start(cfg.game_id, round_id, "artifact_write")
                collector.write_artifacts(cfg.game_id, round_id, analyzed)
                if cfg.debug.export_avatar_candidates:
                    paths = storage.ensure_round_dirs(cfg.game_id, round_id)
                    with open(f"{paths['analyst_outputs']}/avatar_candidates.json", "w", encoding="utf-8") as handle:
                        handle.write(json.dumps(export_avatar_debug(analyzed), sort_keys=True))
                _log_stage_stop(cfg.game_id, round_id, "artifact_write", t0, stage_timings)
                controller_modes = ["random_probe"]
                target_progress = None
                instruction = None
                outcome = None
            else:
                t0 = _log_stage_start(cfg.game_id, round_id, "planning")
                prior_blackboard = load_blackboard_typed(storage, cfg.game_id)
                if prior_blackboard is None:
                    raise RuntimeError("Missing blackboard for directed round")
                skills, skill_executions = load_skill_library(storage, cfg.game_id)
                skills = induce_skills(prior_blackboard, existing=skills)
                skills = reconcile_skill_library(skills, skill_executions)
                plan_memory_state = reconcile_plan_memory(skills, skill_executions, load_plan_memory(storage, cfg.game_id))
                save_plan_memory(storage, cfg.game_id, plan_memory_state)
                directed_count = max(1, int(cfg.collection.directed_probe_episodes))
                _log_stage_stop(cfg.game_id, round_id, "planning", t0, stage_timings)
                t0 = _log_stage_start(cfg.game_id, round_id, "directed_execution")
                outcomes = []
                episodes = []
                round_consequence_records = []
                per_episode_passes: List[Dict[str, Any]] = []
                controller_modes = []
                target_progress = None
                instruction = None
                outcome = None
                belief = None
                plan_nodes = []
                controller_fallback_used = False
                force_regenerate_inventory = False
                for ep_idx in range(directed_count):
                    prior_blackboard = load_blackboard_typed(storage, cfg.game_id) or prior_blackboard
                    skills, skill_executions = load_skill_library(storage, cfg.game_id)
                    skills = induce_skills(prior_blackboard, existing=skills)
                    skills = reconcile_skill_library(skills, skill_executions)
                    plan_memory_state = reconcile_plan_memory(skills, skill_executions, load_plan_memory(storage, cfg.game_id))
                    save_plan_memory(storage, cfg.game_id, plan_memory_state)
                    memory_refs = build_plan_memory_refs(plan_memory_state)
                    belief = build_planner_belief_state(
                        prior_blackboard,
                        skills,
                        plan_memory_refs=memory_refs,
                        plan_memory=plan_memory_state,
                        force_full_inventory=force_regenerate_inventory,
                    )
                    candidate_skill_rows = candidate_skills(skills, belief.candidate_subgoal_ids)
                    belief = build_planner_belief_state(
                        prior_blackboard,
                        skills,
                        candidate_skills=candidate_skill_rows,
                        plan_memory_refs=memory_refs,
                        plan_memory=plan_memory_state,
                        force_full_inventory=force_regenerate_inventory,
                    )
                    option_scores, option_record = rank_options(storage, cfg.game_id, belief, candidate_skill_rows)
                    candidate_mechanic_ids = [node.node_id for node in prior_blackboard.mechanic_graph.nodes] if prior_blackboard.mechanic_graph is not None else []
                    mechanic_scores, mechanic_record = rank_mechanics(storage, cfg.game_id, candidate_mechanic_ids)
                    _save_ranking_records(storage, cfg.game_id, option_record, option_scores, mechanic_record, mechanic_scores)
                    plan_nodes, plan_result = plan_best_first(
                        belief,
                        candidate_skill_rows,
                        learned_score_map=option_scores if option_record is not None and option_scores else None,
                        blackboard=prior_blackboard,
                        plan_memory=plan_memory_state,
                        candidate_source_label="regenerated_inventory" if force_regenerate_inventory else "reused_shortlist",
                    )
                    selected_skill = next((skill for skill in skills if plan_result is not None and skill.skill_id == plan_result.selected_skill_id), None)
                    if selected_skill is not None and plan_result is not None:
                        controller_fallback_used = False
                        instruction = instruction_from_skill(selected_skill, plan_result, prior_blackboard.game_id, prior_blackboard.round_id + 1)
                        instruction = _bind_instruction_to_blackboard(instruction, prior_blackboard)
                        if not _instruction_has_executable_target(instruction):
                            outcome, episode = _invalid_pre_execution_outcome(prior_blackboard.game_id, instruction)
                            skill_records = []
                            _save_plan_memory(
                                storage,
                                cfg.game_id,
                                belief,
                                plan_nodes,
                                plan_result,
                                plan_memory_state,
                                failure_payload={"round_id": round_id, "reason": "invalid_target_pre_execution", "selected_skill_id": selected_skill.skill_id},
                            )
                        else:
                            outcome, episode = run_offline_local_execution(
                                session,
                                instruction,
                                prior_blackboard,
                                cfg.executor,
                                episode_suffix=f"_ep{ep_idx:05d}",
                            )
                            skill_records = [skill_record_from_execution(selected_skill, instruction, outcome, episode, execution_suffix=f"ep{ep_idx:05d}")]
                            skill_executions = list(skill_executions) + skill_records
                        skills = save_skill_library(storage, cfg.game_id, skills, skill_executions)
                        plan_memory_state = reconcile_plan_memory(skills, skill_executions, plan_memory_state)
                        save_plan_memory(storage, cfg.game_id, plan_memory_state)
                        _save_plan_memory(storage, cfg.game_id, belief, plan_nodes, plan_result, plan_memory_state)
                        prior_blackboard = replace(
                            prior_blackboard,
                            metadata={
                                **prior_blackboard.metadata,
                                "round_local_probe_outcomes": list(prior_blackboard.metadata.get("round_local_probe_outcomes", []))
                                + [
                                    {
                                        "round_id": round_id,
                                        "skill_id": selected_skill.skill_id,
                                        "trigger_zone_id": _instruction_trigger_zone_id(instruction),
                                        "outcome_summary": outcome.outcome_summary,
                                    }
                                ],
                            },
                        )
                        force_regenerate_inventory = not _measurable_progress(outcome)
                    else:
                        controller_fallback_used = True
                        fallback_stage, fallback_skill = _choose_structured_fallback_skill(candidate_skill_rows, plan_memory_state)
                        if fallback_skill is not None:
                            plan_result = None
                            selected_skill = fallback_skill
                            controller_fallback_used = False
                            synthetic_plan = PlanResultV1(
                                schema_version="v2.3.2",
                                plan_id="plan:fallback",
                                root_plan_node_id="plan_node:root",
                                selected_plan_node_id="",
                                selected_skill_id=fallback_skill.skill_id,
                                selected_subgoal_id=None,
                                planner_reason=fallback_stage or "planner_fallback",
                                alternative_plan_node_ids=[],
                            )
                            instruction = instruction_from_skill(fallback_skill, synthetic_plan, prior_blackboard.game_id, prior_blackboard.round_id + 1)
                        else:
                            instruction = select_instruction(prior_blackboard, cfg.controller, cfg.scoring, round_id)
                        instruction = _bind_instruction_to_blackboard(instruction, prior_blackboard)
                        if not _instruction_has_executable_target(instruction):
                            outcome, episode = _invalid_pre_execution_outcome(prior_blackboard.game_id, instruction)
                        else:
                            outcome, episode = run_offline_local_execution(
                                session,
                                instruction,
                                prior_blackboard,
                                cfg.executor,
                                episode_suffix=f"_ep{ep_idx:05d}",
                            )
                        _save_plan_memory(
                            storage,
                            cfg.game_id,
                            belief,
                            plan_nodes,
                            plan_result,
                            failure_payload={"round_id": round_id, "reason": fallback_stage or "planner_fallback", "selected_skill_id": getattr(fallback_skill, "skill_id", None)}
                            if plan_result is None and controller_fallback_used
                            else None,
                            plan_memory_state=plan_memory_state,
                        )
                        skills = save_skill_library(storage, cfg.game_id, skills, skill_executions)
                        force_regenerate_inventory = bool(outcome is not None and outcome.outcome_summary in {"route_stall", "contact_no_effect", "contact_no_reach", "blocked", "invalid_target", "unreachable_now"})
                    outcomes.append(outcome)
                    round_consequence_records.extend(list(outcome.consequence_records))
                    episodes.append(episode)
                    controller_modes.append(instruction.mode)
                    target_progress = outcome.target_progress
                    per_episode_passes.append(
                        {
                            "episode_idx": ep_idx,
                            "selected_skill_id": plan_result.selected_skill_id if plan_result is not None else None,
                            "selected_plan_node_id": plan_result.selected_plan_node_id if plan_result is not None else None,
                            "instruction_id": instruction.instruction_id if instruction is not None else None,
                            "outcome_summary": outcome.outcome_summary if outcome is not None else None,
                        }
                    )
                    _save_plan_pass_debug(storage, cfg.game_id, round_id, ep_idx, belief, plan_nodes, plan_result, outcome)
                    if outcome.outcome_summary in {"invalid_target", "unreachable_now"}:
                        break
                    if outcome.outcome_summary in {"route_stall", "contact_no_effect", "contact_no_reach", "blocked"}:
                        force_regenerate_inventory = True
                _log_stage_stop(cfg.game_id, round_id, "directed_execution", t0, stage_timings)
                t0 = _log_stage_start(cfg.game_id, round_id, "episode_analysis")
                analyzed = analyze_episodes_parallel(episodes, cfg.analyst, workers=effective_workers, pool=worker_pool)
                _log_stage_stop(cfg.game_id, round_id, "episode_analysis", t0, stage_timings)
                t0 = _log_stage_start(cfg.game_id, round_id, "trajectory_analysis")
                blackboard = analyze_trajectories(
                    analyzed,
                    cfg.trajectory_analysis,
                    round_id=round_id,
                    prior_blackboard=prior_blackboard,
                    workers=effective_workers,
                    pool=worker_pool,
                )
                _log_stage_stop(cfg.game_id, round_id, "trajectory_analysis", t0, stage_timings)
                t0 = _log_stage_start(cfg.game_id, round_id, "artifact_write")
                blackboard = replace(
                    blackboard,
                    consequence_table=list(blackboard.consequence_table) + [record for row_outcome in outcomes for record in row_outcome.consequence_records],
                )
                collector.write_artifacts(cfg.game_id, round_id, analyzed)
                if cfg.debug.export_avatar_candidates:
                    paths = storage.ensure_round_dirs(cfg.game_id, round_id)
                    with open(f"{paths['analyst_outputs']}/avatar_candidates.json", "w", encoding="utf-8") as handle:
                        handle.write(json.dumps(export_avatar_debug(analyzed), sort_keys=True))
                _log_stage_stop(cfg.game_id, round_id, "artifact_write", t0, stage_timings)
                if per_episode_passes:
                    _export_debug_table(storage, cfg.game_id, round_id, "directed_episode_plan_passes.json", per_episode_passes)
            total_wins += sum(1 for episode in episodes if episode.win)
            episodes_seen += len(episodes)
            round_wins = sum(1 for episode in episodes if episode.win)
            round_max_steps = max((len(episode.steps) for episode in episodes), default=0)
            for episode in episodes:
                max_steps_per_game = max(max_steps_per_game, len(episode.steps))
            reach_lookup = {r.poi_id: r.status for r in blackboard.reachability_table}
            episode_ids = {ep.episode_id for ep in analyzed}
            round_consequences = [
                record
                for record in blackboard.consequence_table
                if record.episode_id in episode_ids or (instruction is not None and record.instruction_id == instruction.instruction_id)
            ]
            if round_id > 0:
                round_consequences = list(round_consequence_records)
            metrics = compute_round_metrics(
                analyzed,
                blackboard.poi_table,
                reach_lookup,
                round_consequences,
                controller_modes,
                len(blackboard.avatar_hypotheses),
                target_progress=target_progress,
                blackboard=blackboard,
                executor_outcomes=outcomes if round_id > 0 else None,
            )
            if round_id > 0:
                metrics = _consistent_round_metrics(metrics, outcomes, controller_modes)
            diagnostics = []
            # Historical diagnostics based on removed metrics are intentionally commented out:
            # if metrics.states_observed > 0 and metrics.unique_states == 0:
            #     diagnostics.append("state_hash_missing")
            # if metrics.candidate_avatar_count == 0:
            #     diagnostics.append("no_avatar_candidates")
            # if metrics.candidate_poi_count > 0 and metrics.reachable_poi_count == 0:
            #     diagnostics.append("no_reachable_pois")
            # targeted_run = instruction.mode not in {"random_probe", "unguided_probe"} if round_id > 0 else False
            # if targeted_run and metrics.target_progress_mean == 0:
            #     diagnostics.append("no_target_progress")
            # if targeted_run and metrics.route_success_rate == 0:
            #     diagnostics.append("no_route_success")
            if round_id > 0 and instruction.mode not in {"random_probe", "unguided_probe"} and metrics.route_success_rate == 0:
                diagnostics.append("no_route_success")
            instruction_history = list(blackboard.metadata.get("instruction_history", [])) if isinstance(blackboard.metadata, dict) else []
            if round_id > 0:
                instruction_history.append(
                    {
                        "round_id": round_id,
                        "mode": instruction.mode,
                        "instruction_id": instruction.instruction_id,
                        "target_poi_id": instruction.target_poi_id,
                        "outcome": "progress" if any(c.distance_decreased or c.reached or c.contact for c in outcome.consequence_records) else "no_progress",
                    }
                )
            outcome_history = list(blackboard.metadata.get("executor_outcome_history", [])) if isinstance(blackboard.metadata, dict) else []
            if round_id > 0:
                outcome_history.append(outcome.to_dict())
            linked_events = [event for event in blackboard.event_table if event.episode_id in episode_ids]
            linked_event_ids = [event.event_id for event in linked_events]
            linked_interventions = [record for record in blackboard.intervention_table if record.round_id == round_id]
            linked_intervention_ids = [record.instruction_id for record in linked_interventions]
            linked_causal_links = [
                link for link in blackboard.cause_effect_table if link.intervention_id in linked_intervention_ids or link.effect_event_id in linked_event_ids
            ]
            promoted_mechanics = [
                mech for mech in blackboard.mechanic_hypotheses if mech.status == "promoted" and any(event_id in linked_event_ids for event_id in mech.support_event_ids)
            ]
            pre_execution_invalidation = bool(
                outcome is not None and outcome.outcome_summary in {"invalid_target", "invalid_target_pre_execution"} and not outcome.actions
            )
            selected_trigger_zone_id = _instruction_trigger_zone_id(instruction) if instruction is not None else None
            decision_record = DecisionRecordV2(
                schema_version=SCHEMA_VERSION,
                game_id=cfg.game_id,
                round_id=round_id,
                instruction_id=instruction.instruction_id if instruction is not None else f"round{round_id:03d}:random_probe",
                selected_target_poi_id=instruction.target_poi_id if instruction is not None else None,
                selected_area_id=next((poi.area_id for poi in blackboard.poi_table if poi.poi_id == instruction.target_poi_id), None) if instruction is not None else None,
                mode=controller_modes[0] if controller_modes else "unknown",
                rationale_codes=[code for code in ((instruction.rationale.split() if instruction is not None and instruction.rationale else [])) if code][:6],
                ranked_candidate_ids=(
                    ([plan_result.selected_plan_node_id] + [node_id for node_id in plan_result.alternative_plan_node_ids if node_id != plan_result.selected_plan_node_id])[:5]
                    if plan_result is not None and plan_result.selected_plan_node_id
                    else list(instruction.ranked_alternatives) if instruction is not None else []
                ),
                outcome_summary="invalid_target_pre_execution" if pre_execution_invalidation else (outcome.outcome_summary if outcome is not None else "initial_probe"),
                progress_score=(max(target_progress) if target_progress else 0.0) if target_progress is not None else None,
                target_invalidated=_decision_target_invalidated(instruction, outcome),
                selected_trigger_zone_id=selected_trigger_zone_id,
                selected_chain_id=_extract_tag(instruction.rationale if instruction is not None else None, "chain_id"),
                selected_hidden_hypothesis_id=_extract_tag(instruction.rationale if instruction is not None else None, "hidden_hypothesis_id"),
            )
            blackboard = replace(
                blackboard,
                decision_history=list(blackboard.decision_history) + [decision_record],
                metadata={
                    **blackboard.metadata,
                    "diagnostics": diagnostics,
                    "metrics": metrics.to_dict(),
                    "instruction_history": instruction_history[-20:],
                    "executor_outcome_history": outcome_history[-10:],
                    "round_mode": controller_modes[0] if controller_modes else "unknown",
                    "learned_option_ranking_applied": bool(round_id > 0 and option_record is not None and option_scores),
                    "learned_mechanic_ranking_applied": bool(round_id > 0 and mechanic_record is not None and mechanic_scores),
                },
            )
            save_blackboard(cfg.memory, storage, blackboard)
            save_graph_state(storage, blackboard)
            if cfg.memory.persist_world_model:
                save_world_model_archive(storage, blackboard)
            if cfg.memory.persist_events:
                save_event_table(storage, blackboard)
            if cfg.memory.persist_navigation_graph:
                save_navigation_graph(storage, blackboard)
            if cfg.memory.persist_interventions:
                save_interventions(storage, blackboard)
            if cfg.memory.persist_world_model:
                save_mechanic_hypotheses(storage, blackboard)
            if cfg.debug.export_trigger_zones:
                _export_debug_table(storage, cfg.game_id, round_id, "trigger_zones.json", [row.to_dict() for row in blackboard.trigger_zone_table])
            if cfg.debug.export_event_graph:
                _export_debug_table(storage, cfg.game_id, round_id, "event_graph.json", [row.to_dict() for row in blackboard.event_edge_table])
            if cfg.debug.export_event_sequence_patterns:
                _export_debug_table(storage, cfg.game_id, round_id, "event_sequence_patterns.json", [row.to_dict() for row in blackboard.event_sequence_patterns])
            if cfg.debug.export_hidden_trigger_hypotheses:
                _export_debug_table(storage, cfg.game_id, round_id, "hidden_trigger_hypotheses.json", [row.to_dict() for row in blackboard.hidden_trigger_hypotheses])
            if cfg.debug.export_causal_chain_hypotheses:
                _export_debug_table(storage, cfg.game_id, round_id, "causal_chain_hypotheses.json", [row.to_dict() for row in blackboard.causal_chain_hypotheses])
            if cfg.debug.export_counterfactual_traces:
                _export_debug_table(storage, cfg.game_id, round_id, "counterfactual_traces.json", [row.to_dict() for row in blackboard.counterfactual_traces])
            report = {
                "round_id": round_id,
                "game_id": cfg.game_id,
                "poi_count": len(blackboard.poi_table),
                "metrics": metrics.to_dict(),
                "stage_timings": {
                    **{k: round(v, 6) for k, v in stage_timings.items()},
                    "round_total": round(time.perf_counter() - round_t0, 6),
                    "analysis_substages": (blackboard.metadata.get("analysis_stage_timings", {}) if isinstance(blackboard.metadata, dict) else {}),
                },
                "diagnostics": diagnostics,
                "invalid_target_link_count": sum(1 for c in blackboard.consequence_table if c.consequence_class == "invalid_target_link"),
                "wins": round_wins,
                "max_steps_per_game": round_max_steps,
                "decision": decision_record.to_dict(),
                "execution_outcome": (
                    {
                        **outcome.to_dict(),
                        "outcome_summary": "invalid_target_pre_execution",
                        "blocked": False,
                    }
                    if pre_execution_invalidation
                    else (outcome.to_dict() if outcome is not None else None)
                ),
                "linked_event_ids": linked_event_ids,
                "linked_causal_link_ids": [link.link_id for link in linked_causal_links],
                "promoted_mechanic_hypothesis_ids": [mech.hypothesis_id for mech in promoted_mechanics],
            }
            append_round_report(storage, cfg.game_id, round_id, report)
            log_event(cfg.logging.log_dir, "v2_round_complete", report)
            print(
                f"[v2] round_complete game_id={cfg.game_id} round_id={round_id} poi_count={len(blackboard.poi_table)} wins={round_wins} max_steps_per_game={round_max_steps} total_s={round(time.perf_counter() - round_t0, 3)}",
                flush=True,
            )
            last_report = report

        if last_report is not None:
            summary = {
                **last_report,
                "wins": total_wins,
                "max_steps_per_game": max_steps_per_game,
                "episodes_seen": episodes_seen,
            }
            session_mgr.export_summary(cfg.game_id, summary)
            return summary
    finally:
        if worker_pool is not None:
            worker_pool.close()
            worker_pool.join()
        if shared_env is not None and hasattr(shared_env, "close"):
            try:
                shared_env.close()
            except Exception:
                pass
    return {
        "game_id": cfg.game_id,
        "wins": total_wins,
        "max_steps_per_game": max_steps_per_game,
        "episodes_seen": episodes_seen,
    }
