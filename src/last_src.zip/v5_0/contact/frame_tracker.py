from __future__ import annotations

from collections import Counter
from math import sqrt


def track_avatar_bbox_in_frame(
    frame: tuple[tuple[int, ...], ...] | None,
    reference_bbox: tuple[int, int, int, int] | None,
    reference_histogram: dict[int, int] | None = None,
    frontier_reanchor: bool = False,
) -> tuple[int, int, int, int] | None:
    return _track_bbox(frame, reference_bbox, reference_histogram, for_poi=False, frontier_reanchor=frontier_reanchor)


def track_poi_bbox_in_frame(
    frame: tuple[tuple[int, ...], ...] | None,
    reference_bbox: tuple[int, int, int, int] | None,
    reference_histogram: dict[int, int] | None = None,
    frontier_reanchor: bool = False,
) -> tuple[int, int, int, int] | None:
    return _track_bbox(frame, reference_bbox, reference_histogram, for_poi=True, frontier_reanchor=frontier_reanchor)


def detect_screen_change(pre_frame: tuple[tuple[int, ...], ...] | None, post_frame: tuple[tuple[int, ...], ...] | None) -> bool:
    if pre_frame is None or post_frame is None:
        return False
    return any(
        int(pre_frame[y][x]) != int(post_frame[y][x])
        for y in range(min(len(pre_frame), len(post_frame)))
        for x in range(min(len(pre_frame[y]), len(post_frame[y])))
    )


def detect_screen_change_outside_hud_mask(
    pre_frame: tuple[tuple[int, ...], ...] | None,
    post_frame: tuple[tuple[int, ...], ...] | None,
    hud_mask=None,
) -> bool:
    if hud_mask is None:
        return detect_screen_change(pre_frame, post_frame)
    if pre_frame is None or post_frame is None:
        return False
    h = min(len(pre_frame), len(post_frame))
    w = min(len(pre_frame[0]), len(post_frame[0])) if h else 0
    if h == 0 or w == 0:
        return False

    if isinstance(hud_mask, dict):
        rows_active = set(int(v) for v in hud_mask.get("rows_active", ()))
        cols_active = set(int(v) for v in hud_mask.get("cols_active", ()))
    else:
        rows_active = set(int(v) for v in getattr(hud_mask, "rows_active", ()))
        cols_active = set(int(v) for v in getattr(hud_mask, "cols_active", ()))

    for y in range(h):
        for x in range(w):
            if int(pre_frame[y][x]) == int(post_frame[y][x]):
                continue
            if y in rows_active and x in cols_active:
                continue
            return True
    return False


def detect_hud_only_change(pre_frame: tuple[tuple[int, ...], ...] | None, post_frame: tuple[tuple[int, ...], ...] | None, border_width: int = 2) -> bool:
    if pre_frame is None or post_frame is None:
        return False
    if not detect_screen_change(pre_frame, post_frame):
        return False
    h = min(len(pre_frame), len(post_frame))
    w = min(len(pre_frame[0]), len(post_frame[0])) if h else 0
    # Conservative rule: when there is no interior region, do not classify as HUD-only.
    if h <= (2 * border_width) or w <= (2 * border_width):
        return False
    for y in range(h):
        for x in range(w):
            if int(pre_frame[y][x]) == int(post_frame[y][x]):
                continue
            if border_width <= x < (w - border_width) and border_width <= y < (h - border_width):
                return False
    return True


def detect_contact(
    avatar_bbox: tuple[int, int, int, int] | None,
    poi_bbox: tuple[int, int, int, int] | None,
) -> bool:
    if avatar_bbox is None or poi_bbox is None:
        return False
    if _bbox_iou(avatar_bbox, poi_bbox) > 0.0:
        return True
    return _bbox_gap(avatar_bbox, poi_bbox) <= 1.0


def detect_object_removed(
    previous_poi_bbox: tuple[int, int, int, int] | None,
    current_poi_bbox: tuple[int, int, int, int] | None,
    contact_or_approach: bool,
) -> bool:
    return bool(previous_poi_bbox is not None and current_poi_bbox is None and contact_or_approach)


def detect_new_object_appeared(
    pre_frame: tuple[tuple[int, ...], ...] | None,
    post_frame: tuple[tuple[int, ...], ...] | None,
    avatar_bbox: tuple[int, int, int, int] | None = None,
) -> bool:
    if pre_frame is None or post_frame is None:
        return False
    h = min(len(pre_frame), len(post_frame))
    w = min(len(pre_frame[0]), len(post_frame[0])) if h else 0
    pre_background = _dominant_value(pre_frame)
    appeared_cells: set[tuple[int, int]] = set()
    for y in range(h):
        for x in range(w):
            pre_v = int(pre_frame[y][x])
            post_v = int(post_frame[y][x])
            if pre_v == post_v:
                continue
            if post_v == pre_background:
                continue
            appeared_cells.add((x, y))
    for component in _connected_components(appeared_cells):
        box = _bbox(component)
        if avatar_bbox is not None and _bbox_iou(box, avatar_bbox) > 0.0:
            continue
        if len(component) >= 2:
            return True
    return False


def _track_bbox(frame, reference_bbox, reference_histogram, for_poi: bool, frontier_reanchor: bool = False):
    if frame is None:
        return None
    components = _components_non_background(frame)
    if not components:
        return None
    if reference_bbox is None:
        return _bbox(max(components, key=len))

    best = None
    best_score = -1.0
    best_iou = 0.0
    best_dist = float("inf")
    ref_center = _center_from_bbox(reference_bbox)
    ref_area = _bbox_area(reference_bbox)
    best_area_ratio = 1.0
    for component in components:
        box = _bbox(component)
        center = _center_from_bbox(box)
        iou = _bbox_iou(box, reference_bbox)
        dist = sqrt((center[0] - ref_center[0]) ** 2 + (center[1] - ref_center[1]) ** 2)
        proximity = max(0.0, 1.0 - dist / 8.0)
        hist = _histogram_for_component(frame, component)
        hist_sim = _hist_similarity(hist, reference_histogram or {}) if reference_histogram else 0.5
        area = _bbox_area(box)
        area_ratio = max(area, ref_area) / max(1.0, min(area, ref_area))
        area_similarity = max(0.0, min(1.0, 1.0 - (area_ratio - 1.0) / 3.0))
        expansion_penalty = max(0.0, (area / max(1.0, ref_area)) - 2.5)
        score = 0.34 * iou + 0.24 * proximity + 0.22 * hist_sim + 0.20 * area_similarity - 0.18 * expansion_penalty
        if score > best_score:
            best = box
            best_score = score
            best_iou = iou
            best_dist = dist
            best_area_ratio = area / max(1.0, ref_area)

    if best is None:
        return None
    if _is_large_geometry_mismatch(
        for_poi=for_poi,
        score=best_score,
        iou=best_iou,
        center_distance=best_dist,
        area_ratio=best_area_ratio,
    ):
        if frontier_reanchor:
            return find_plausible_component_match_in_frame(
                frame=frame,
                reference_bbox=reference_bbox,
                reference_histogram=reference_histogram,
                for_poi=for_poi,
            )
        return None
    if for_poi and best_area_ratio > 3.0:
        if _is_bbox_visible(frame, reference_bbox):
            return reference_bbox
        return None
    if for_poi and best_score < 0.25:
        if _is_bbox_visible(frame, reference_bbox):
            return reference_bbox
        return None
    return best


def find_plausible_component_match_in_frame(
    *,
    frame: tuple[tuple[int, ...], ...] | None,
    reference_bbox: tuple[int, int, int, int] | None,
    reference_histogram: dict[int, int] | None = None,
    for_poi: bool,
) -> tuple[int, int, int, int] | None:
    if frame is None:
        return None
    components = _components_non_background(frame)
    if not components:
        return None
    if reference_bbox is None:
        candidate = _bbox(max(components, key=len))
        return candidate if _bbox_area(candidate) >= 1 else None

    ref_center = _center_from_bbox(reference_bbox)
    ref_area = _bbox_area(reference_bbox)
    best_box = None
    best_score = -1.0
    for component in components:
        box = _bbox(component)
        center = _center_from_bbox(box)
        dist = sqrt((center[0] - ref_center[0]) ** 2 + (center[1] - ref_center[1]) ** 2)
        if dist > (8.5 if for_poi else 7.5):
            continue
        proximity = max(0.0, 1.0 - dist / (12.0 if for_poi else 10.0))
        hist = _histogram_for_component(frame, component)
        hist_sim = _hist_similarity(hist, reference_histogram or {}) if reference_histogram else 0.5
        area = _bbox_area(box)
        ratio = max(area, ref_area) / max(1.0, min(area, ref_area))
        area_similarity = max(0.0, 1.0 - (ratio - 1.0) / 4.0)
        width = max(1, box[2] - box[0] + 1)
        height = max(1, box[3] - box[1] + 1)
        compactness = min(width, height) / float(max(width, height))
        role_bias = 0.05 if (for_poi and area >= 1) else (0.08 if (not for_poi and area >= 1) else 0.0)
        score = (0.40 * hist_sim) + (0.25 * area_similarity) + (0.20 * proximity) + (0.15 * compactness) + role_bias
        if score > best_score:
            best_score = score
            best_box = box
    if best_box is None:
        return None
    threshold = 0.35 if for_poi else 0.38
    if best_score < threshold:
        return None
    return best_box


def _is_large_geometry_mismatch(*, for_poi: bool, score: float, iou: float, center_distance: float, area_ratio: float) -> bool:
    if for_poi:
        if iou < 0.05 and center_distance > 10.0:
            return True
        if iou < 0.05 and area_ratio > 5.0:
            return True
        return score < 0.15 and center_distance > 8.0
    if iou < 0.03 and center_distance > 9.0:
        return True
    return score < 0.10 and area_ratio > 4.0


def _components_non_background(frame):
    background = _dominant_value(frame)
    cells = {(x, y) for y, row in enumerate(frame) for x, value in enumerate(row) if int(value) != background}
    return _connected_components(cells)


def _connected_components(cells):
    remaining = set(cells)
    components = []
    while remaining:
        start = remaining.pop()
        stack = [start]
        component = {start}
        while stack:
            x, y = stack.pop()
            for n in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                if n in remaining:
                    remaining.remove(n)
                    component.add(n)
                    stack.append(n)
        components.append(tuple(sorted(component)))
    return tuple(components)


def _dominant_value(frame):
    counts = Counter(int(v) for row in frame for v in row)
    return int(counts.most_common(1)[0][0]) if counts else 0


def _bbox(component):
    xs = [x for x, _ in component]
    ys = [y for _, y in component]
    return (min(xs), min(ys), max(xs), max(ys))


def _center_from_bbox(bbox):
    return ((bbox[0] + bbox[2]) / 2.0, (bbox[1] + bbox[3]) / 2.0)


def _bbox_area(bbox):
    return max(1, (bbox[2] - bbox[0] + 1) * (bbox[3] - bbox[1] + 1))


def _bbox_iou(left, right):
    ix0 = max(left[0], right[0])
    iy0 = max(left[1], right[1])
    ix1 = min(left[2], right[2])
    iy1 = min(left[3], right[3])
    if ix1 < ix0 or iy1 < iy0:
        return 0.0
    inter = (ix1 - ix0 + 1) * (iy1 - iy0 + 1)
    l_area = (left[2] - left[0] + 1) * (left[3] - left[1] + 1)
    r_area = (right[2] - right[0] + 1) * (right[3] - right[1] + 1)
    return inter / max(l_area + r_area - inter, 1)


def _bbox_gap(left, right):
    dx = max(0, max(left[0] - right[2] - 1, right[0] - left[2] - 1))
    dy = max(0, max(left[1] - right[3] - 1, right[1] - left[3] - 1))
    return sqrt(dx * dx + dy * dy)


def _histogram_for_component(frame, component):
    c = Counter(int(frame[y][x]) for x, y in component)
    return dict(c)


def _hist_similarity(left, right):
    if not left or not right:
        return 0.0
    keys = set(left) | set(right)
    overlap = sum(min(int(left.get(k, 0)), int(right.get(k, 0))) for k in keys)
    total = sum(max(int(left.get(k, 0)), int(right.get(k, 0))) for k in keys)
    return overlap / max(total, 1)


def _is_bbox_visible(frame, bbox):
    if frame is None or bbox is None:
        return False
    background = _dominant_value(frame)
    x0, y0, x1, y1 = bbox
    hits = 0
    total = 0
    for y in range(max(0, y0), min(len(frame), y1 + 1)):
        for x in range(max(0, x0), min(len(frame[0]), x1 + 1)):
            total += 1
            if int(frame[y][x]) != background:
                hits += 1
    if total <= 0:
        return False
    return (hits / total) >= 0.2
