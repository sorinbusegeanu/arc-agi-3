from __future__ import annotations

from v5_0.contact.frame_tracker import track_avatar_bbox_in_frame


def build_solve_policy_for_target(
    selected_avatar_result,
    target_poi,
    current_frame,
    step_budget_remaining,
) -> tuple[str, ...]:
    budget = max(0, int(step_budget_remaining))
    if budget <= 0 or target_poi is None:
        return ()

    avatar_bbox = track_avatar_bbox_in_frame(
        current_frame,
        getattr(selected_avatar_result, "selected_bbox", None),
        None,
    )
    if avatar_bbox is None:
        avatar_center = tuple(getattr(selected_avatar_result, "selected_center", (0.0, 0.0)) or (0.0, 0.0))
    else:
        avatar_center = ((avatar_bbox[0] + avatar_bbox[2]) / 2.0, (avatar_bbox[1] + avatar_bbox[3]) / 2.0)

    target_center = tuple(getattr(target_poi, "center", avatar_center))
    dx = float(target_center[0]) - float(avatar_center[0])
    dy = float(target_center[1]) - float(avatar_center[1])

    horizontal = _axis_actions(dx, "RIGHT", "LEFT")
    vertical = _axis_actions(dy, "DOWN", "UP")
    planned = horizontal + vertical if abs(dx) >= abs(dy) else vertical + horizontal
    horizon = min(budget, max(1, min(6, len(planned) if planned else 1)))
    if not planned:
        return ("RIGHT",)[:horizon]
    return tuple(planned[:horizon])


def build_adaptive_policy_for_target(
    selected_avatar_result,
    target_poi,
    current_frame,
    step_budget_remaining,
) -> tuple[str, ...]:
    return build_solve_policy_for_target(
        selected_avatar_result=selected_avatar_result,
        target_poi=target_poi,
        current_frame=current_frame,
        step_budget_remaining=step_budget_remaining,
    )


def _axis_actions(delta: float, positive: str, negative: str) -> list[str]:
    steps = int(round(abs(delta)))
    token = positive if delta >= 0.0 else negative
    return [token for _ in range(max(0, steps))]
