from __future__ import annotations

from collections import Counter
import hashlib
import time
from typing import Any, Callable

from v5_0.contracts.avatar_types import (
    AdaptiveDiagnostics,
    AdaptiveEpisodeResult,
    AdaptiveSolveReport,
    AdaptiveStepRecord,
    AdaptiveTargetState,
    SavedLevelTrace,
    LevelSolution,
    LevelSolveAction,
    SolveDiagnostics,
    SolveReport,
)
from v5_0.replay.player import replay_saved_trace
from v5_0.mechanics.service import build_mechanic_report
from v5_0.solve.policy_builder import build_adaptive_policy_for_target
from v5_0.solve.loop_runner import run_adaptive_solve_episode, run_solve_episode
from v5_0.solve.target_selector import select_initial_target, select_next_target
from v5_0.contact.frame_tracker import (
    detect_contact,
    detect_hud_only_change,
    detect_screen_change,
    detect_screen_change_outside_hud_mask,
    find_best_component_match_in_frame,
    reacquire_avatar_bbox_in_frame,
    reacquire_poi_bbox_in_frame,
    track_avatar_bbox_in_frame,
    track_poi_bbox_in_frame,
)
from v5_0.contact.outcome_classifier import is_useful_world_change
from v4_5.adapters.actionAdapter import ActionAdapter, ActionTranslationContext
from v4_5.runtime.sessionAdapter import SessionAdapter
from v5_0.replay.player import replay_trace_at_frontier
from v5_0.memory.trace_store import upsert_verified_best_trace


def run_closed_loop_solve_multi_reset(
    *,
    avatar_multi_report,
    poi_multi_bundle,
    hud_targeting_report,
    contact_experiment_report=None,
    game_id,
    plan,
    base_seed,
    render_terminal,
    env_factory: Callable[[], Any] | None,
    max_steps,
) -> SolveReport:
    if getattr(avatar_multi_report.selected, "failure_reason", None) is not None or not bool(getattr(avatar_multi_report.diagnostics, "stable_avatar_found", False)):
        diagnostics = SolveDiagnostics(
            episode_count=0,
            solved_episode_count=0,
            failed_episode_count=0,
            failure_reason_counts={"no_stable_avatar": 1},
            retarget_count=0,
            level_transition_count=0,
            terminal_success_count=0,
            terminal_failure_count=0,
            step_budget_exhausted_count=0,
        )
        return SolveReport(episodes=(), diagnostics=diagnostics, selected_target_id=None, solved=False, failure_reason="no_stable_avatar")

    poi_report = poi_multi_bundle.get("report") if isinstance(poi_multi_bundle, dict) else None
    ranked_pois = tuple(getattr(poi_report, "candidates", ()))
    if not ranked_pois:
        diagnostics = SolveDiagnostics(
            episode_count=0,
            solved_episode_count=0,
            failed_episode_count=0,
            failure_reason_counts={"no_poi_candidate": 1},
            retarget_count=0,
            level_transition_count=0,
            terminal_success_count=0,
            terminal_failure_count=0,
            step_budget_exhausted_count=0,
        )
        return SolveReport(episodes=(), diagnostics=diagnostics, selected_target_id=None, solved=False, failure_reason="no_poi_candidate")

    mechanic_report = build_mechanic_report(
        ranked_pois,
        contact_experiment_report=contact_experiment_report,
        hud_targeting_report=hud_targeting_report,
        solve_report=None,
        previous_mechanic_memory=None,
    )

    initial_target = select_initial_target(
        hud_targeting_report,
        ranked_pois,
        contact_experiment_report=contact_experiment_report,
        mechanic_report=mechanic_report,
    )
    if initial_target is None or initial_target.target_poi_id is None:
        diagnostics = SolveDiagnostics(
            episode_count=0,
            solved_episode_count=0,
            failed_episode_count=0,
            failure_reason_counts={"no_target_selected": 1},
            retarget_count=0,
            level_transition_count=0,
            terminal_success_count=0,
            terminal_failure_count=0,
            step_budget_exhausted_count=0,
        )
        return SolveReport(episodes=(), diagnostics=diagnostics, selected_target_id=None, solved=False, failure_reason="no_target_selected")

    episodes = []
    failure_counts = Counter()
    retarget_count = 0
    level_transition_count = 0
    terminal_success_count = 0
    terminal_failure_count = 0
    step_budget_exhausted_count = 0

    for probe_episode in tuple(getattr(avatar_multi_report, "episodes", ())):
        selected_avatar = probe_episode.report.selected
        if selected_avatar.failure_reason is not None:
            continue
        result = run_solve_episode(
            game_id=game_id,
            plan=plan,
            episode_index=int(probe_episode.episode_index),
            initial_target_state=initial_target,
            selected_avatar=selected_avatar,
            ranked_poi_candidates=ranked_pois,
            hud_targeting_report=hud_targeting_report,
            contact_experiment_report=contact_experiment_report,
            mechanic_report=mechanic_report,
            seed=int(base_seed) + int(probe_episode.episode_index),
            render_terminal=render_terminal,
            env_factory=env_factory,
            max_steps=max_steps,
        )
        episodes.append(result)
        mechanic_report = build_mechanic_report(
            ranked_pois,
            contact_experiment_report=contact_experiment_report,
            hud_targeting_report=hud_targeting_report,
            solve_report=SolveReport(
                episodes=tuple(episodes),
                diagnostics=SolveDiagnostics(
                    episode_count=len(episodes),
                    solved_episode_count=sum(1 for ep in episodes if ep.solved),
                    failed_episode_count=sum(1 for ep in episodes if not ep.solved),
                    failure_reason_counts={},
                    retarget_count=0,
                    level_transition_count=0,
                    terminal_success_count=0,
                    terminal_failure_count=0,
                    step_budget_exhausted_count=0,
                ),
                selected_target_id=initial_target.target_poi_id,
                solved=any(ep.solved for ep in episodes),
                failure_reason=None,
            ),
            previous_mechanic_memory=getattr(mechanic_report, "memory", None),
        )

        if result.failure_reason is not None:
            failure_counts[str(result.failure_reason)] += 1
        step_budget_exhausted_count += 1 if result.failure_reason == "step_budget_exhausted" else 0
        terminal_failure_count += 1 if result.failure_reason == "terminal_failure" else 0
        retarget_count += sum(1 for step in result.steps if str(step.target_poi_id) != str(result.initial_target.target_poi_id))
        level_transition_count += sum(1 for step in result.steps if int(step.levels_completed_after) > int(step.levels_completed_before))
        terminal_success_count += sum(1 for step in result.steps if bool(step.terminal) and step.outcome_type in {"terminal", "level_transition"})

    solved_episode_count = sum(1 for item in episodes if item.solved)
    failed_episode_count = max(0, len(episodes) - solved_episode_count)
    solved = solved_episode_count > 0

    failure_reason = None
    if not episodes:
        failure_reason = "no_progress"
    elif not solved:
        if failure_counts:
            failure_reason = sorted(failure_counts.items(), key=lambda item: (-item[1], item[0]))[0][0]
        else:
            failure_reason = "no_progress"

    diagnostics = SolveDiagnostics(
        episode_count=len(episodes),
        solved_episode_count=solved_episode_count,
        failed_episode_count=failed_episode_count,
        failure_reason_counts=dict(sorted((str(k), int(v)) for k, v in failure_counts.items())),
        retarget_count=int(retarget_count),
        level_transition_count=int(level_transition_count),
        terminal_success_count=int(terminal_success_count),
        terminal_failure_count=int(terminal_failure_count),
        step_budget_exhausted_count=int(step_budget_exhausted_count),
    )
    return SolveReport(
        episodes=tuple(episodes),
        diagnostics=diagnostics,
        selected_target_id=str(initial_target.target_poi_id),
        solved=bool(solved),
        failure_reason=failure_reason,
    )


def run_adaptive_solve_multi_reset(
    *,
    avatar_multi_report,
    poi_multi_bundle,
    hud_targeting_report,
    contact_experiment_report=None,
    game_id,
    plan,
    base_seed,
    render_terminal,
    env_factory: Callable[[], Any] | None,
    max_steps,
) -> AdaptiveSolveReport:
    if getattr(avatar_multi_report.selected, "failure_reason", None) is not None or not bool(getattr(avatar_multi_report.diagnostics, "stable_avatar_found", False)):
        diagnostics = AdaptiveDiagnostics(
            episode_count=0,
            solved_episode_count=0,
            failed_episode_count=0,
            retarget_count=0,
            target_switch_count=0,
            useful_change_count=0,
            no_progress_count=0,
            level_transition_count=0,
            terminal_count=0,
            step_budget_exhausted_count=0,
            failure_reason_counts={"no_stable_avatar": 1},
        )
        return AdaptiveSolveReport(episodes=(), diagnostics=diagnostics, selected_target_id=None, solved=False, failure_reason="no_stable_avatar")

    poi_report = poi_multi_bundle.get("report") if isinstance(poi_multi_bundle, dict) else None
    ranked_pois = tuple(getattr(poi_report, "candidates", ()))
    if not ranked_pois:
        diagnostics = AdaptiveDiagnostics(
            episode_count=0,
            solved_episode_count=0,
            failed_episode_count=0,
            retarget_count=0,
            target_switch_count=0,
            useful_change_count=0,
            no_progress_count=0,
            level_transition_count=0,
            terminal_count=0,
            step_budget_exhausted_count=0,
            failure_reason_counts={"no_poi_candidate": 1},
        )
        return AdaptiveSolveReport(episodes=(), diagnostics=diagnostics, selected_target_id=None, solved=False, failure_reason="no_poi_candidate")

    episodes = []
    failure_counts = Counter()
    retarget_count = 0
    target_switch_count = 0
    useful_change_count = 0
    no_progress_count = 0
    level_transition_count = 0
    terminal_count = 0
    step_budget_exhausted_count = 0

    for probe_episode in tuple(getattr(avatar_multi_report, "episodes", ())):
        selected_avatar = probe_episode.report.selected
        if selected_avatar.failure_reason is not None:
            continue
        result = run_adaptive_solve_episode(
            game_id=game_id,
            plan=plan,
            episode_index=int(probe_episode.episode_index),
            selected_avatar=selected_avatar,
            ranked_poi_candidates=ranked_pois,
            hud_targeting_report=hud_targeting_report,
            contact_experiment_report=contact_experiment_report,
            seed=int(base_seed) + int(probe_episode.episode_index),
            render_terminal=render_terminal,
            env_factory=env_factory,
            max_steps=max_steps,
        )
        episodes.append(result)
        if result.failure_reason is not None:
            failure_counts[str(result.failure_reason)] += 1
            if result.failure_reason == "no_progress":
                no_progress_count += 1
            if result.failure_reason == "step_budget_exhausted":
                step_budget_exhausted_count += 1
        for step in result.steps:
            if bool(step.retargeted):
                retarget_count += 1
            if str(step.outcome_type) in {"reward_change", "object_removed", "door_opens", "level_transition", "terminal"}:
                useful_change_count += 1
            if int(step.levels_completed_after) > int(step.levels_completed_before):
                level_transition_count += 1
            if bool(step.terminal):
                terminal_count += 1
        target_switch_count += max(0, len(result.target_sequence) - 1)

    solved_episode_count = sum(1 for ep in episodes if ep.solved)
    failed_episode_count = max(0, len(episodes) - solved_episode_count)
    solved = solved_episode_count > 0
    failure_reason = None
    if not episodes:
        failure_reason = "no_progress"
    elif not solved:
        if failure_counts:
            failure_reason = sorted(failure_counts.items(), key=lambda item: (-item[1], item[0]))[0][0]
        else:
            failure_reason = "no_progress"

    selected_target_id = None
    if episodes and episodes[0].target_sequence:
        selected_target_id = episodes[0].target_sequence[0].target_poi_id
    diagnostics = AdaptiveDiagnostics(
        episode_count=len(episodes),
        solved_episode_count=solved_episode_count,
        failed_episode_count=failed_episode_count,
        retarget_count=int(retarget_count),
        target_switch_count=int(target_switch_count),
        useful_change_count=int(useful_change_count),
        no_progress_count=int(no_progress_count),
        level_transition_count=int(level_transition_count),
        terminal_count=int(terminal_count),
        step_budget_exhausted_count=int(step_budget_exhausted_count),
        failure_reason_counts=dict(sorted((str(k), int(v)) for k, v in failure_counts.items())),
    )
    return AdaptiveSolveReport(
        episodes=tuple(episodes),
        diagnostics=diagnostics,
        selected_target_id=selected_target_id,
        solved=bool(solved),
        failure_reason=failure_reason,
    )


def build_level_solution_from_adaptive_report(
    *,
    game_id: str,
    level_id: str,
    adaptive_report: AdaptiveSolveReport,
) -> LevelSolution:
    episodes = tuple(getattr(adaptive_report, "episodes", ()))
    solved_episode = next((ep for ep in episodes if bool(getattr(ep, "solved", False))), None)
    source_episode = solved_episode if solved_episode is not None else (episodes[0] if episodes else None)

    trace: list[LevelSolveAction] = []
    terminal = False
    level_transition = False
    if source_episode is not None:
        trace = list(_extract_full_level_step_trace(tuple(getattr(source_episode, "steps", ()))))
        for step in tuple(getattr(source_episode, "steps", ())):
            pre_level = int(getattr(step, "levels_completed_before", 0))
            post_level = int(getattr(step, "levels_completed_after", 0))
            level_transition = level_transition or (post_level > pre_level)
            terminal = terminal or bool(getattr(step, "terminal", False))

    solved = bool(getattr(adaptive_report, "solved", False))
    if solved and not trace:
        fallback_episode = next((ep for ep in episodes if tuple(getattr(ep, "steps", ()))), None)
        if fallback_episode is not None:
            trace = list(_extract_full_level_step_trace(tuple(getattr(fallback_episode, "steps", ()))))
            for step in tuple(getattr(fallback_episode, "steps", ())):
                pre_level = int(getattr(step, "levels_completed_before", 0))
                post_level = int(getattr(step, "levels_completed_after", 0))
                level_transition = level_transition or (post_level > pre_level)
                terminal = terminal or bool(getattr(step, "terminal", False))

    failure_reason = None if solved else getattr(adaptive_report, "failure_reason", "no_progress")
    return LevelSolution(
        game_id=str(game_id),
        level_id=str(level_id),
        solved=bool(solved),
        action_trace=tuple(trace),
        step_count=len(trace),
        terminal=bool(terminal),
        level_transition=bool(level_transition),
        failure_reason=failure_reason,
    )


def extract_replayable_level_trace(
    *,
    solved_level_result,
    executed_solve_steps,
    game_id: str,
    level_id: str,
    source_run_id: str | None = None,
    trace_version: int = 1,
) -> SavedLevelTrace:
    solved = bool(getattr(solved_level_result, "solved", False) if solved_level_result is not None else False)
    actions = tuple(str(getattr(step, "action", "")) for step in tuple(executed_solve_steps or ()))
    action_sources = tuple(str(getattr(step, "source", "frontier_solve")) for step in tuple(executed_solve_steps or ()))
    return SavedLevelTrace(
        game_id=str(game_id),
        level_id=str(level_id),
        solved=bool(solved),
        action_trace=actions,
        step_count=len(actions),
        source_run_id=source_run_id,
        trace_version=int(trace_version),
        replay_verified=False,
        action_sources=action_sources,
    )


def verify_level_trace_replay(
    *,
    game_id: str,
    level_id: str,
    saved_trace: SavedLevelTrace,
    prefix_traces=(),
    render_terminal: bool = False,
    env_factory: Callable[[], Any] | None = None,
) -> dict[str, Any]:
    replay = replay_trace_at_frontier(
        game_id=game_id,
        level_id=level_id,
        prefix_traces=tuple(prefix_traces or ()),
        frontier_trace=tuple(saved_trace.action_trace),
        render_terminal=bool(render_terminal),
        env_factory=env_factory,
    )
    return {
        "verified": bool(replay.get("success", False)) and bool(replay.get("level_solved", False)),
        "final_level_reached": int(replay.get("final_level_reached", 0)),
        "executed_action_count": int(replay.get("executed_action_count", 0)),
        "divergence": bool(replay.get("divergence", False)),
        "frontier_reached": bool(replay.get("frontier_reached", False)),
        "level_solved": bool(replay.get("level_solved", False)),
    }


def finalize_solved_level_trace(
    *,
    solved_level_result,
    executed_actions: tuple[str, ...] | list[str],
    game_id: str,
    level_id: str,
    prefix_traces=(),
    render_terminal: bool = False,
    env_factory: Callable[[], Any] | None = None,
    trace_db_path: str | None = None,
) -> dict[str, Any]:
    solved = bool(getattr(solved_level_result, "solved", False) if solved_level_result is not None else False)
    raw_items = tuple(executed_actions or ())
    actions: list[str] = []
    action_sources: list[str] = []
    for item in raw_items:
        if isinstance(item, str):
            actions.append(str(item))
            action_sources.append("frontier_solve")
            continue
        action = getattr(item, "action", None)
        if action is None and isinstance(item, dict):
            action = item.get("action")
        source = getattr(item, "source", None)
        if source is None and isinstance(item, dict):
            source = item.get("source")
        if action is None:
            continue
        actions.append(str(action))
        action_sources.append(str(source or "frontier_solve"))
    actions_tuple = tuple(actions)
    sources_tuple = tuple(action_sources)
    if solved and not actions_tuple:
        trace = SavedLevelTrace(
            game_id=str(game_id),
            level_id=str(level_id),
            solved=True,
            action_trace=tuple(),
            step_count=0,
            source_run_id=None,
            trace_version=1,
            replay_verified=False,
            action_sources=tuple(),
            trace_id=None,
        )
        return {
            "saved_trace": trace,
            "replay_verified": False,
            "failure_reason": "solved_trace_missing_actions",
            "trace_id": None,
        }
    trace_id = f"{game_id}:{level_id}:{int(time.time() * 1000)}"
    trace = SavedLevelTrace(
        game_id=str(game_id),
        level_id=str(level_id),
        solved=bool(solved),
        action_trace=actions_tuple,
        step_count=len(actions_tuple),
        source_run_id=None,
        trace_version=1,
        replay_verified=False,
        action_sources=sources_tuple if sources_tuple else None,
        trace_id=trace_id,
    )
    replay = verify_level_trace_replay(
        game_id=game_id,
        level_id=level_id,
        saved_trace=trace,
        prefix_traces=tuple(prefix_traces or ()),
        render_terminal=bool(render_terminal),
        env_factory=env_factory,
    )
    replay_verified = bool(replay.get("verified", False))
    finalized = SavedLevelTrace(
        game_id=trace.game_id,
        level_id=trace.level_id,
        solved=trace.solved,
        action_trace=trace.action_trace,
        step_count=trace.step_count,
        source_run_id=trace.source_run_id,
        trace_version=trace.trace_version,
        replay_verified=replay_verified,
        action_sources=trace.action_sources,
        trace_id=trace.trace_id,
    )
    persisted_trace_id = None
    if replay_verified:
        inserted, persisted_trace_id = upsert_verified_best_trace(db_path=trace_db_path, trace=finalized)
        if not inserted and not persisted_trace_id:
            return {
                "saved_trace": finalized,
                "replay_verified": True,
                "failure_reason": "verified_trace_persist_failed",
                "trace_id": None,
            }
    return {
        "saved_trace": finalized,
        "replay_verified": replay_verified,
        "failure_reason": None if replay_verified else "trace_replay_verification_failed",
        "trace_id": persisted_trace_id if replay_verified else None,
    }


def _conservative_hud_only_change(
    pre_frame: tuple[tuple[int, ...], ...] | None,
    post_frame: tuple[tuple[int, ...], ...] | None,
) -> bool:
    return detect_hud_only_change(pre_frame, post_frame)


def _deterministic_frame_hash(frame: tuple[tuple[int, ...], ...] | None) -> str:
    if frame is None:
        return "none"
    payload = "|".join(",".join(str(int(v)) for v in row) for row in frame).encode("utf-8")
    return hashlib.sha1(payload).hexdigest()


def _build_state_signature(
    *,
    level_id: int,
    action: str,
    avatar_bbox_after,
    target_bbox_after,
    reward_after,
    post_frame: tuple[tuple[int, ...], ...] | None,
) -> tuple[str, str, tuple[int, int, int, int] | None, tuple[int, int, int, int] | None, float | None, str]:
    return (
        str(level_id),
        str(action),
        avatar_bbox_after,
        target_bbox_after,
        float(reward_after) if reward_after is not None else None,
        _deterministic_frame_hash(post_frame),
    )


def reanchor_frontier_objects(
    *,
    frame: tuple[tuple[int, ...], ...] | None,
    selected_avatar,
    initial_poi,
) -> tuple[tuple[int, int, int, int] | None, tuple[int, int, int, int] | None]:
    avatar_ref_bbox = getattr(selected_avatar, "selected_bbox", None)
    avatar_ref_hist = getattr(selected_avatar, "value_histogram", None)
    poi_ref_bbox = getattr(initial_poi, "bbox", None) if initial_poi is not None else None
    poi_ref_hist = getattr(initial_poi, "value_histogram", None) if initial_poi is not None else None
    strict_avatar = track_avatar_bbox_in_frame(
        frame,
        avatar_ref_bbox,
        avatar_ref_hist,
        frontier_reanchor=False,
    )
    strict_target = track_poi_bbox_in_frame(
        frame,
        poi_ref_bbox,
        poi_ref_hist,
        frontier_reanchor=False,
    )
    if strict_avatar is not None and strict_target is not None:
        return strict_avatar, strict_target
    relaxed_avatar = strict_avatar or reacquire_avatar_bbox_in_frame(
        frame,
        avatar_ref_bbox,
        avatar_ref_hist,
    )
    relaxed_target = strict_target or reacquire_poi_bbox_in_frame(
        frame,
        poi_ref_bbox,
        poi_ref_hist,
    )
    if relaxed_avatar is None:
        relaxed_avatar = find_best_component_match_in_frame(
            frame=frame,
            reference_bbox=avatar_ref_bbox,
            reference_histogram=avatar_ref_hist,
            for_poi=False,
        )
    if relaxed_target is None:
        relaxed_target = find_best_component_match_in_frame(
            frame=frame,
            reference_bbox=poi_ref_bbox,
            reference_histogram=poi_ref_hist,
            for_poi=True,
        )
    return relaxed_avatar, relaxed_target


def run_adaptive_solve_on_live_session(
    *,
    session,
    selected_avatar,
    ranked_poi_candidates,
    hud_targeting_report,
    contact_experiment_report,
    game_id: str,
    level_id: str,
    max_steps: int,
    session_adapter: SessionAdapter | None = None,
    action_adapter: ActionAdapter | None = None,
    skip_bootstrap_replay_in_final_solve: bool = False,
) -> AdaptiveSolveReport:
    del skip_bootstrap_replay_in_final_solve
    session_adapter = session_adapter or SessionAdapter()
    action_adapter = action_adapter or ActionAdapter()
    ranked = tuple(ranked_poi_candidates or ())
    if selected_avatar is None or getattr(selected_avatar, "failure_reason", None) is not None:
        diagnostics = AdaptiveDiagnostics(0, 0, 0, 0, 0, 0, 1, 0, 0, 0, {"no_stable_avatar": 1})
        return AdaptiveSolveReport(episodes=(), diagnostics=diagnostics, selected_target_id=None, solved=False, failure_reason="no_stable_avatar")
    if not ranked:
        diagnostics = AdaptiveDiagnostics(0, 0, 0, 0, 0, 0, 1, 0, 0, 0, {"no_poi_candidate": 1})
        return AdaptiveSolveReport(episodes=(), diagnostics=diagnostics, selected_target_id=None, solved=False, failure_reason="no_poi_candidate")

    initial = select_initial_target(
        hud_targeting_report,
        ranked,
        contact_experiment_report=contact_experiment_report,
    )
    if initial is None or initial.target_poi_id is None:
        diagnostics = AdaptiveDiagnostics(0, 0, 0, 0, 0, 0, 1, 0, 0, 0, {"no_target_selected": 1})
        return AdaptiveSolveReport(episodes=(), diagnostics=diagnostics, selected_target_id=None, solved=False, failure_reason="no_target_selected")

    poi_by_id = {item.poi_id: item for item in ranked}
    initial_obs = session_adapter.get_current_observation(session)
    initial_frame = _extract_frame_plane(initial_obs.frame)
    initial_poi = poi_by_id.get(str(initial.target_poi_id))
    avatar_anchor, target_anchor = reanchor_frontier_objects(
        frame=initial_frame,
        selected_avatar=selected_avatar,
        initial_poi=initial_poi,
    )
    if avatar_anchor is None or target_anchor is None:
        diagnostics = AdaptiveDiagnostics(1, 0, 1, 0, 0, 0, 1, 0, 0, 0, {"frontier_geometry_mismatch": 1})
        return AdaptiveSolveReport(
            episodes=(),
            diagnostics=diagnostics,
            selected_target_id=initial.target_poi_id,
            solved=False,
            failure_reason="frontier_geometry_mismatch",
        )

    steps: list[AdaptiveStepRecord] = []
    target_sequence: list[AdaptiveTargetState] = [
        AdaptiveTargetState(
            target_poi_id=initial.target_poi_id,
            source=initial.source,
            confidence=float(initial.confidence),
            attempt_count=int(initial.attempt_count),
            last_outcome_type=initial.last_outcome_type,
            active=bool(initial.active),
        )
    ]
    current = initial
    current_avatar_bbox = avatar_anchor
    current_target_bbox = target_anchor
    blocked_streak = 0
    repeated_identical_signature_count = 0
    last_signature = None
    same_action_no_progress_streak = 0
    last_action_no_progress: str | None = None
    solved = False
    failure_reason: str | None = None
    hud_mask = getattr(hud_targeting_report, "hud_mask", None)

    for step_index in range(max(0, int(max_steps))):
        obs = session_adapter.get_current_observation(session)
        pre_frame = _extract_frame_plane(obs.frame)
        reward_before = _extract_reward(obs.raw_payload)
        poi = poi_by_id.get(str(current.target_poi_id))
        if poi is None:
            failure_reason = "no_target_selected"
            break
        avatar_before = track_avatar_bbox_in_frame(
            pre_frame,
            current_avatar_bbox,
            getattr(selected_avatar, "value_histogram", None),
            frontier_reanchor=False,
        )
        target_before = track_poi_bbox_in_frame(
            pre_frame,
            current_target_bbox,
            poi.value_histogram,
            frontier_reanchor=False,
        )
        if avatar_before is None or target_before is None:
            avatar_before = avatar_before or reacquire_avatar_bbox_in_frame(
                pre_frame,
                current_avatar_bbox,
                getattr(selected_avatar, "value_histogram", None),
            )
            target_before = target_before or reacquire_poi_bbox_in_frame(
                pre_frame,
                current_target_bbox,
                poi.value_histogram,
            )
            if avatar_before is None:
                avatar_before = find_best_component_match_in_frame(
                    frame=pre_frame,
                    reference_bbox=current_avatar_bbox,
                    reference_histogram=getattr(selected_avatar, "value_histogram", None),
                    for_poi=False,
                )
            if target_before is None:
                target_before = find_best_component_match_in_frame(
                    frame=pre_frame,
                    reference_bbox=current_target_bbox,
                    reference_histogram=poi.value_histogram,
                    for_poi=True,
                )
            if avatar_before is None or target_before is None:
                failure_reason = "frontier_geometry_mismatch"
                break
        policy = build_adaptive_policy_for_target(
            selected_avatar,
            poi,
            pre_frame,
            max(1, int(max_steps) - step_index),
        )
        action = policy[0] if policy else "RIGHT"
        context = ActionTranslationContext(
            available_action_ids=obs.available_actions,
            coordinate_action_id=session.environment_metadata.coordinate_action_id,
            coordinate_bounds=session.environment_metadata.coordinate_bounds,
        )
        try:
            translated = action_adapter.translate_token(action, context)
            executed = session_adapter.execute_action_prefix(session, (translated,), (action,))
            invalid = False
        except Exception:
            executed = None
            invalid = True

        if invalid:
            step = AdaptiveStepRecord(
                step_index=step_index, action=str(action), pre_frame=pre_frame, post_frame=None,
                invalid_action=True, blocked_action=False, terminal=False,
                levels_completed_before=int(obs.levels_completed), levels_completed_after=int(obs.levels_completed),
                reward_before=reward_before, reward_after=reward_before,
                avatar_bbox_before=avatar_before, avatar_bbox_after=avatar_before,
                target_poi_id=current.target_poi_id, target_bbox_before=target_before, target_bbox_after=target_before,
                contact_detected=False, screen_changed=False, hud_changed_only=False, outcome_type="no_effect", retargeted=False,
                source="frontier_solve",
            )
            steps.append(step)
            failure_reason = "no_progress"
            break

        post = session_adapter.get_current_observation(session)
        post_frame = _extract_frame_plane(post.frame)
        reward_after = _extract_reward(post.raw_payload)
        blocked = any(not item.action_legal for item in executed.step_results)
        blocked_streak = blocked_streak + 1 if blocked else 0
        level_transition = int(post.levels_completed) > int(obs.levels_completed)
        terminal = str(executed.terminal_status) in {"success", "failure"}
        avatar_after = track_avatar_bbox_in_frame(
            post_frame,
            avatar_before,
            getattr(selected_avatar, "value_histogram", None),
            frontier_reanchor=False,
        )
        target_after = track_poi_bbox_in_frame(
            post_frame,
            target_before,
            poi.value_histogram,
            frontier_reanchor=False,
        )
        if avatar_after is None:
            avatar_after = reacquire_avatar_bbox_in_frame(
                post_frame,
                avatar_before or current_avatar_bbox,
                getattr(selected_avatar, "value_histogram", None),
            )
        if target_after is None:
            target_after = reacquire_poi_bbox_in_frame(
                post_frame,
                target_before or current_target_bbox,
                poi.value_histogram,
            )
        if avatar_after is None:
            avatar_after = find_best_component_match_in_frame(
                frame=post_frame,
                reference_bbox=avatar_before or current_avatar_bbox,
                reference_histogram=getattr(selected_avatar, "value_histogram", None),
                for_poi=False,
            )
        if target_after is None:
            target_after = find_best_component_match_in_frame(
                frame=post_frame,
                reference_bbox=target_before or current_target_bbox,
                reference_histogram=poi.value_histogram,
                for_poi=True,
            )

        screen_changed = detect_screen_change(pre_frame, post_frame)
        contact_detected = detect_contact(avatar_after, target_after)
        hud_changed_only = detect_hud_only_change(pre_frame, post_frame) if hud_mask is not None else _conservative_hud_only_change(pre_frame, post_frame)
        world_change_outside_hud = detect_screen_change_outside_hud_mask(pre_frame, post_frame, hud_mask=hud_mask)
        reward_changed = reward_after != reward_before
        terminal_success = terminal and str(executed.terminal_status) == "success"
        no_progress = (
            (not level_transition)
            and (not terminal_success)
            and (not reward_changed)
            and (not world_change_outside_hud)
            and (avatar_after is None or avatar_before is None or avatar_after == avatar_before)
        )
        if level_transition:
            outcome_type = "level_transition"
        elif terminal:
            outcome_type = "terminal"
        elif reward_changed:
            outcome_type = "reward_change"
        elif hud_changed_only:
            outcome_type = "hud_change_only"
        elif world_change_outside_hud:
            outcome_type = "world_change"
        else:
            outcome_type = "no_effect"
        step = AdaptiveStepRecord(
            step_index=step_index, action=str(action), pre_frame=pre_frame, post_frame=post_frame,
            invalid_action=False, blocked_action=bool(blocked), terminal=bool(terminal),
            levels_completed_before=int(obs.levels_completed), levels_completed_after=int(post.levels_completed),
            reward_before=reward_before, reward_after=reward_after,
            avatar_bbox_before=avatar_before, avatar_bbox_after=avatar_after,
            target_poi_id=current.target_poi_id, target_bbox_before=target_before, target_bbox_after=target_after,
            contact_detected=bool(contact_detected), screen_changed=bool(screen_changed), hud_changed_only=bool(hud_changed_only), outcome_type=outcome_type, retargeted=False,
            source="frontier_solve",
        )
        current_avatar_bbox = step.avatar_bbox_after
        current_target_bbox = step.target_bbox_after
        steps.append(step)

        signature = _build_state_signature(
            level_id=int(post.levels_completed),
            action=str(action),
            avatar_bbox_after=step.avatar_bbox_after,
            target_bbox_after=step.target_bbox_after,
            reward_after=reward_after,
            post_frame=post_frame,
        )
        if signature == last_signature:
            repeated_identical_signature_count += 1
        else:
            repeated_identical_signature_count = 1
            last_signature = signature
        if no_progress and last_action_no_progress == str(action):
            same_action_no_progress_streak += 1
            last_action_no_progress = str(action)
        elif no_progress:
            same_action_no_progress_streak = 1
            last_action_no_progress = str(action)
        else:
            same_action_no_progress_streak = 0
            last_action_no_progress = None

        if repeated_identical_signature_count >= 3 or same_action_no_progress_streak >= 3:
            failure_reason = "repeated_non_progress"
            break

        if level_transition or str(executed.terminal_status) == "success":
            solved = True
            break
        if terminal:
            failure_reason = "terminal_failure"
            break
        repeated_no_effect = _tail_count([item for item in steps if item.target_poi_id == current.target_poi_id], lambda s: s.outcome_type in {"no_effect", "hud_change_only"}) >= 3
        if repeated_no_effect or blocked_streak >= 2:
            nxt = select_next_target(current, ranked, tuple(steps), contact_experiment_report)
            if nxt is None:
                failure_reason = "no_target_selected"
                break
            current = nxt
            next_poi = poi_by_id.get(str(current.target_poi_id))
            current_target_bbox = track_poi_bbox_in_frame(
                post_frame,
                getattr(next_poi, "bbox", None) if next_poi is not None else None,
                getattr(next_poi, "value_histogram", None) if next_poi is not None else None,
                frontier_reanchor=False,
            )
            if current_target_bbox is None:
                current_target_bbox = reacquire_poi_bbox_in_frame(
                    post_frame,
                    getattr(next_poi, "bbox", None) if next_poi is not None else None,
                    getattr(next_poi, "value_histogram", None) if next_poi is not None else None,
                )
            if current_target_bbox is None:
                current_target_bbox = find_best_component_match_in_frame(
                    frame=post_frame,
                    reference_bbox=getattr(next_poi, "bbox", None) if next_poi is not None else None,
                    reference_histogram=getattr(next_poi, "value_histogram", None) if next_poi is not None else None,
                    for_poi=True,
                )
            if current_target_bbox is None:
                failure_reason = "frontier_geometry_mismatch"
                break
            target_sequence.append(
                AdaptiveTargetState(
                    target_poi_id=current.target_poi_id,
                    source=current.source,
                    confidence=float(current.confidence),
                    attempt_count=int(current.attempt_count),
                    last_outcome_type=current.last_outcome_type,
                    active=bool(current.active),
                )
            )

    if not solved and failure_reason is None:
        failure_reason = "step_budget_exhausted" if len(steps) >= int(max_steps) else "no_progress"
    episode = AdaptiveEpisodeResult(
        episode_index=0,
        target_sequence=tuple(target_sequence),
        steps=tuple(steps),
        solved=bool(solved),
        failure_reason=None if solved else failure_reason,
    )
    diagnostics = AdaptiveDiagnostics(
        episode_count=1,
        solved_episode_count=1 if solved else 0,
        failed_episode_count=0 if solved else 1,
        retarget_count=sum(1 for s in steps if s.retargeted),
        target_switch_count=max(0, len(target_sequence) - 1),
        useful_change_count=sum(1 for s in steps if s.outcome_type in {"reward_change", "object_removed", "door_opens", "level_transition", "terminal"}),
        no_progress_count=0 if solved else 1,
        level_transition_count=sum(1 for s in steps if s.levels_completed_after > s.levels_completed_before),
        terminal_count=sum(1 for s in steps if s.terminal),
        step_budget_exhausted_count=1 if (not solved and failure_reason == "step_budget_exhausted") else 0,
        failure_reason_counts={} if solved else {str(failure_reason): 1},
    )
    return AdaptiveSolveReport(
        episodes=(episode,),
        diagnostics=diagnostics,
        selected_target_id=initial.target_poi_id,
        solved=bool(solved),
        failure_reason=None if solved else failure_reason,
    )


def extract_verified_frontier_trace(
    *,
    game_id: str,
    level_id: str,
    adaptive_report: AdaptiveSolveReport,
    source_run_id: str | None = None,
    trace_version: int = 1,
) -> SavedLevelTrace:
    solved_episode = next((ep for ep in adaptive_report.episodes if ep.solved), None)
    source = solved_episode if solved_episode is not None else (adaptive_report.episodes[0] if adaptive_report.episodes else None)
    actions = tuple(str(step.action) for step in tuple(getattr(source, "steps", ())))
    sources = tuple(str(getattr(step, "source", "frontier_solve")) for step in tuple(getattr(source, "steps", ())))
    return SavedLevelTrace(
        game_id=game_id,
        level_id=level_id,
        solved=bool(adaptive_report.solved),
        action_trace=actions,
        step_count=len(actions),
        source_run_id=source_run_id,
        trace_version=int(trace_version),
        replay_verified=False,
        action_sources=sources if sources else None,
    )


def _extract_full_level_step_trace(steps) -> tuple[LevelSolveAction, ...]:
    trace: list[LevelSolveAction] = []
    for idx, step in enumerate(tuple(steps or ())):
        pre_level = int(getattr(step, "levels_completed_before", 0))
        post_level = int(getattr(step, "levels_completed_after", 0))
        trace.append(
            LevelSolveAction(
                step_index=int(getattr(step, "step_index", idx)),
                action=str(getattr(step, "action", "")),
                target_poi_id=getattr(step, "target_poi_id", None),
                reason=str(getattr(step, "outcome_type", "")) if getattr(step, "outcome_type", None) is not None else None,
                pre_level_index=pre_level,
                post_level_index=post_level,
                source=str(getattr(step, "source", "frontier_solve")),
                pre_frame=getattr(step, "pre_frame", None),
                post_frame=getattr(step, "post_frame", None),
                invalid_action=bool(getattr(step, "invalid_action", False)),
                blocked_action=bool(getattr(step, "blocked_action", False)),
                terminal=bool(getattr(step, "terminal", False)),
                reward_before=getattr(step, "reward_before", None),
                reward_after=getattr(step, "reward_after", None),
            )
        )
    return tuple(trace)


def _extract_full_executed_action_trace(steps) -> tuple[LevelSolveAction, ...]:
    return _extract_full_level_step_trace(steps)


def _extract_frame_plane(frame: Any) -> tuple[tuple[int, ...], ...] | None:
    if not isinstance(frame, tuple) or not frame:
        return None
    plane = frame[0]
    if not isinstance(plane, tuple):
        return None
    rows: list[tuple[int, ...]] = []
    for row in plane:
        if not isinstance(row, tuple):
            return None
        rows.append(tuple(int(value) for value in row))
    return tuple(rows)


def _extract_reward(payload: Any) -> float | None:
    if not isinstance(payload, dict):
        return None
    value = payload.get("reward")
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _tail_count(items, predicate) -> int:
    count = 0
    for item in reversed(tuple(items)):
        if not predicate(item):
            break
        count += 1
    return count
