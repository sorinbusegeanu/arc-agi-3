from __future__ import annotations

from v5_0.contracts.avatar_types import ContactPolicy, POICandidate, ProbeTransitionRecord


def build_contact_policy_for_poi(
    selected_avatar,
    poi_candidate: POICandidate,
    transitions: tuple[ProbeTransitionRecord, ...],
    episode_index: int,
) -> ContactPolicy | None:
    if _is_border_locked_poi(poi_candidate):
        return None

    avatar_center = selected_avatar.selected_center or (0.0, 0.0)
    poi_center = poi_candidate.center
    dx = poi_center[0] - avatar_center[0]
    dy = poi_center[1] - avatar_center[1]

    horizontal = _axis_actions(dx, "RIGHT", "LEFT")
    vertical = _axis_actions(dy, "DOWN", "UP")
    if abs(dx) >= abs(dy):
        planned = horizontal + vertical
    else:
        planned = vertical + horizontal

    max_steps = min(8, max(1, len(planned) + 2))
    planned = planned[:max_steps]
    return ContactPolicy(
        policy_id=f"contact:{episode_index}:{poi_candidate.poi_id}",
        poi_id=poi_candidate.poi_id,
        episode_index=int(episode_index),
        planned_actions=tuple(planned),
        max_steps=int(max_steps),
        stop_on_contact=True,
        stop_on_screen_change=True,
        stop_on_terminal=True,
    )


def _axis_actions(delta: float, positive: str, negative: str) -> list[str]:
    steps = int(round(abs(delta)))
    token = positive if delta >= 0 else negative
    return [token for _ in range(max(0, steps))]


def _is_border_locked_poi(poi_candidate: POICandidate) -> bool:
    x0, y0, x1, y1 = poi_candidate.bbox
    bw = max(1, x1 - x0 + 1)
    bh = max(1, y1 - y0 + 1)
    strip_like = bw <= 2 or bh <= 2 or bw >= 3 * bh or bh >= 3 * bw
    tiny = int(poi_candidate.area) <= 8
    if not (tiny or strip_like):
        return False
    return bool("border_locked" in set(poi_candidate.ambiguity_flags) or x0 == 0 or y0 == 0 or x1 == 0 or y1 == 0)
