import unittest
from types import SimpleNamespace

from v5_0.contact.frame_tracker import (
    find_best_component_match_in_frame,
    reacquire_avatar_bbox_in_frame,
    reacquire_poi_bbox_in_frame,
)
from v5_0.solve.service import reanchor_frontier_objects


def _frame(w, h, cells):
    rows = [[0 for _ in range(w)] for _ in range(h)]
    for (x, y), value in cells.items():
        rows[y][x] = value
    return tuple(tuple(int(v) for v in row) for row in rows)


class TestFrontierReanchor(unittest.TestCase):
    def test_strict_reanchor_success(self):
        frame = _frame(8, 8, {(1, 1): 1, (4, 4): 2})
        avatar = SimpleNamespace(selected_bbox=(1, 1, 1, 1), value_histogram={1: 1})
        poi = SimpleNamespace(bbox=(4, 4, 4, 4), value_histogram={2: 1})
        a, p = reanchor_frontier_objects(frame=frame, selected_avatar=avatar, initial_poi=poi)
        self.assertEqual(a, (1, 1, 1, 1))
        self.assertEqual(p, (4, 4, 4, 4))

    def test_relaxed_avatar_reacquire_success_when_overlap_gone(self):
        frame = _frame(8, 8, {(4, 1): 1, (6, 6): 2})
        out = reacquire_avatar_bbox_in_frame(frame, (1, 1, 1, 1), {1: 1})
        self.assertEqual(out, (4, 1, 4, 1))

    def test_relaxed_poi_reacquire_success_when_overlap_gone(self):
        frame = _frame(10, 10, {(6, 3): 2, (1, 1): 1})
        out = reacquire_poi_bbox_in_frame(frame, (2, 3, 2, 3), {2: 1})
        self.assertEqual(out, (6, 3, 6, 3))

    def test_near_plausible_component_beats_far_unrelated_component(self):
        frame = _frame(20, 20, {(5, 5): 3, (18, 18): 3})
        out = find_best_component_match_in_frame(
            frame=frame,
            reference_bbox=(4, 4, 4, 4),
            reference_histogram={3: 1},
            for_poi=True,
        )
        self.assertEqual(out, (5, 5, 5, 5))

    def test_missing_frame_returns_none(self):
        self.assertIsNone(reacquire_avatar_bbox_in_frame(None, (1, 1, 1, 1), {1: 1}))
        self.assertIsNone(reacquire_poi_bbox_in_frame(None, (1, 1, 1, 1), {2: 1}))

    def test_reanchor_frontier_objects_relaxed_success_prevents_immediate_failure(self):
        frame = _frame(10, 10, {(2, 2): 1, (4, 4): 2})
        avatar = SimpleNamespace(selected_bbox=(2, 2, 2, 2), value_histogram={1: 1})
        # Large reference poi box makes strict poi match reject; relaxed re-acquire should still find (4,4)
        poi = SimpleNamespace(bbox=(0, 0, 8, 8), value_histogram={2: 1})
        a, p = reanchor_frontier_objects(frame=frame, selected_avatar=avatar, initial_poi=poi)
        self.assertIsNotNone(a)
        self.assertIsNotNone(p)


if __name__ == "__main__":
    unittest.main()
