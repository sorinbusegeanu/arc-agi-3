# ARC-AGI3 flat report consolidation

Copy `src` into the repository root. The existing command already uses
`PYTHONPATH=src`, so the patch loads automatically.

## Future epochs

After each hypothesis suite completes, reports are consolidated into:

```text
<run-output-dir>/reports/
```

Canonical names:

```text
epoch_0001_h01_report.json
epoch_0001_h01_report.txt
epoch_0001_h01_report.md
...
epoch_0001_h12_report.json
epoch_0001_summary.json
epoch_0001_aggregated.txt
latest_h01_report.json
...
latest_h12_report.json
latest_summary.json
report_index.json
```

Additional diagnostics and provenance artifacts are also flattened with the
epoch and hypothesis prefix.

The original nested folders remain unchanged for compatibility. Consolidated
files use hard links where supported, so they do not duplicate report data on
disk.

## Consolidate existing epochs

```bash
PYTHONPATH=src python -m v6.report_consolidation \
  --run-dir runs/v6/continuous/full_readwrite
```

## Verify automatic patch loading

```bash
PYTHONPATH=src python -c \
'import v6.report_consolidation as r; print(r._PATCHED)'
```

Expected:

```text
True
```

## Disable temporarily

```bash
ARC_AGI3_DISABLE_REPORT_CONSOLIDATION=1 PYTHONPATH=src python -m v6.cli ...
```
