# ARC-AGI3 hypothesis pipeline repairs

Copy the `src` directory into the repository root.

This package automatically loads through `src/sitecustomize.py` when the existing command uses:

```bash
PYTHONPATH=src python -m v6.cli ...
```

Repairs included:

- H09: reserves the event budget for contingencies, families, carriers, and roles before graph-edge events.
- H09: resolves source/target game and context for graph-edge events, using explicit surrogate values when concrete metadata is unavailable.
- H09: prevents motif signature collapse by adding semantic source information.
- H09: prevents surrogate-only scope breadth from qualifying a motif as emergent.
- H07/H08: retains bounded role-transfer history across epochs.
- H07/H08: creates event-level compact prediction and contradiction evidence when `prediction_results` is unavailable.
- H02: computes cumulative manifest coverage against cumulative expected jobs and caps the ratio at 1.0.

Verify:

```bash
PYTHONPATH=src python -c \
'import v6.future_options as f, v6.higher_order_substrate as h, v6.hypothesis_h02_report as r; print(f._ARC_AGI3_HYPOTHESIS_REPAIRS, h._ARC_AGI3_HYPOTHESIS_REPAIRS, r._ARC_AGI3_HYPOTHESIS_REPAIRS)'
```

Expected output:

```text
True True True
```

Use a new output directory for the next scientific run. Existing epochs contain collapsed H09 events and non-retained transfer populations.

Disable temporarily:

```bash
ARC_AGI3_DISABLE_HYPOTHESIS_REPAIRS=1 PYTHONPATH=src python -m v6.cli ...
```
