"""ARC-AGI3 local runtime patches loaded automatically by Python."""

from v6.higher_order_scope_index import apply_patch

apply_patch()
