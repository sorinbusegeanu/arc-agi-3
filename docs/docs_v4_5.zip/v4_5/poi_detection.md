POI detection for movement-only bootstrap

- Avatar handling is separate from POI detection.
- HUD, life, and progress region handling are separate from POI detection.
- Click handling is out of scope here.
- POI output contains only:
  - `bbox`
  - `center`
  - `colors`
- No shape field is included.
- No evidence tags are included.
- No code-generated natural-language hint is included.
- Deterministic POI analysis, LLM text POI analysis, and VLM video POI analysis run in parallel.
- Selection logic is not implemented yet.
- The default selected POI set is always the deterministic result.
